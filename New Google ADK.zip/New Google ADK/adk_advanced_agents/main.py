import asyncio
import os
from dotenv import load_dotenv
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from agents import create_integrated_workflow

# Load environment variables
load_dotenv()

async def run_agent(runner, query, user_id, session_id):
    """
    Helper to run an agent and return the text response.
    """
    # Create the Content object for the user query
    content = types.Content(role='user', parts=[types.Part(text=query)])
    
    print(f"  > Sending query: {query[:50]}...")
    
    # Run the agent asynchronously
    # We must consume the generator to execute the turn
    async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=content):
        # We process events here if needed, e.g. logging
        pass
    
    # After run completion, fetch the latest history from the session
    session = await runner.session_service.get_session(
        app_name=runner.app_name, 
        user_id=user_id, 
        session_id=session_id
    )
    
    last_response_text = ""
    # Iterate through events/history to find the last model response
    if hasattr(session, 'events') and session.events:
        # Traverse backwards to find the last model message
        for e in reversed(session.events):
            # Check if event has content and looks like a model response
            if hasattr(e, 'content') and e.content:
                # Check role if available (model responses usually have role='model')
                # Also check author if needed, but content.role is standard GenAI
                if hasattr(e.content, 'role') and e.content.role == 'model':
                    parts_text = []
                    if hasattr(e.content, 'parts') and e.content.parts:
                        for part in e.content.parts:
                            # Safely extract text
                            if hasattr(part, 'text') and part.text:
                                parts_text.append(part.text)
                    
                    if parts_text:
                        last_response_text = "\n".join(parts_text)
                        break

    return last_response_text if last_response_text else "Could not determine final response from session."

async def main():
    if not os.environ.get("GOOGLE_API_KEY"):
        print("Error: GOOGLE_API_KEY not found in .env file.")

    print("--- Initializing Workflow Agent ---")
    workflow_agent = create_integrated_workflow()
    
    session_service = InMemorySessionService()
    
    # Runner for the complete Sequential -> Loopable workflow
    workflow_runner = Runner(
        agent=workflow_agent, 
        session_service=session_service, 
        app_name="product_launch_app",
        auto_create_session=True
    )

    # Identifiers
    user_id = "user1234"
    session_id = "session_launch_01"

    product_name = "SuperPhone"
    # Single query that drives the whole Sequential Chain
    query = f"Research the product '{product_name}' and then write a strictly compliant marketing draft for it."
    
    print(f"\n--- Running Integrated Workflow for '{product_name}' ---")
    
    response_text = await run_agent(workflow_runner, query, user_id, session_id)
    
    print(f"\n[Workflow Final Output]:\n{response_text}")

if __name__ == "__main__":
    asyncio.run(main())
