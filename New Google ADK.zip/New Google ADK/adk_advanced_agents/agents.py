from google.adk.agents.llm_agent import LlmAgent
from google.adk.agents.sequential_agent import SequentialAgent
from google.adk.agents.loop_agent import LoopAgent
from google.adk.planners import BuiltInPlanner
from google.genai.types import ThinkingConfig
from utils import get_product_info, get_competitor_prices, analyze_market_sentiment, verify_policy_compliance

MODEL_NAME = "gemini-2.5-flash" 

def create_researcher_agent(model_name=MODEL_NAME):
    """
    Creates the researcher step.
    """
    # ... Same implementation ...
    thinking_config = ThinkingConfig(include_thoughts=True, thinking_budget=1024)
    planner = BuiltInPlanner(thinking_config=thinking_config)
    
    agent = LlmAgent(
        name="ResearcherAgent",
        model=model_name,
        planner=planner,
        tools=[get_product_info, get_competitor_prices, analyze_market_sentiment],
        instruction="""
        You are a detailed product researcher. 
        Your goal is to gather comprehensive data about a product.
        1. Get product specifications.
        2. Get competitor prices.
        3. Analyze market sentiment.
        4. Compile all this into a structured research summary.
        """
    )
    return agent

def create_editor_agent(model_name=MODEL_NAME):
    """
    Creates the editor step.
    """
    thinking_config = ThinkingConfig(include_thoughts=True, thinking_budget=1024)
    planner = BuiltInPlanner(thinking_config=thinking_config)
    
    agent = LlmAgent(
        name="EditorAgent",
        model=model_name,
        planner=planner,
        tools=[verify_policy_compliance],
        instruction="""
        You are a Strict Compliance Editor.
        Your task is to take the research summary provided in the context and write a marketing draft.
        
        CRITICAL: You must use the `verify_policy_compliance` tool to check your draft.
        If the tool says 'false', REWRITE and CHECK AGAIN.
        Only output the final text when it is compliant.
        """
    )
    return agent

def create_integrated_workflow(model_name=MODEL_NAME):
    """
    Creates the complete workflow using SequentialAgent and LoopAgent.
    
    Structure:
    SequentialAgent
      |-> ResearcherAgent
      |-> LoopAgent (Wrapper to ensure compliance persistence if needed)
            |-> EditorAgent
    """
    researcher = create_researcher_agent(model_name)
    editor = create_editor_agent(model_name)
    
    # We wrap the Editor in a LoopAgent. 
    # In this strict usage, we define max_iterations to prevent infinite loops, 
    # relying on the Editor's internal reasoning (Planner) to fix things first.
    # The LoopAgent here serves as a 'Retry Policy' wrapper at the agent level.
    looping_editor = LoopAgent(
        name="LoopingEditorStep",
        sub_agents=[editor],
        max_iterations=1 # We mostly rely on internal planner loop, this wrapper demonstrates the class usage.
    )
    
    # Sequential Agent runs Researcher -> then LoopingEditor
    workflow = SequentialAgent(
        name="ProductLaunchWorkflow",
        sub_agents=[researcher, looping_editor]
    )
    return workflow
