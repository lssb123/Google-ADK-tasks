import random

def get_product_info(product_name: str) -> dict:
    """Retrieves detailed specifications for a given product."""
    products = {
        "SuperPhone": {"screen": "6.5 inch", "battery": "5000mAh", "camera": "108MP"},
        "UltraLaptop": {"cpu": "M3 Max", "ram": "32GB", "storage": "1TB"},
        "SmartWatch": {"sensors": ["Heart Rate", "SpO2"], "battery": "48h"}
    }
    return products.get(product_name, {"error": "Product not found"})

def get_competitor_prices(product_name: str) -> dict:
    """Fetches the current pricing of competitors for a product."""
    base_price = 1000
    if product_name == "SmartWatch": base_price = 300
    
    return {
        "CompetitorA": base_price * 0.95,
        "CompetitorB": base_price * 1.05,
        "CompetitorC": base_price * 0.98
    }

def analyze_market_sentiment(product_name: str) -> dict:
    """Analyzes social media sentiment for a product category."""
    sentiments = ["Positive", "Neutral", "Mixed", "Rising Interest"]
    return {
        "sentiment": random.choice(sentiments),
        "score": random.randint(60, 95)
    }

def verify_policy_compliance(copy_text: str) -> dict:
    """
    Checks if marketing copy complies with company policy.
    Policy: Must not use the word 'cheap'. Must mention 'sustainable'.
    """
    issues = []
    if "cheap" in copy_text.lower():
        issues.append("Do not use the word 'cheap'. Use 'affordable' instead.")
    if "sustainable" not in copy_text.lower():
        issues.append("Must mention 'sustainable' or 'sustainability'.")
    
    if not issues:
        return {"compliant": True, "message": "Copy is compliant."}
    else:
        return {"compliant": False, "issues": issues}
