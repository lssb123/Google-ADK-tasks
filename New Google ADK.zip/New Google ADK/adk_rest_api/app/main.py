import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

# Load env variables at startup
load_dotenv()

from app.routes import router as agent_router

app = FastAPI(title="ADK Agent API")

# Enable CORS for local UI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False, # Must be False when allow_origins is ["*"]
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(agent_router)

@app.get("/")
def health_check():
    return {"status": "ok", "message": "ADK Agent API is running"}

if __name__ == "__main__":
    if not os.environ.get("GOOGLE_API_KEY"):
         print("WARNING: GOOGLE_API_KEY not set in .env. Agents may fail.")
         
    uvicorn.run("app.main:app", host="0.0.0.0", port=8008, reload=True)
