def get_product_specs(product_name: str):
    """Retrieves technical specifications for a product."""
    # Mock data for demonstration
    specs = {
        "SuperPhone": {
            "battery": "5000mAh",
            "processor": "Tensor G4",
            "screen": "6.7 inch OLED",
            "camera": "50MP Main"
        },
        "UltraLaptop": {
            "battery": "100Wh",
            "processor": "M3 Max",
            "screen": "16 inch Mini-LED"
        }
    }
    return specs.get(product_name, {"error": "Product not found. Try 'SuperPhone' or 'UltraLaptop'."})

def verify_compliance(text: str):
    """
    Checks marketing copy for policy compliance.
    Policy: 
    1. Must NOT contain the word 'cheap'.
    2. Must contain the word 'premium'.
    3. Must be under 280 characters.
    """
    errors = []
    lower_text = text.lower()
    
    if "cheap" in lower_text:
        errors.append("Validation Error: Do not use the word 'cheap'. Use 'affordable' or 'value'.")
    
    if "premium" not in lower_text:
        errors.append("Validation Error: Must include the word 'premium' to describe the product.")
        
    if len(text) > 280:
        errors.append(f"Validation Error: Text is too long ({len(text)} chars). Must be under 280 characters.")
        
    if errors:
        return {"compliant": False, "errors": errors}
        
    return {"compliant": True, "message": "Text is compliant."}
