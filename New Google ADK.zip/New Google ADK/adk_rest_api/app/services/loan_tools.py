import random

# Mock Database
LOANS_DB = {
    "loan_001": {"applicant": "John Doe", "amount": 50000, "purpose": "Home Renovation", "status": "Pending"},
    "loan_002": {"applicant": "Jane Smith", "amount": 120000, "purpose": "Business Startup", "status": "Pending"},
    "loan_003": {"applicant": "Bob Wilson", "amount": 5000, "purpose": "Vacation", "status": "Pending"}
}

def get_loan_details(loan_id: str):
    """Retrieves basic details about a specific loan application."""
    return LOANS_DB.get(loan_id, {"error": "Loan not found"})

def get_credit_score(applicant_name: str):
    """Fetches the applicant's credit score from the bureau."""
    # Simulation
    scores = {
        "John Doe": 720,
        "Jane Smith": 650, # High Risk
        "Bob Wilson": 800
    }
    return {"applicant": applicant_name, "score": scores.get(applicant_name, 700)}

def analyze_debt_to_income(applicant_name: str):
    """Calculates the Debt-to-Income (DTI) ratio."""
    # Simulation
    dtis = {
        "John Doe": 0.30, # Healthy
        "Jane Smith": 0.55, # Risky
        "Bob Wilson": 0.10
    }
    return {"applicant": applicant_name, "dti_ratio": dtis.get(applicant_name, 0.40)}
