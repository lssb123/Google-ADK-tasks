from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from app.agents.registry import AGENT_REGISTRY
import json
import asyncio

# Ensure agents are loaded
import app.agents 

router = APIRouter()

class InteractionRequest(BaseModel):
    query: str
    user_id: str = "default_user"
    session_id: str = "default_session"

# Mock endpoint to list loans (for the UI)
from app.services.loan_tools import LOANS_DB
@router.get("/loans")
def get_loans():
    return {"loans": [{"id": k, **v} for k, v in LOANS_DB.items()]}

# 2. Endpoint: Provide info of all agents
@router.get("/agents/info")
def get_agents_info():
    """Returns a list of all available agents and their descriptions."""
    info = {
        name: meta["description"] 
        for name, meta in AGENT_REGISTRY.items()
    }
    return {"available_agents": info}

# 1. Endpoint: Call specific agent
@router.post("/agents/{agent_name}")
async def call_agent(agent_name: str, request: InteractionRequest):
    """Executes a specific agent by name."""
    
    if agent_name not in AGENT_REGISTRY:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Instantiate the agent on demand
    agent_builder = AGENT_REGISTRY[agent_name]["builder"]
    agent_instance = agent_builder()
    
    # Setup ADK Runner
    session_service = InMemorySessionService()
    runner = Runner(
        agent=agent_instance,
        session_service=session_service,
        app_name=f"api_{agent_name}",
        auto_create_session=True
    )
    
    # Construct Message
    content = types.Content(role='user', parts=[types.Part(text=request.query)])
    
    # Run Agent
    # For simplicity, we want the final response text.
    response_text = ""
    try:
        async for event in runner.run_async(
            user_id=request.user_id, 
            session_id=request.session_id, 
            new_message=content
        ):
            pass # Consume events
            
        # Extract response from session history
        session = await session_service.get_session(
            app_name=runner.app_name, 
            user_id=request.user_id, 
            session_id=request.session_id
        )
        
        # Traverse backwards to find the last model message
        if hasattr(session, 'events') and session.events:
             for e in reversed(session.events):
                if hasattr(e, 'content') and e.content and \
                   hasattr(e.content, 'role') and e.content.role == 'model':
                        parts = []
                        if hasattr(e.content, 'parts') and e.content.parts:
                            for p in e.content.parts:
                                if hasattr(p, 'text') and p.text:
                                    parts.append(p.text)
                        if parts:
                            response_text = "\n".join(parts)
                            break
                            
    except Exception as e:
        import traceback
        traceback_str = traceback.format_exc()
        print(f"Error executing agent {agent_name}: {traceback_str}")
        # Return error details to client for debugging
        raise HTTPException(status_code=500, detail=f"Agent Execution Error: {str(e)}")
        
    if not response_text:
        return {"status": "completed_no_output", "agent": agent_name}

    return {"status": "success", "agent": agent_name, "response": response_text}

async def event_generator(agent_name: str, query: str, user_id: str, session_id: str):
    """
    Generator that yields SSE (Server-Sent Events) from the Agent Runner.
    Format: data: <json>\n\n
    """
    
    if agent_name not in AGENT_REGISTRY:
        yield f"data: {json.dumps({'error': 'Agent not found'})}\n\n"
        return

    # Instantiate
    agent_builder = AGENT_REGISTRY[agent_name]["builder"]
    agent_instance = agent_builder()
    
    # Setup Runner
    session_service = InMemorySessionService()
    runner = Runner(
        agent=agent_instance,
        session_service=session_service,
        app_name=f"api_{agent_name}",
        auto_create_session=True
    )
    
    content = types.Content(role='user', parts=[types.Part(text=query)])
    
    try:
        async for event in runner.run_async(
            user_id=user_id, 
            session_id=session_id, 
            new_message=content
        ):
            # Serialize ADK Event to JSON
            # Event attributes: author, content (types.Content), etc.
            
            # Simple serialization strategy
            evt_data = {
                "author": event.author,
                # 'content' is complex, let's extract text parts
                "text": "",
                "tool_calls": [],
                "thought": False 
            }
            
            # Extract Text
            if hasattr(event, "content") and event.content:
                if hasattr(event.content, "parts"):
                    for part in event.content.parts:
                        if hasattr(part, "text") and part.text:
                            evt_data["text"] += part.text
                        if hasattr(part, "thought") and part.thought:
                            evt_data["thought"] = True  
                            
            # ToDo: Extract Function Calls if needed for UI, currently text is primary focus
            
            yield f"data: {json.dumps(evt_data)}\n\n"
            
        yield f"data: {json.dumps({'status': 'completed'})}\n\n"
        
    except Exception as e:
        import traceback
        yield f"data: {json.dumps({'error': str(e), 'details': traceback.format_exc()})}\n\n"


@router.get("/agents/{agent_name}/stream")
async def stream_agent(agent_name: str, query: str, user_id: str = "default_user", session_id: str = "default_session"):
    """
    Streaming endpoint for agent interactions.
    Use with EventSource in JS.
    """
    return StreamingResponse(
        event_generator(agent_name, query, user_id, session_id),
        media_type="text/event-stream"
    )
