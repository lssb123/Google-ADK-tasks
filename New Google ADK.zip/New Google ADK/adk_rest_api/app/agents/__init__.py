# This file makes 'app.agents' a package and auto-discovers agents.
import pkgutil
import importlib
import os

# Walk through the current directory and import all modules.
# This triggers the @register_agent decorators in those files.
package_dir = os.path.dirname(__file__)
for _, module_name, _ in pkgutil.iter_modules([package_dir]):
    if module_name != "registry":
        importlib.import_module(f".{module_name}", __package__)
