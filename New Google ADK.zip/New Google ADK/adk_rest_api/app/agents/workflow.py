from google.adk.agents.llm_agent import LlmAgent
from google.adk.agents.sequential_agent import SequentialAgent
from google.adk.agents.loop_agent import LoopAgent
from google.adk.planners import BuiltInPlanner
from google.genai.types import ThinkingConfig
from app.agents.registry import register_agent
from app.services.workflow_tools import get_product_specs, verify_compliance

@register_agent(name="product_launch_workflow", description="Sequential workflow: Researcher -> Looping Editor (Compliance Check)")
def build_product_launch_workflow(model_name: str = "gemini-2.5-flash"):
    """
    Builds a complex workflow:
    1. Researcher (Sequential): Gathers product specs.
    2. Editor (Loop): Generates and iteratively fixes marketing copy until compliant.
    """
    
    thinking_config = ThinkingConfig(include_thoughts=True, thinking_budget=1024)
    planner = BuiltInPlanner(thinking_config=thinking_config)

    # 1. Researcher Agent
    # Responsibility: Get facts about the product.
    researcher = LlmAgent(
        name="Researcher",
        model=model_name,
        planner=planner,
        tools=[get_product_specs],
        instruction="""
        You are a generic Researcher. 
        Your goal is to retrieve the technical specifications for the product mentioned by the user.
        Use the 'get_product_specs' tool.
        Output a summary of the specs.
        """
    )

    # 2. Editor Agent
    # Responsibility: Write copy. This agent will be wrapped in a loop.
    editor = LlmAgent(
        name="Editor",
        model=model_name,
        planner=planner,
        tools=[verify_compliance],
        instruction="""
        You are a Marketing Editor.
        Your goal is to write a social media post (tweet) based on the specs provided by the Researcher.
        
        CRITICAL INSTRUCTIONS:
        1. Write a draft.
        2. ALWAYS use the 'verify_compliance' tool to check your draft.
        3. If 'verify_compliance' returns errors, you MUST REWRITE the text to fix them and check again.
        4. If 'verify_compliance' returns compliant=True, just output the final text.
        
        Do not output the final text unless it is compliant.
        """
    )

    # 3. Looping Wrapper for Editor
    # This ensures the Editor keeps trying if it fails compliance, up to max_iterations.
    looping_editor = LoopAgent(
        name="LoopingEditor",
        sub_agents=[editor],
        max_iterations=5
    )

    # 4. Sequential Workflow
    # Connects Researcher -> Looping Editor
    workflow = SequentialAgent(
        name="ProductLaunchWorkflow",
        sub_agents=[researcher, looping_editor]
    )

    return workflow
