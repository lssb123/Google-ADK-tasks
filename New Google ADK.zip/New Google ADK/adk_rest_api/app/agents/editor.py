from google.adk.agents.llm_agent import LlmAgent
from google.adk.planners import BuiltInPlanner
from google.genai.types import ThinkingConfig
from app.agents.registry import register_agent
from app.services.storage_tools import upload_to_gcs

@register_agent(name="marketing_editor", description="Writes marketing copy and uploads to GCS.")
def build_editor_agent(model_name: str = "gemini-2.5-flash"):
    thinking_config = ThinkingConfig(include_thoughts=True, thinking_budget=512)
    planner = BuiltInPlanner(thinking_config=thinking_config)
    
    return LlmAgent(
        name="MarketingEditor",
        model=model_name,
        planner=planner,
        # Injected 'upload_to_gcs' service as a tool
        tools=[upload_to_gcs],
        instruction="""
        You are a Marketing Editor.
        1. Write a short marketing tweet about the user's topic.
        2. UPLOAD the tweet text using `upload_to_gcs` (filename: tweet.txt).
        """
    )
