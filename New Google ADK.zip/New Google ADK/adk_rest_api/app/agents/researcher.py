from google.adk.agents.llm_agent import LlmAgent
from google.adk.planners import BuiltInPlanner
from google.genai.types import ThinkingConfig
from app.agents.registry import register_agent
from app.services.storage_tools import save_research_to_db

# Local tools
def get_specs(product: str):
    return f"Specs for {product}: High-end features."

@register_agent(name="researcher", description="Gathers information and saves it to DB.")
def build_researcher_agent(model_name: str = "gemini-2.5-flash"):
    thinking_config = ThinkingConfig(include_thoughts=True, thinking_budget=512)
    planner = BuiltInPlanner(thinking_config=thinking_config)
    
    return LlmAgent(
        name="ResearcherAgent",
        model=model_name,
        planner=planner,
        # Injected 'save_research_to_db' service as a tool
        tools=[get_specs, save_research_to_db],
        instruction="""
        You are a Researcher. 
        1. Find specs for the product.
        2. SAVE the found specs using the `save_research_to_db` tool.
        3. Return a summary.
        """
    )
