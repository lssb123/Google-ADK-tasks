# Registry pattern for agents
from typing import Callable, Dict, Any

# Dictionary to hold agent info: { "name": { "builder": func, "description": str } }
AGENT_REGISTRY: Dict[str, Dict[str, Any]] = {}

def register_agent(name: str, description: str):
    """Decorator to register an agent builder function."""
    def decorator(builder_func: Callable):
        AGENT_REGISTRY[name] = {
            "builder": builder_func,
            "description": description
        }
        return builder_func
    return decorator
