### Start ADK Web Interface Server

Source: https://google.github.io/adk-docs/get-started/python

Launches the ADK web user interface server on a specified port, providing a chat-based interface for testing agents. Must be run from the parent directory containing agent projects and is intended for development and debugging only.

```bash
adk web --port 8000
```

--------------------------------

### Install and Run Development Server

Source: https://google.github.io/adk-docs/tools/third-party/ag-ui

These commands install project dependencies and start the development server, allowing you to test your AG-UI application locally.

```bash
npm install && npm run dev

```

--------------------------------

### Install Google ADK Python Library with A2A Dependencies

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This command installs the `google-adk` Python library, including its A2A-specific dependencies, into your current environment. It ensures that all necessary packages required for developing and running A2A agents are available.

```bash
pip install google-adk[a2a]
```

--------------------------------

### Install ADK Package and Configure Gemini API Key in Python

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

This snippet provides the necessary setup instructions for running ADK (Agent Development Kit) examples in a Python environment. It covers installing the `google-adk` package using pip and setting up the `GOOGLE_API_KEY` environment variable, which is crucial for authenticating with Google AI services like Gemini.

Dependencies: Python 3 environment.
Inputs: Your Google AI Studio API key.
Outputs: `google-adk` package installed, `GOOGLE_API_KEY` set in the current process's environment variables.

```Python
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# # --- Setup Instructions ---
# # 1. Install the ADK package:
!pip install google-adk
# # Make sure to restart kernel if using colab/jupyter notebooks

# # 2. Set up your Gemini API Key:
# #    - Get a key from Google AI Studio: https://aistudio.google.com/app/apikey
# #    - Set it as an environment variable:
import os
os.environ["GOOGLE_API_KEY"] = "YOUR_API_KEY_HERE" # <--- REPLACE with your actual key
```

--------------------------------

### Example ADK TypeScript package.json Configuration

Source: https://google.github.io/adk-docs/get-started/typescript

This 'package.json' example shows the expected configuration after installing ADK dependencies. It defines project metadata, sets 'agent.ts' as the main entry, and lists 'typescript', '@google/adk', and '@google/adk-devtools' as dependencies.

```json
{
  "name": "my-agent",
  "version": "1.0.0",
  "description": "My ADK Agent",
  "main": "agent.ts",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "devDependencies": {
    "typescript": "^5.9.3"
  },
  "dependencies": {
    "@google/adk": "^0.2.0",
    "@google/adk-devtools": "^0.2.0"
  }
}
```

--------------------------------

### Navigate to a2a_basic sample directory in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming-go

Changes to the a2a_basic example directory to access the multi-agent system sample code. This directory contains the main root agent and remote prime agent implementations.

```bash
cd examples/go/a2a_basic
```

--------------------------------

### Initialize Go Modules and Install Dependencies

Source: https://google.github.io/adk-docs/get-started/go

Initializes Go module management for the ADK agent project and resolves all import dependencies. Executes go mod init to create module configuration and go mod tidy to download and manage required packages based on import statements.

```bash
go mod init my-agent/main
go mod tidy
```

--------------------------------

### Install Agent Development Kit - Go

Source: https://google.github.io/adk-docs/index

Install the Google ADK package for Go using the go get command. This retrieves the ADK module from the Google Go package repository.

```shell
go get google.golang.org/adk
```

--------------------------------

### LlmAgent.Builder - exampleProvider(Example... examples)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example

Sets multiple examples for the LlmAgent using varargs. This method accepts a variable number of Example objects to configure the agent with example data.

```APIDOC
## LlmAgent.Builder.exampleProvider(Example... examples)

### Description
Configures the LlmAgent with one or more examples using variable arguments. This method allows flexible example provision to the agent builder.

### Method
Builder Method (Fluent API)

### Class
LlmAgent.Builder

### Parameters
#### Method Parameters
- **examples** (Example...) - Required - Variable number of Example objects to provide to the agent

### Return Type
`LlmAgent.Builder` - Returns the builder instance for method chaining

### Usage Example
```java
LlmAgent.Builder builder = new LlmAgent.Builder();
builder.exampleProvider(example1, example2, example3);
```

### Related Methods
- `LlmAgent.Builder.exampleProvider(List<Example> examples)` - Alternative method accepting a List
```

--------------------------------

### Install ADK TypeScript Project Dependencies

Source: https://google.github.io/adk-docs/get-started/typescript

This sequence of 'npm' and 'npx' commands initializes a Node.js project, installs TypeScript as a dev dependency, configures 'tsconfig.json', and then installs the core '@google/adk' and '@google/adk-devtools' libraries as project dependencies.

```bash
cd my-agent/
# initialize a project with default values
npm init --yes
# configure TypeScript
npm install -D typescript
npx tsc --init
# install ADK libraries
npm install @google/adk
npm install @google/adk-devtools
```

--------------------------------

### Run ADK Agent with Web Interface Using Maven

Source: https://google.github.io/adk-docs/get-started/java

Start the ADK web server using Maven to provide a chat interface for your agent accessible at http://localhost:8000. This command compiles the project and runs the AdkWebServer with specified configuration for development and debugging only.

```bash
# Remember to load keys and settings: source .env OR env.bat
mvn compile exec:java \
    -Dexec.mainClass="com.google.adk.web.AdkWebServer" \
    -Dexec.args="--adk.agents.source-dir=target --server.port=8000"
```

--------------------------------

### Setup A2A Web Launcher and Server Configuration in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing-go

Initializes the A2A web launcher on port 8001 and creates the ADK configuration with a single agent loader and in-memory session service. The launcher dynamically generates the agent card and handles incoming A2A requests. Includes error handling for launcher parsing and execution.

```go
port := 8001
webLauncher := web.NewLauncher(a2a.NewLauncher())
_, err = webLauncher.Parse([]string{
    "--port", strconv.Itoa(port),
    "a2a", "--a2a_agent_url", "http://localhost:" + strconv.Itoa(port),
})
if err != nil {
    log.Fatalf("launcher.Parse() error = %v", err)
}

config := &launcher.Config{
    AgentLoader:    agent.NewSingleLoader(primeAgent),
    SessionService: session.InMemoryService(),
}

log.Printf("Starting A2A prime checker server on port %d\n", port)
if err := webLauncher.Run(context.Background(), config); err != nil {
    log.Fatalf("webLauncher.Run() error = %v", err)
}
```

--------------------------------

### LlmAgent.Builder - exampleProvider(List<Example> examples)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example

Sets examples for the LlmAgent using a List collection. This method provides an alternative to the varargs version for providing multiple examples.

```APIDOC
## LlmAgent.Builder.exampleProvider(List<Example> examples)

### Description
Configures the LlmAgent with a list of examples. This method accepts a List collection of Example objects to configure the agent.

### Method
Builder Method (Fluent API)

### Class
LlmAgent.Builder

### Parameters
#### Method Parameters
- **examples** (List<Example>) - Required - List of Example objects to provide to the agent

### Return Type
`LlmAgent.Builder` - Returns the builder instance for method chaining

### Usage Example
```java
List<Example> exampleList = Arrays.asList(example1, example2, example3);
LlmAgent.Builder builder = new LlmAgent.Builder();
builder.exampleProvider(exampleList);
```

### Related Methods
- `LlmAgent.Builder.exampleProvider(Example... examples)` - Alternative method accepting varargs
```

--------------------------------

### Launch ADK Web Server - Bash Command

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Start the ADK web server in a separate terminal to launch the development UI. This command runs the web server on the specified samples directory and makes it accessible at http://localhost:8000 for interacting with the root agent.

```bash
adk web contributing/samples/
```

--------------------------------

### Complete ADKPython Agent Example with BuiltInPlanner and Tools

Source: https://google.github.io/adk-docs/agents/llm-agents

A comprehensive example demonstrating the setup of an `LlmAgent` using `BuiltInPlanner` and custom tools (`get_weather`, `get_current_time`). It shows how to define `ThinkingConfig` to enable and budget model thoughts, and then integrate the planner and tools into the agent for handling user queries.

```python
from dotenv import load_dotenv


import asyncio
import os

from google.genai import types
from google.adk.agents.llm_agent import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts.in_memory_artifact_service import InMemoryArtifactService # Optional
from google.adk.planners import BasePlanner, BuiltInPlanner, PlanReActPlanner
from google.adk.models import LlmRequest

from google.genai.types import ThinkingConfig
from google.genai.types import GenerateContentConfig

import datetime
from zoneinfo import ZoneInfo

APP_NAME = "weather_app"
USER_ID = "1234"
SESSION_ID = "session1234"

def get_weather(city: str) -> dict:
    """Retrieves the current weather report for a specified city.

    Args:
        city (str): The name of the city for which to retrieve the weather report.

    Returns:
        dict: status and result or error msg.
    """
    if city.lower() == "new york":
        return {
            "status": "success",
            "report": (
                "The weather in New York is sunny with a temperature of 25 degrees"
                " Celsius (77 degrees Fahrenheit)."
            ),
        }
    else:
        return {
            "status": "error",
            "error_message": f"Weather information for '{city}' is not available.",
        }


def get_current_time(city: str) -> dict:
    """Returns the current time in a specified city.

    Args:
        city (str): The name of the city for which to retrieve the current time.

    Returns:
        dict: status and result or error msg.
    """

    if city.lower() == "new york":
        tz_identifier = "America/New_York"
    else:
        return {
            "status": "error",
            "error_message": (
                f"Sorry, I don't have timezone information for {city}."
            ),
        }

    tz = ZoneInfo(tz_identifier)
    now = datetime.datetime.now(tz)
    report = (
        f'The current time in {city} is {now.strftime("%Y-%m-%d %H:%M:%S %Z%z")}'
    )
    return {"status": "success", "report": report}

# Step 1: Create a ThinkingConfig
thinking_config = ThinkingConfig(
    include_thoughts=True,   # Ask the model to include its thoughts in the response
    thinking_budget=256      # Limit the 'thinking' to 256 tokens (adjust as needed)
)
print("ThinkingConfig:", thinking_config)

# Step 2: Instantiate BuiltInPlanner
planner = BuiltInPlanner(
    thinking_config=thinking_config
)
print("BuiltInPlanner created.")

# Step 3: Wrap the planner in an LlmAgent
agent = LlmAgent(
    model="gemini-2.5-pro-preview-03-25",  # Set your model name
    name="weather_and_time_agent",
    instruction="You are an agent that returns time and weather",
    planner=planner,
    tools=[get_weather, get_current_time]
)
```

--------------------------------

### BaseExampleProvider - getExamples(String query)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example

Retrieves a list of Example objects based on a query string. This method queries the example provider for relevant examples matching the given criteria.

```APIDOC
## BaseExampleProvider.getExamples(String query)

### Description
Retrieves a list of Example objects that match the provided query string. This method searches the example provider for relevant examples.

### Method
GET (Query Method)

### Class
BaseExampleProvider

### Parameters
#### Method Parameters
- **query** (String) - Required - Query string to filter and retrieve matching examples

### Return Type
`List<Example>` - Returns a list of Example objects matching the query

### Usage Example
```java
BaseExampleProvider provider = new BaseExampleProvider();
List<Example> results = provider.getExamples("search query");
```

### Response
#### Success Response
- **List<Example>** - Collection of Example objects matching the query criteria
  - May be empty if no matches are found
  - Order and filtering depend on provider implementation

### Notes
- Query parameter is case-sensitive unless otherwise specified by implementation
- Returns an empty list if no examples match the query
- Concrete implementations may vary in search behavior
```

--------------------------------

### Java: Configure LLM Agent with Guardrail Example Setup

Source: https://google.github.io/adk-docs/callbacks

Sets up a Java-based example with a Gemini model, defines model ID, app name, and user ID constants. The BeforeModelGuardrailExample class demonstrates how to initialize and run an agent with guardrail callbacks by passing a test user prompt to the agent.

```Java
public class BeforeModelGuardrailExample {

  private static final String MODEL_ID = "gemini-2.0-flash";
  private static final String APP_NAME = "guardrail_app";
  private static final String USER_ID = "user_1";

  public static void main(String[] args) {
    BeforeModelGuardrailExample example = new BeforeModelGuardrailExample();
    example.defineAgentAndRun("Tell me about quantum computing. This is a test.");
  }
```

--------------------------------

### Initial ADK Project File Structure Example

Source: https://google.github.io/adk-docs/deploy/agent-engine/asp

This snippet illustrates the typical starting file structure of an ADK project, using 'multi_tool_agent' as a reference. It shows the core Python files like `__init__.py` and `agent.py`, along with a `.env` file for environment variables, before any modifications by the ASP tools.

```plaintext
multi_tool_agent/
├─ __init__.py
├─ agent.py
└─ .env
```

--------------------------------

### Initialize MCPToolset and Get Tools (TypeScript)

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/MCPToolset

This example demonstrates how to import necessary classes, define connection parameters for an MCP server, instantiate the `MCPToolset`, and asynchronously retrieve the list of available tools. It shows a common setup for connecting to a local MCP server.

```typescript
import { MCPToolset } from '@google/adk';
import { StreamableHTTPConnectionParamsSchema } from '@google/adk';

const connectionParams = StreamableHTTPConnectionParamsSchema.parse({ type: "StreamableHTTPConnectionParams", url: "http://localhost:8788/mcp" });
const mcpToolset = new MCPToolset(connectionParams);
const tools = await mcpToolset.getTools();
```

--------------------------------

### Install Agent Development Kit - Python

Source: https://google.github.io/adk-docs/index

Install the Google ADK package for Python using pip package manager. This is the recommended way to get started with ADK in Python environments.

```shell
pip install google-adk
```

--------------------------------

### Create Go module and install ADK

Source: https://google.github.io/adk-docs/get-started/installation

Initialize a new Go module and add Google ADK as a dependency using go get. This updates the go.mod file with the ADK dependency.

```bash
go mod init example.com/my-agent
```

```bash
go get google.golang.org/adk
```

--------------------------------

### Build Few-Shot Example String in Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/ExampleUtils

Static method that constructs a formatted few-shot example string from a BaseExampleProvider and user query. Takes an example provider as the source of examples and a query string as input, returning a formatted string containing the few-shot examples for use in prompt engineering or AI model contexts.

```java
public static String buildExampleSi(BaseExampleProvider exampleProvider, String query)
Builds a formatted few-shot example string for the given query.

Parameters:
    exampleProvider - Source of examples.
    query - User query.

Returns:
    formatted string with few-shot examples.
```

--------------------------------

### Run ADK Web Server Command

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Command to start the ADK web server for hosting sample agents. Runs the server with the contributing/samples directory as the source location, enabling the main consuming agent to access remote agents via the A2A Protocol.

```bash
adk web contributing/samples/
```

--------------------------------

### SseServerParameters.Builder - Complete Configuration Example

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/mcp/SseServerParameters.Builder

A comprehensive example demonstrating how to use the SseServerParameters.Builder to configure all available SSE connection parameters in a fluent builder pattern.

```APIDOC
## SseServerParameters.Builder - Complete Configuration

### Description
Complete example of building SseServerParameters with all configuration options.

### Full Example
```java
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

// Create headers map
Map<String, Object> headers = new HashMap<>();
headers.put("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");
headers.put("Accept", "text/event-stream");
headers.put("Cache-Control", "no-cache");

// Build SseServerParameters with all settings
SseServerParameters sseParams = new SseServerParameters.Builder()
  .url("https://api.example.com/v1/events")
  .headers(headers)
  .timeout(Duration.ofSeconds(30))
  .sseReadTimeout(Duration.ofMinutes(5))
  .build();

// Use the configured parameters
// sseClient.connect(sseParams);
```

### Configuration Details
- **URL**: The SSE server endpoint to connect to
- **Headers**: Custom HTTP headers sent with the connection request
- **Timeout**: Maximum wait time for initial connection (30 seconds)
- **SSE Read Timeout**: Maximum wait time between data packets (5 minutes)
```

--------------------------------

### Clone ADK Python Repository

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Clone the google/adk-python repository to access sample code and examples. This command retrieves the complete ADK Python project including the a2a_basic sample.

```bash
git clone https://github.com/google/adk-python.git
```

--------------------------------

### Install ADK with A2A Support - Python

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Install the google-adk package with A2A protocol support using pip. This command installs the necessary dependencies for building Agent2Agent applications in Python.

```bash
pip install google-adk[a2a]
```

--------------------------------

### Example.Builder - build()

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example

Constructs and returns an Example instance from the builder configuration. This is the terminal operation of the Example builder pattern.

```APIDOC
## Example.Builder.build()

### Description
Builds and returns a configured Example object. This abstract method completes the builder pattern for creating Example instances.

### Method
Builder Terminal Method

### Class
Example.Builder

### Parameters
None

### Return Type
`abstract Example` - Returns a newly constructed Example instance

### Usage Example
```java
Example example = new Example.Builder()
  .withField("value")
  .build();
```

### Notes
- This is an abstract method that must be implemented by concrete builder subclasses
- Represents the terminal operation in the builder pattern
- Returns an immutable Example instance
```

--------------------------------

### Start ADK Remote A2A Agent Server with Uvicorn

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This command initiates the remote A2A agent server using Uvicorn. It specifies the path to the `a2a_app` instance within the `hello_world` agent, binds the server to `localhost`, and sets the listening port to `8001` for local testing.

```bash
uvicorn contributing.samples.a2a_root.remote_a2a.hello_world.agent:a2a_app --host localhost --port 8001
```

--------------------------------

### Run ADK Agent with Command-Line Interface

Source: https://google.github.io/adk-docs/get-started/go

Executes the ADK agent using Go's run command from the project directory. Requires loading environment variables from .env or env.bat before execution. Provides an interactive command-line interface for testing the agent.

```bash
# Remember to load keys and settings: source .env OR env.bat
go run agent.go
```

--------------------------------

### Run ADK Agent with Command-Line Interface Using Maven

Source: https://google.github.io/adk-docs/get-started/java

Execute the AgentCliRunner class using Maven to start an interactive command-line interface for testing and interacting with your ADK agent. Requires loading environment variables from .env or env.bat file first.

```bash
# Remember to load keys and settings: source .env OR env.bat
mvn compile exec:java -Dexec.mainClass="com.example.agent.AgentCliRunner"
```

--------------------------------

### Install Agent Development Kit - TypeScript/Node.js

Source: https://google.github.io/adk-docs/index

Install the Google ADK package for TypeScript and Node.js using npm package manager. This enables ADK functionality in JavaScript/TypeScript projects.

```shell
npm install @google/adk
```

--------------------------------

### Run ADK Agent with Web Interface

Source: https://google.github.io/adk-docs/get-started/go

Launches the ADK agent with a web-based chat interface accessible at localhost:8080. Requires loading environment variables before execution. The web interface allows agent selection and request input, but is intended for development and debugging only, not production deployments.

```bash
# Remember to load keys and settings: source .env OR env.bat
go run agent.go web api webui
```

--------------------------------

### Configure Agent Development Kit - Java Gradle

Source: https://google.github.io/adk-docs/index

Add the Google ADK dependency to a Gradle project's build.gradle file. This configuration specifies version 0.5.0 of the google-adk library for implementation.

```gradle
dependencies {
    implementation 'com.google.adk:google-adk:0.5.0'
}
```

--------------------------------

### Run ADK TypeScript Agent via Command Line

Source: https://google.github.io/adk-docs/get-started/typescript

This command executes the ADK TypeScript agent using the '@google/adk-devtools' command-line interface. It starts the agent in an interactive CLI mode for testing and interaction.

```bash
npx @google/adk-devtools run agent.ts
```

--------------------------------

### Create Project Structure - macOS/Linux

Source: https://google.github.io/adk-docs/get-started/go

Creates the basic directory structure and files for an ADK agent project on Unix-like systems. Uses standard bash commands (mkdir, touch) to establish the project folder, agent code file, and environment configuration file.

```bash
mkdir -p my_agent/ && \
    touch my_agent/agent.go && \
    touch my_agent/.env
```

--------------------------------

### Configure Agent Development Kit - Java Maven

Source: https://google.github.io/adk-docs/index

Add the Google ADK dependency to a Maven project's pom.xml file. This configuration specifies version 0.5.0 of the google-adk artifact from the com.google.adk group.

```xml
<dependency>
    <groupId>com.google.adk</groupId>
    <artifactId>google-adk</artifactId>
    <version>0.5.0</version>
</dependency>
```

--------------------------------

### Setup Runner and Session (Java)

Source: https://google.github.io/adk-docs/agents/custom-agents

Initializes an InMemoryRunner with the StoryFlowAgent and creates a HashMap for initial state containing the topic. Java implementation of runner and session setup.

```java
public static void runAgent(StoryFlowAgentExample agent, String userTopic) {
  InMemoryRunner runner = new InMemoryRunner(agent);
  Map<String, Object> initialState = new HashMap<>();
```

--------------------------------

### Uvicorn Server Startup Console Output

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This snippet displays the expected console output upon successful startup of the Uvicorn server hosting an ADK A2A agent. It confirms that the server process has started, the application is operational, and it's listening on the specified host and port.

```plaintext
INFO:     Started server process [10615]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://localhost:8001 (Press CTRL+C to quit)
```

--------------------------------

### Define Basic Go Agent with Gemini API and Google Search

Source: https://google.github.io/adk-docs/get-started/go

Creates a basic ADK agent in Go that integrates with the Gemini API model and includes the built-in Google Search tool. The agent is configured with a name, description, system instruction, and initialized through a launcher that provides both CLI and web interfaces. Requires GOOGLE_API_KEY environment variable and ADK Go v0.2.0 or later.

```go
package main

import (
    "context"
    "log"
    "os"

    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/cmd/launcher"
    "google.golang.org/adk/cmd/launcher/full"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/geminitool"
    "google.golang.org/genai"
)

func main() {
    ctx := context.Background()

    model, err := gemini.NewModel(ctx, "gemini-3-pro-preview", &genai.ClientConfig{
        APIKey: os.Getenv("GOOGLE_API_KEY"),
    })
    if err != nil {
        log.Fatalf("Failed to create model: %v", err)
    }

    timeAgent, err := llmagent.New(llmagent.Config{
        Name:        "hello_time_agent",
        Model:       model,
        Description: "Tells the current time in a specified city.",
        Instruction: "You are a helpful assistant that tells the current time in a city.",
        Tools: []tool.Tool{
            geminitool.GoogleSearch{},
        },
    })
    if err != nil {
        log.Fatalf("Failed to create agent: %v", err)
    }

    config := &launcher.Config{
        AgentLoader: agent.NewSingleLoader(timeAgent),
    }

    l := full.NewLauncher()
    if err = l.Execute(ctx, config, os.Args[1:]); err != nil {
        log.Fatalf("Run failed: %v\n\n%s", err, l.CommandLineSyntax())
    }
}

```

--------------------------------

### Configure ADK Agent with Tool Instructions and Runner (Java)

Source: https://google.github.io/adk-docs/tools-custom

This Java code snippet illustrates the setup of an ADK agent. It defines the agent's operational logic through a multi-line instruction string, integrates external tools for weather reporting and sentiment analysis, and initializes a session runner to process user queries. The instructions guide the agent on when and how to use its tools based on user input and tool response statuses.

```java
                    **If the user asks about the weather in a specific city, use the
                    'get_weather_report' tool to retrieve the weather details.**
                    **If the 'get_weather_report' tool returns a 'success' status, provide the
                    weather report to the user.**
                    **If the 'get_weather_report' tool returns an 'error' status, inform the
                    user that the weather information for the specified city is not available
                    and ask if they have another city in mind.**
                    **After providing a weather report, if the user gives feedback on the
                    weather (e.g., 'That's good' or 'I don't like rain'), use the
                    'analyze_sentiment' tool to understand their sentiment.** Then, briefly
                    acknowledge their sentiment.
                    You can handle these tasks sequentially if needed.
                    """)
            .tools(ImmutableList.of(weatherTool, sentimentTool))
            .build();

    InMemorySessionService sessionService = new InMemorySessionService();
    Runner runner = new Runner(weatherSentimentAgent, APP_NAME, null, sessionService);

    // Change the query to ensure the tool is called with a valid city that triggers a "success"
    // response from the tool, like "london" (without the question mark).
    callAgent(runner, "weather in paris");
  }
}
```

--------------------------------

### Start Remote A2A Server with Debug Logging

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Start an ADK API server with debug-level logging enabled for the remote prime agent. The --log_level debug flag provides richer logs for inspection and troubleshooting during agent testing.

```bash
adk api_server --a2a --port 8001 contributing/samples/a2a_basic/remote_a2a --log_level debug
```

--------------------------------

### Create Project Structure - Windows Command Line

Source: https://google.github.io/adk-docs/get-started/go

Creates the basic directory structure and files for an ADK agent project on Windows systems. Uses Windows-specific commands (mkdir and type nul) to establish the project folder, agent code file, and environment configuration file.

```batch
mkdir my_agent\
type nul > my_agent\agent.go
type nul > my_agent\env.bat
```

--------------------------------

### ADK Interactive Agent Session Example

Source: https://google.github.io/adk-docs/runtime/command-line

This example illustrates a typical interactive session with an ADK agent, showing user queries and agent responses, and how to exit the session.

```shell
Running agent my_agent, type exit to exit.
[user]: What's the weather in New York?
[my_agent]: The weather in New York is sunny with a temperature of 25°C.
[user]: exit
```

--------------------------------

### Start Remote A2A Server with Standard Logging

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Start an ADK API server exposing a remote agent via A2A protocol on port 8001. The check_prime_agent runs on this separate server instance, allowing the root agent to communicate with it remotely.

```bash
adk api_server --a2a --port 8001 contributing/samples/a2a_basic/remote_a2a
```

--------------------------------

### Initialize Session and LLM Agent with State-Injected Instruction (Go)

Source: https://google.github.io/adk-docs/sessions/state

This Go example demonstrates the complete flow for setting up an LLM agent whose instruction is dynamically populated from session state. It initializes a session with a 'topic' and then creates an LlmAgent that uses this topic in its instruction, which is then managed by a runner.

```go
func main() {
    ctx := context.Background()
    sessionService := session.InMemoryService()

    // 1. Initialize a session with a 'topic' in its state.
    _, err := sessionService.Create(ctx, &session.CreateRequest{
        AppName:   appName,
        UserID:    userID,
        SessionID: sessionID,
        State: map[string]any{
            "topic": "friendship",
        },
    })
    if err != nil {
        log.Fatalf("Failed to create session: %v", err)
    }

    // 2. Create an agent with an instruction that uses a {topic} placeholder.
    //    The ADK will automatically inject the value of "topic" from the
    //    session state into the instruction before calling the LLM.
    model, err := gemini.NewModel(ctx, modelID, nil)
    if err != nil {
        log.Fatalf("Failed to create Gemini model: %v", err)
    }
    storyGenerator, err := llmagent.New(llmagent.Config{
        Name:        "StoryGenerator",
        Model:       model,
        Instruction: "Write a short story about a cat, focusing on the theme: {topic}.",
    })
    if err != nil {
        log.Fatalf("Failed to create agent: %v", err)
    }

    r, err := runner.New(runner.Config{
        AppName:        appName,
        Agent:          agent.Agent(storyGenerator),
        SessionService: sessionService,
    })
    if err != nil {
        log.Fatalf("Failed to create runner: %v", err)
    }

}
```

--------------------------------

### Create ADK Agent Project

Source: https://google.github.io/adk-docs/get-started/python

Initializes a new ADK agent project with the specified project name. This command generates the project structure including agent.py, .env, and __init__.py files.

```bash
adk create my_agent
```

--------------------------------

### Start ADK Web with Custom Options

Source: https://google.github.io/adk-docs/runtime/web-interface

Run the ADK web interface with custom configuration options including port and session storage URI. Demonstrates how to override default settings.

```bash
adk web --port 3000 --session_service_uri "sqlite:///sessions.db"
```

--------------------------------

### Create LLM Agent with Individual and Grouped Tools in Python

Source: https://google.github.io/adk-docs/tools-custom

Python example showing LlmAgent instantiation combining an individual greet_tool with a math_toolset_instance. Specifies agent name, model (gemini-2.0-flash), and detailed instruction text for tool usage. Demonstrates the cross-language pattern for mixed tool configurations.

```python
calculator_agent = LlmAgent(
    name="CalculatorAgent",
    model="gemini-2.0-flash",
    instruction="You are a helpful calculator and greeter. "
    "Use 'greet_user' for greetings. "
    "Use 'calculator_add_numbers' to add and 'calculator_subtract_numbers' to subtract. "
    "Announce the state of 'last_math_operation' if it's set.",
    tools=[greet_tool, math_toolset_instance],
)
```

--------------------------------

### Configure LLM Agent with Before-Tool Callback (Python, TypeScript, Go, Java)

Source: https://google.github.io/adk-docs/safety

This collection of snippets demonstrates how to instantiate and configure an LLM Agent across various programming languages. A key configuration shown is the `before_tool_callback` (or `BeforeToolCallbacks` in Go, `beforeToolCallback` in TS, `beforeToolCallback` in Java). This callback allows for pre-execution validation or modification of tool parameters, enhancing control and security over agent interactions with tools. Note that the Go and Java agent setup examples are hypothetical and may be incomplete.

```python
root_agent = LlmAgent( # Use specific agent type
    model='gemini-2.0-flash',
    name='root_agent',
    instruction="...",
    before_tool_callback=validate_tool_params, # Assign the callback
    tools = [
      # ... list of tool functions or Tool instances ...
      # e.g., query_tool_instance
    ]
)
```

```typescript
const rootAgent = new LlmAgent({
    model: 'gemini-2.5-flash',
    name: 'root_agent',
    instruction: "...",
    beforeToolCallback: validateToolParams, // Assign the callback
    tools: [
      // ... list of tool functions or Tool instances ...
      // e.g., queryToolInstance
    ]
});
```

```go
// Hypothetical Agent setup
// rootAgent, err := llmagent.New(llmagent.Config{
//  Model: "gemini-2.0-flash",
//  Name: "root_agent",
//  Instruction: "...",
//  BeforeToolCallbacks: []llmagent.BeforeToolCallback{validateToolParams},
//  Tools: []tool.Tool{queryToolInstance},
// })
```

```java
// Hypothetical Agent setup
public void runAgent() {
LlmAgent agent =
    LlmAgent.builder()
        .model("gemini-2.0-flash")
```

--------------------------------

### Runner Start Callback Handler

Source: https://google.github.io/adk-docs/plugins

Executes immediately after runner.run() is called, before agent logic begins. Provides opportunity for global setup and inspection of the user message. Returns a types.Content object to replace the message or None to proceed with original.

```Python
async def before_run_callback(
    self, *, invocation_context: InvocationContext
) -> Optional[types.Content]:
```

```TypeScript
async beforeRunCallback(invocationContext: InvocationContext): Promise<Content | undefined> {
  // Your implementation here
}
```

--------------------------------

### Create Summary Agent with AgentTool and skip_summarization

Source: https://google.github.io/adk-docs/tools/function-tools

Python example demonstrating a root agent that uses a summary agent as a tool with skip_summarization=True to bypass LLM-based summarization. Includes session setup, async runner initialization, and agent interaction patterns for processing user queries.

```python
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.agent_tool import AgentTool
from google.genai import types

APP_NAME="summary_agent"
USER_ID="user1234"
SESSION_ID="1234"

summary_agent = Agent(
    model="gemini-2.0-flash",
    name="summary_agent",
    instruction="""You are an expert summarizer. Please read the following text and provide a concise summary.""",
    description="Agent to summarize text",
)

root_agent = Agent(
    model='gemini-2.0-flash',
    name='root_agent',
    instruction="""You are a helpful assistant. When the user provides a text, use the 'summarize' tool to generate a summary. Always forward the user's message exactly as received to the 'summarize' tool, without modifying or summarizing it yourself. Present the response from the tool to the user.""",
    tools=[AgentTool(agent=summary_agent, skip_summarization=True)]
)

# Session and Runner
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=root_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner


# Agent Interaction
async def call_agent_async(query):
    content = types.Content(role='user', parts=[types.Part(text=query)])
    session, runner = await setup_session_and_runner()
    events = runner.run_async(user_id=USER_ID, session_id=SESSION_ID, new_message=content)

    async for event in events:
        if event.is_final_response():
            final_response = event.content.parts[0].text
            print("Agent Response: ", final_response)


long_text = """Quantum computing represents a fundamentally different approach to computation, 
levering the bizarre principles of quantum mechanics to process information. Unlike classical computers 
that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively 
being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled, 
meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and 
interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such 
as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far 
faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages."""
```

--------------------------------

### Dockerfile for Self-Contained Stdio MCP Servers with Node.js and Python

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

This Dockerfile provides a base image for an ADK agent that uses self-contained Stdio MCP servers. It installs Node.js and npm for `npx`-based MCP servers, then installs Python dependencies from `requirements.txt`, and finally copies the agent code. This setup allows `npx` commands to run MCP servers within the same container.

```dockerfile
FROM python:3.13-slim

# Install Node.js and npm for MCP servers
RUN apt-get update && apt-get install -y nodejs npm && rm -rf /var/lib/apt/lists/*

# Install your Python dependencies
COPY requirements.txt .
RUN pip install -r requirements.txt

# Copy your agent code
COPY . .

# Your agent can now use StdioConnectionParams with 'npx' commands
CMD ["python", "main.py"]
```

--------------------------------

### Initialize Node.js Project and Install ADK - TypeScript

Source: https://google.github.io/adk-docs/grounding/vertex_ai_search_grounding

Creates a new Node.js project and installs the Google ADK TypeScript package using npm.

```bash
npm init -y
npm install @google/adk
```

--------------------------------

### Example LlmAgentConfig with Callbacks (YAML)

Source: https://google.github.io/adk-docs/api-reference/agentconfig

This snippet demonstrates a basic LlmAgentConfig using YAML. It includes an example of how to configure 'before_agent_callbacks' using a CodeConfig reference. The 'name' and 'instruction' fields are required for an LlmAgent.

```yaml
agent_class: "LlmAgent"
name: "MyLlmAgent"
description: "An example LLM agent."
instruction: "You are a helpful assistant."
before_agent_callbacks:
  - name: "my_library.security_callbacks.before_agent_callback"
    args:
      - name: "some_arg"
        value: "some_value"
after_agent_callbacks:
  - name: "my_library.logging_callbacks.after_agent_callback"
model: "gpt-4"
input_schema:
  name: "my_library.schemas.MyInputSchema"
output_schema:
  name: "my_library.schemas.MyOutputSchema"
output_key: "response"
include_contents: "default"
```

--------------------------------

### Python Example: Defining a Custom Toolset

Source: https://google.github.io/adk-docs/api-reference/agentconfig

An example demonstrating how to define a custom toolset in a Python file, which can then be referenced in the ADK configuration.

```python
# tools.py
from adk.tools import MCPToolset, StdioServerParameters

# Assuming NOTION_HEADERS is defined elsewhere
# NOTION_HEADERS = "..."

my_mcp_toolset = MCPToolset(
    connection_params=StdioServerParameters(
        command="npx",
        args=["-y", "@notionhq/notion-mcp-server"],
        env={"OPENAPI_MCP_HEADERS": "NOTION_HEADERS"},
    )
)

```

--------------------------------

### Compile ADK TypeScript Project

Source: https://google.github.io/adk-docs/get-started/typescript

This command compiles the TypeScript source code of the ADK project into JavaScript. It uses the 'npx tsc' command, leveraging the TypeScript compiler installed as a dev dependency.

```bash
npx tsc
```

--------------------------------

### Runner Start Callback

Source: https://google.github.io/adk-docs/plugins

The before_run_callback is executed when the Runner object takes the potentially modified user message and prepares for execution. This callback enables global setup and initialization before any agent logic begins, allowing inspection or modification of the message before agent processing.

```APIDOC
## before_run_callback

### Description
Callback executed when the Runner object prepares for execution. Enables global setup and initialization before any agent logic begins.

### When It Runs
Immediately after `runner.run()` is called, before any other processing.

### Purpose
Provides the first opportunity to inspect or modify the user's raw input and perform global setup.

### Flow Control
Returns a `types.Content` object to **replace** the user's original message.

### Python Signature
```python
async def before_run_callback(
    self, *, invocation_context: InvocationContext
) -> Optional[types.Content]:
    # Your implementation here
    pass
```

### TypeScript Signature
```typescript
async beforeRunCallback(invocationContext: InvocationContext): Promise<Content | undefined> {
  // Your implementation here
}
```

### Parameters
- **invocation_context** (InvocationContext) - Required - The context of the current invocation

### Returns
- **types.Content** (Optional) - Modified message content to replace the original, or undefined to keep original
```

--------------------------------

### Setup Agent Runner and Session Service

Source: https://google.github.io/adk-docs/tools-custom

Configures the runner with the main agent and in-memory session service. Creates a new session for the customer support application with user identification.

```go
sessionService := session.InMemoryService()
runner, err := runner.New(runner.Config{
    AppName:        "customer_support_agent",
    Agent:          mainAgent,
    SessionService: sessionService,
})
if err != nil {
    log.Fatal(err)
}

session, err := sessionService.Create(ctx, &session.CreateRequest{
    AppName: "customer_support_agent",
    UserID:  "user1234",
})
if err != nil {
    log.Fatal(err)
}
```

--------------------------------

### Create ADK Agent Project Directory Structure

Source: https://google.github.io/adk-docs/get-started/java

These command-line snippets create the necessary directory structure and empty placeholder files for a new ADK Java agent project. They set up the `my_agent` root, the `src/main/java/com/example/agent` path, and create files for the main agent code, CLI runner, Maven configuration, and environment variables, providing commands for both Windows and Unix-like operating systems.

```Batch
mkdir my_agent\src\main\java\com\example\agent
type nul > my_agent\src\main\java\com\example\agent\HelloTimeAgent.java
type nul > my_agent\src\main\java\com\example\agent\AgentCliRunner.java
type nul > my_agent\pom.xml
type nul > my_agent\.env
```

```Bash
mkdir -p my_agent/src/main/java/com/example/agent && \
    touch my_agent/src/main/java/com/example/agent/HelloTimeAgent.java && \
    touch my_agent/src/main/java/com/example/agent/AgentCliRunner.java && \
    touch my_agent/pom.xml my_agent/.env
```

--------------------------------

### beforeRunnerCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SecurityPlugin

Callback executed before the runner starts processing an invocation. This callback is useful for setup operations, logging, or halting execution early by returning an Event instead of undefined.

```APIDOC
## beforeRunnerCallback

### Description
Callback executed before the runner starts processing an invocation. This callback is useful for setup operations, logging, or halting execution early by returning an Event instead of undefined.

### Method
Callback

### Function Signature
```typescript
beforeRunnerCallback(
  invocationContext: { invocationContext: InvocationContext }
): Promise<Content | undefined>
```

### Parameters
#### Input Parameters
- **invocationContext** (object) - Required - The context for the entire invocation, containing session information, the root agent, etc.
  - **invocationContext** (InvocationContext) - The invocation context object

### Returns
- **Promise<Content | undefined>** - An optional `Event` to be returned to the ADK. Returning a value halts execution of the runner and ends it with that event. Return `undefined` to proceed normally.
```

--------------------------------

### Python: Initialize ADK Services and Run Initial Agent Query

Source: https://google.github.io/adk-docs/tools/authentication

This code snippet demonstrates the initial setup for an ADK agent application. It initializes in-memory session and artifact services, creates a new user session, defines an initial user query, and then runs the ADK agent with this query. The `Runner` orchestrates the interaction between the user, agent, and services.

```python
import asyncio
from dotenv import load_dotenv
from google.adk.artifacts.in_memory_artifact_service import InMemoryArtifactService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from .helpers import is_pending_auth_event, get_function_call_id, get_function_call_auth_config, get_user_input
from .tools_and_agent import root_agent

load_dotenv()

agent = root_agent

async def async_main():
  """
  Main asynchronous function orchestrating the agent interaction and authentication flow.
  """
  # --- Step 1: Service Initialization ---
  # Use in-memory services for session and artifact storage (suitable for demos/testing).
  session_service = InMemorySessionService()
  artifacts_service = InMemoryArtifactService()

  # Create a new user session to maintain conversation state.
  session = session_service.create_session(
      state={},  # Optional state dictionary for session-specific data
      app_name='my_app', # Application identifier
      user_id='user' # User identifier
  )

  # --- Step 2: Initial User Query ---
  # Define the user's initial request.
  query = 'Show me my user info'
  print(f"user: {query}")

  # Format the query into the Content structure expected by the ADK Runner.
  content = types.Content(role='user', parts=[types.Part(text=query)])

  # Initialize the ADK Runner
  runner = Runner(
      app_name='my_app',
      agent=agent,
      artifact_service=artifacts_service,
      session_service=session_service,
  )

  # --- Step 3: Send Query and Handle Potential Auth Request ---
  print("\nRunning agent with initial query...")
  events_async = runner.run_async(
      session_id=session.id, user_id='user', new_message=content
  )
```

--------------------------------

### Configure ADK Sequential Agent for Code Generation, Review, and Refactoring

Source: https://google.github.io/adk-docs/agents/workflow-agents/sequential-agents

This snippet demonstrates the setup of a SequentialAgent that orchestrates a multi-step code development workflow. It includes LlmAgent instances for initial code generation, subsequent code review based on defined criteria, and final code refactoring according to review comments. The example is provided in both Go and Java, showcasing how to define agent configurations, instructions, and output keys for each stage of the pipeline.

```go
    codeWriterAgent, err := llmagent.New(llmagent.Config{
        Name:        "CodeWriterAgent",
        Model:       model,
        Description: "Writes initial Go code based on a specification.",
        Instruction: `You are a Go Code Generator.
Based *only* on the user's request, write Go code that fulfills the requirement.
Output *only* the complete Go code block, enclosed in triple backticks ('''go ... ''').
Do not add any other text before or after the code block.`,
        OutputKey: "generated_code",
    })
    if err != nil {
        return fmt.Errorf("failed to create code writer agent: %v", err)
    }

    codeReviewerAgent, err := llmagent.New(llmagent.Config{
        Name:        "CodeReviewerAgent",
        Model:       model,
        Description: "Reviews Go code and provides feedback.",
        Instruction: `You are an expert Go Code Reviewer.
Your task is to provide constructive feedback on the provided code.

**Code to Review:**
'''go
{generated_code}
'''

**Review Criteria:**
1.  **Correctness:** Does the code work as intended? Are there logic errors?
2.  **Readability:** Is the code clear and easy to understand? Follows Go style guidelines?
3.  **Idiomatic Go:** Does the code use Go's features in a natural and standard way?
4.  **Edge Cases:** Does the code handle potential edge cases or invalid inputs gracefully?
5.  **Best Practices:** Does the code follow common Go best practices?

**Output:**
Provide your feedback as a concise, bulleted list. Focus on the most important points for improvement.
If the code is excellent and requires no changes, simply state: "No major issues found."
Output *only* the review comments or the "No major issues" statement.`,
        OutputKey: "review_comments",
    })
    if err != nil {
        return fmt.Errorf("failed to create code reviewer agent: %v", err)
    }

    codeRefactorerAgent, err := llmagent.New(llmagent.Config{
        Name:        "CodeRefactorerAgent",
        Model:       model,
        Description: "Refactors code based on review comments.",
        Instruction: `You are a Go Code Refactoring AI.
Your goal is to improve the given Go code based on the provided review comments.

**Original Code:**
'''go
{generated_code}
'''

**Review Comments:**
{review_comments}

**Task:**
Carefully apply the suggestions from the review comments to refactor the original code.
If the review comments state "No major issues found," return the original code unchanged.
Ensure the final code is complete, functional, and includes necessary imports.

**Output:**
Output *only* the final, refactored Go code block, enclosed in triple backticks ('''go ... ''').
Do not add any other text before or after the code block.`,
        OutputKey: "refactored_code",
    })
    if err != nil {
        return fmt.Errorf("failed to create code refactorer agent: %v", err)
    }

    codePipelineAgent, err := sequentialagent.New(sequentialagent.Config{
        AgentConfig: agent.Config{
            Name:        appName,
            Description: "Executes a sequence of code writing, reviewing, and refactoring.",
            SubAgents: []agent.Agent{
                codeWriterAgent,
                codeReviewerAgent,
                codeRefactorerAgent,
            },
        },
    })
    if err != nil {
        return fmt.Errorf("failed to create sequential agent: %v", err)
    }
```

```java
    LlmAgent codeWriterAgent =
        LlmAgent.builder()
            .model(MODEL_NAME)
            .name("CodeWriterAgent")
            .description("Writes initial Java code based on a specification.")
            .instruction(
                """
                You are a Java Code Generator.
                Based *only* on the user's request, write Java code that fulfills the requirement.
                Output *only* the complete Java code block, enclosed in triple backticks (```java ... ```).
                Do not add any other text before or after the code block.
                """)
            .outputKey("generated_code")
            .build();

    LlmAgent codeReviewerAgent =
        LlmAgent.builder()
            .model(MODEL_NAME)
            .name("CodeReviewerAgent")
            .description("Reviews code and provides feedback.")
            .instruction(
                """
                    You are an expert Java Code Reviewer.
                    Your task is to provide constructive feedback on the provided code.

                    **Code to Review:**
                    ```java
                    {generated_code}
                    ```

                    **Review Criteria:**
                    1.  **Correctness:** Does the code work as intended? Are there logic errors?
                    2.  **Readability:** Is the code clear and easy to understand? Follows Java style guidelines?
                    3.  **Efficiency:** Is the code reasonably efficient? Any obvious performance bottlenecks?
                    4.  **Edge Cases:** Does the code handle potential edge cases or invalid inputs gracefully?
                    5.  **Best Practices:** Does the code follow common Java best practices?

                    **Output:**
""")
```

--------------------------------

### Create and Examine ADK Session Properties

Source: https://google.github.io/adk-docs/sessions/session

These examples demonstrate how to initialize an `InMemorySessionService`, create a new session with an application name, user ID, and initial state, and then print out its core properties like `id`, `app_name`/`appName`, `user_id`/`userId`, `state`, `events`, and `last_update_time`/`lastUpdateTime`. The Python, TypeScript, and Go examples also include a cleanup step to delete the created session.

```python
from google.adk.sessions import InMemorySessionService, Session

# Create a simple session to examine its properties
temp_service = InMemorySessionService()
example_session = await temp_service.create_session(
    app_name="my_app",
    user_id="example_user",
    state={"initial_key": "initial_value"} # State can be initialized
)

print(f"--- Examining Session Properties ---")
print(f"ID (`id`):                {example_session.id}")
print(f"Application Name (`app_name`): {example_session.app_name}")
print(f"User ID (`user_id`):         {example_session.user_id}")
print(f"State (`state`):           {example_session.state}") # Note: Only shows initial state here
print(f"Events (`events`):         {example_session.events}") # Initially empty
print(f"Last Update (`last_update_time`): {example_session.last_update_time:.2f}")
print(f"---------------------------------")

# Clean up (optional for this example)
temp_service = await temp_service.delete_session(app_name=example_session.app_name,
                            user_id=example_session.user_id, session_id=example_session.id)
print("The final status of temp_service - ", temp_service)
```

```typescript
import { InMemorySessionService } from "@google/adk";

// Create a simple session to examine its properties
const tempService = new InMemorySessionService();
const exampleSession = await tempService.createSession({
    appName: "my_app",
    userId: "example_user",
    state: {"initial_key": "initial_value"} // State can be initialized
});

console.log("--- Examining Session Properties ---");
console.log(`ID ('id'):                ${exampleSession.id}`);
console.log(`Application Name ('appName'): ${exampleSession.appName}`);
console.log(`User ID ('userId'):         ${exampleSession.userId}`);
console.log(`State ('state'):           ${JSON.stringify(exampleSession.state)}`); // Note: Only shows initial state here
console.log(`Events ('events'):         ${JSON.stringify(exampleSession.events)}`); // Initially empty
console.log(`Last Update ('lastUpdateTime'): ${exampleSession.lastUpdateTime}`);
console.log("---------------------------------");

// Clean up (optional for this example)
const finalStatus = await tempService.deleteSession({
    appName: exampleSession.appName,
    userId: exampleSession.userId,
    sessionId: exampleSession.id
});
console.log("The final status of temp_service - ", finalStatus);
```

```go
appName := "my_go_app"
userID := "example_go_user"
initialState := map[string]any{"initial_key": "initial_value"}

// Create a session to examine its properties.
createResp, err := inMemoryService.Create(ctx, &session.CreateRequest{
 AppName: appName,
 UserID:  userID,
 State:   initialState,
})
if err != nil {
 log.Fatalf("Failed to create session: %v", err)
}
exampleSession := createResp.Session

fmt.Println("\n--- Examining Session Properties ---")
fmt.Printf("ID (`ID()`): %s\n", exampleSession.ID())
fmt.Printf("Application Name (`AppName()`): %s\n", exampleSession.AppName())
// To access state, you call Get().
val, _ := exampleSession.State().Get("initial_key")
fmt.Printf("State (`State().Get()`):    initial_key = %v\n", val)

// Events are initially empty.
fmt.Printf("Events (`Events().Len()`):  %d\n", exampleSession.Events().Len())
fmt.Printf("Last Update (`LastUpdateTime()`): %s\n", exampleSession.LastUpdateTime().Format("2006-01-02 15:04:05"))
fmt.Println("---------------------------------")

// Clean up the session.
err = inMemoryService.Delete(ctx, &session.DeleteRequest{
 AppName:   exampleSession.AppName(),
 UserID:    exampleSession.UserID(),
 SessionID: exampleSession.ID(),
})
if err != nil {
 log.Fatalf("Failed to delete session: %v", err)
}
fmt.Println("Session deleted successfully.")
```

```java
import com.google.adk.sessions.InMemorySessionService;
import com.google.adk.sessions.Session;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;

String sessionId = "123";
String appName = "example-app"; // Example app name
String userId = "example-user"; // Example user id
ConcurrentMap<String, Object> initialState = new ConcurrentHashMap<>(Map.of("newKey", "newValue"));
InMemorySessionService exampleSessionService = new InMemorySessionService();

// Create Session
Session exampleSession = exampleSessionService.createSession(
    appName, userId, initialState, Optional.of(sessionId)).blockingGet();
System.out.println("Session created successfully.");

System.out.println("--- Examining Session Properties ---");
System.out.printf("ID (`id`): %s%n", exampleSession.id());
System.out.printf("Application Name (`appName`): %s%n", exampleSession.appName());
System.out.printf("User ID (`userId`): %s%n", exampleSession.userId());
System.out.printf("State (`state`): %s%n", exampleSession.state());
System.out.println("------------------------------------");
```

--------------------------------

### Instantiate Custom Agent and Setup Runner in Python

Source: https://google.github.io/adk-docs/agents/custom-agents

This Python code instantiates a custom 'StoryFlowAgent', passing in previously defined individual LLM agents as arguments. It then defines an asynchronous function to set up a 'Runner' and 'Session' using an 'InMemorySessionService'. The session is initialized with a starting 'topic' in its state, and the 'Runner' is configured to use the custom orchestrator agent for execution.

```python
# --- Create the custom agent instance ---
story_flow_agent = StoryFlowAgent(
    name="StoryFlowAgent",
    story_generator=story_generator,
    critic=critic,
    reviser=reviser,
    grammar_check=grammar_check,
    tone_check=tone_check,
)

INITIAL_STATE = {"topic": "a brave kitten exploring a haunted house"}

# --- Setup Runner and Session ---
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID, state=INITIAL_STATE)
    logger.info(f"Initial session state: {session.state}")
    runner = Runner(
        agent=story_flow_agent, # Pass the custom orchestrator agent
        app_name=APP_NAME,
        session_service=session_service
    )
    return session_service, runner
```

--------------------------------

### Start MLflow Tracking Server with SQL Backend

Source: https://google.github.io/adk-docs/observability/mlflow

Launch MLflow server with SQLite backend store on port 5000. Requires SQLite and MLflow installed. SQL-based backends (SQLite, PostgreSQL, MySQL, MSSQL) are required for OTLP ingestion support.

```shell
mlflow server --backend-store-uri sqlite:///mlflow.db --port 5000
```

--------------------------------

### ToolContext.Builder - Complete Builder Pattern Example

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/ToolContext.Builder

Demonstrates the complete builder pattern workflow for creating a ToolContext instance with all available configuration options.

```APIDOC
## ToolContext.Builder - Complete Usage

### Description
Complete example showing how to use the ToolContext.Builder to create a fully configured ToolContext instance.

### Class Definition
```java
public static final class ToolContext.Builder extends Object
```

### Available Methods
- **actions(EventActions actions)** - Configure EventActions
- **functionCallId(String functionCallId)** - Set function call identifier
- **build()** - Create the ToolContext instance

### Complete Example
```java
EventActions eventActions = new EventActions();
ToolContext context = new ToolContext.Builder()
    .actions(eventActions)
    .functionCallId("my-function-call-id")
    .build();
```

### Notes
- All builder methods are annotated with @CanIgnoreReturnValue
- The builder supports method chaining for fluent API usage
- The build() method creates the final immutable ToolContext instance
```

--------------------------------

### Tool Starting Event JSON Payload Structure

Source: https://google.github.io/adk-docs/observability/bigquery-agent-analytics

Defines the JSON structure for TOOL_STARTING events that capture the tool name and arguments at the beginning of tool execution. Example demonstrates a list_datasets tool with project_id argument.

```json
{
  "tool": "list_datasets",
  "args": {"project_id": "my-project"}
}
```

--------------------------------

### BaseExampleProvider Interface

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/package-use

An interface that provides examples for a given query. This interface defines the contract for example providers used throughout the Google ADK agents and examples packages.

```APIDOC
## BaseExampleProvider Interface

### Description
An interface that provides examples for a given query. Implementations of this interface are responsible for retrieving and supplying few-shot examples based on query parameters.

### Package
com.google.adk.examples

### Used By
- com.google.adk.agents
- com.google.adk.examples

### Purpose
Defines the contract for example providers that supply contextual examples to support query processing and few-shot learning scenarios in the Google ADK framework.
```

--------------------------------

### Declare getExamples Method in BaseExampleProvider (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/BaseExampleProvider

This snippet declares the `getExamples` method within the `BaseExampleProvider` interface. This method is designed to retrieve a list of `Example` objects, taking a `String query` as input to filter or specify the desired examples. It is the primary mechanism for fetching examples from an implementing class.

```java
List<Example> getExamples(String query)
```

--------------------------------

### CALLBACK /beforeRunCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LoggingPlugin

Executed before the ADK runner starts. Ideal for global setup or initialization tasks as it's the first callback in the lifecycle.

```APIDOC
## CALLBACK /beforeRunCallback

### Description
Callback executed before the ADK runner runs. This is the first callback to be called in the lifecycle, ideal for global setup or initialization tasks.

### Method
CALLBACK

### Endpoint
/beforeRunCallback

### Parameters
#### Request Body
- **invocationContext** (object) - Required - The context for the entire invocation, containing session information, the root agent, etc.
  - **invocationContext** (InvocationContext) - The invocation context object.

### Request Example
```json
{
  "invocationContext": {
    "invocationContext": {
      "sessionId": "abc-123",
      "agentId": "myAgent"
    }
  }
}
```

### Response
#### Success Response (200)
- **Content** (Content | undefined) - An optional `Event` to be returned to the ADK. Returning a value halts execution of the runner and ends the runner with that event. Returning `undefined` proceeds normally.

#### Response Example
```json
{
  "type": "event",
  "data": "Initialization successful"
}
```
```

--------------------------------

### Start ADK Web Server - Go

Source: https://google.github.io/adk-docs/runtime/web-interface

Run the ADK web interface for Go agents by executing the agent with web api webui parameters. The server starts on http://localhost:8000 by default.

```bash
go run agent.go web api webui
```

--------------------------------

### Run OpenAPI agent examples with multiple queries

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Async function that executes three example queries demonstrating different Pet Store operations: listing pets, creating a new pet, and retrieving pet information by ID. Each query triggers specific API endpoints through the agent's tool invocation.

```Python
async def run_openapi_example():
    runner_openapi = await setup_session_and_runner()

    await call_openapi_agent_async("Show me the pets available.", runner_openapi)
    await call_openapi_agent_async("Please add a new dog named 'Dukey'.", runner_openapi)
    await call_openapi_agent_async("Get info for pet with ID 123.", runner_openapi)
```

--------------------------------

### Run main consuming agent in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming-go

Starts the main root agent in a separate terminal after the remote prime agent server is running. The root agent will orchestrate tasks and communicate with both local roll agent and remote prime agent via A2A.

```bash
go run main.go
```

--------------------------------

### Set LlmAgent example provider (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/LlmAgent.Builder

Configures the example provider for the `LlmAgent`, which supplies examples for few-shot learning or context. This method is overloaded to accept a `BaseExampleProvider` object, a `List` of `Example` objects, or a variable number of `Example` arguments. It is annotated with `@CanIgnoreReturnValue` and returns the builder instance for chaining.

```java
@CanIgnoreReturnValue public LlmAgent.Builder exampleProvider(BaseExampleProvider exampleProvider)
```

```java
@CanIgnoreReturnValue public LlmAgent.Builder exampleProvider(List<Example> examples)
```

```java
@CanIgnoreReturnValue public LlmAgent.Builder exampleProvider(Example... examples)
```

--------------------------------

### A2A basic project folder structure

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing-go

The a2a_basic sample project structure showing the organization of the remote A2A agent, root agent, and Go module files. The remote_a2a directory contains the check_prime_agent that will be exposed via A2A Protocol.

```text
a2a_basic/
├── remote_a2a/
│   └── check_prime_agent/
│       └── main.go    # Remote Prime Agent
├── go.mod
├── go.sum
└── main.go            # Root agent
```

--------------------------------

### Create Python Virtual Environment

Source: https://google.github.io/adk-docs/get-started/python

Creates and activates a Python virtual environment for isolating ADK project dependencies. Provides platform-specific activation commands for Windows (CMD and PowerShell) and Unix-like systems (macOS/Linux).

```bash
python -m venv .venv
```

```batch
.venv\Scripts\activate.bat
```

```powershell
.venv\Scripts\Activate.ps1
```

```bash
source .venv/bin/activate
```

--------------------------------

### Example.Builder.output() - Set Output Content

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example.Builder

Abstract method that sets the output content list for the Example being built. Accepts a list of Content objects and returns the builder for method chaining.

```APIDOC
## Method: Example.Builder.output()

### Description
Sets the output content list for the Example object being constructed. This is an abstract method that must be implemented by concrete builder subclasses.

### Method
ABSTRACT

### Signature
```java
abstract Example.Builder output(List<com.google.genai.types.Content> output)
```

### Parameters
#### Method Parameters
- **output** (List<com.google.genai.types.Content>) - Required - A list of Content objects representing the output for this example

### Returns
- **Example.Builder** - Returns this builder instance for method chaining

### Usage Example
```java
Example.Builder builder = Example.builder()
  .output(outputContentList);
```
```

--------------------------------

### Example.Builder Class

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/package-use

Builder class for constructing Example instances in the Google ADK framework. Provides a fluent API for creating Example objects with specified properties and configurations.

```APIDOC
## Example.Builder Class

### Description
Builder for constructing `Example` instances. This class implements the builder pattern to provide a flexible and readable way to create Example objects with various configurations.

### Package
com.google.adk.examples

### Purpose
Provides a fluent API for building Example instances with proper initialization and validation of all required and optional fields.

### Usage Pattern
Use this builder class to construct Example objects:
```
Example example = new Example.Builder()
  .withProperty(value)
  .build();
```

### Related Classes
- Example - The class being constructed by this builder
```

--------------------------------

### Configure and Run LLM Agent with Custom After-Model Callback (Go and Java)

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

These examples illustrate how to set up and execute an LLM agent that integrates an `after_model_callback` in both Go and Java. They cover initializing the LLM model, configuring the agent with the specified callback, and running a scenario to demonstrate the callback's effect on the agent's output. The Java example also includes necessary imports and constants for the agent's operation.

```go
func runAfterModelExample() {
    ctx := context.Background()
    geminiModel, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("FATAL: Failed to create model: %v", err)
    }

    llmCfg := llmagent.Config{
        Name:                "AgentWithAfterModelCallback",
        Model:               geminiModel,
        AfterModelCallbacks: []llmagent.AfterModelCallback{onAfterModel},
    }
    testAgent, err := llmagent.New(llmCfg)
    if err != nil {
        log.Fatalf("FATAL: Failed to create agent: %v", err)
    }

    sessionService := session.InMemoryService()
    r, err := runner.New(runner.Config{AppName: appName, Agent: testAgent, SessionService: sessionService})
    if err != nil {
        log.Fatalf("FATAL: Failed to create runner: %v", err)
    }

    log.Println("--- SCENARIO 1: Response should be modified ---")
    runScenario(ctx, r, sessionService, appName, "session_modify", nil, `Give me a paragraph about different styles of jokes.`)
}
```

```java
import com.google.adk.agents.LlmAgent;
import com.google.adk.agents.CallbackContext;
import com.google.adk.events.Event;
import com.google.adk.models.LlmResponse;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.common.collect.ImmutableList;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.core.Maybe;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AfterModelCallbackExample {

  // --- Define Constants ---
  private static final String AGENT_NAME = "AfterModelCallbackAgent";
  private static final String MODEL_NAME = "gemini-2.0-flash";
  private static final String AGENT_INSTRUCTION = "You are a helpful assistant.";
  private static final String AGENT_DESCRIPTION = "An LLM agent demonstrating after_model_callback";

  // For session and runner
  private static final String APP_NAME = "AfterModelCallbackAgentApp";
  private static final String USER_ID = "user_1";

  // For text replacement
  private static final String SEARCH_TERM = "joke";
  private static final String REPLACE_TERM = "funny story";
  private static final Pattern SEARCH_PATTERN =
      Pattern.compile("\\b" + Pattern.quote(SEARCH_TERM) + "\\b", Pattern.CASE_INSENSITIVE);

  public static void main(String[] args) {
    AfterModelCallbackExample example = new AfterModelCallbackExample();
    example.defineAgentAndRun();
  }
```

--------------------------------

### Start Google ADK Web UI and Agent (Python & Java)

Source: https://google.github.io/adk-docs/tools/google-cloud/application-integration

These commands initiate the Google ADK Web UI, allowing users to interact with their agents. The Python command `adk web` launches the UI directly, while the Java commands use Maven to build and run the `AdkWebServer`. After execution, the UI is accessible at `http://localhost:8000` where the agent can be selected.

```python
    # make sure to run `adk web` from your project_root_folder
    adk web
```

```java
    mvn install

    mvn exec:java \
        -Dexec.mainClass="com.google.adk.web.AdkWebServer" \
        -Dexec.args="--adk.agents.source-dir=src/main/java" \
        -Dexec.classpathScope="compile"
```

--------------------------------

### Configure BigQuery Agent Analytics Plugin with GCS Offloading - Python

Source: https://google.github.io/adk-docs/observability/bigquery-agent-analytics

Initialize and configure the BigQuery Agent Analytics Plugin with an ADK agent, including OpenTelemetry setup for distributed tracing and GCS bucket configuration for multimodal content offloading. This example demonstrates environment variable setup, authentication, and plugin registration with the agent's App object.

```python
# my_bq_agent/agent.py
import os
import google.auth
from google.adk.apps import App
from google.adk.plugins.bigquery_agent_analytics_plugin import BigQueryAgentAnalyticsPlugin, BigQueryLoggerConfig
from google.adk.agents import Agent
from google.adk.models.google_llm import Gemini
from google.adk.tools.bigquery import BigQueryToolset, BigQueryCredentialsConfig


# --- OpenTelemetry Initialization (Optional) ---
# Recommended for enabling distributed tracing (populates trace_id, span_id).
# If not configured, the plugin uses internal UUIDs for span correlation.
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    trace.set_tracer_provider(TracerProvider())
except ImportError:
    pass # OpenTelemetry is optional

# --- Configuration ---
PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id")
DATASET_ID = os.environ.get("BIG_QUERY_DATASET_ID", "your-big-query-dataset-id")
LOCATION = os.environ.get("GOOGLE_CLOUD_LOCATION", "US") # default location is US in the plugin
GCS_BUCKET = os.environ.get("GCS_BUCKET_NAME", "your-gcs-bucket-name") # Optional

if PROJECT_ID == "your-gcp-project-id":
    raise ValueError("Please set GOOGLE_CLOUD_PROJECT or update the code.")

# --- CRITICAL: Set environment variables BEFORE Gemini instantiation ---
os.environ['GOOGLE_CLOUD_PROJECT'] = PROJECT_ID
os.environ['GOOGLE_CLOUD_LOCATION'] = LOCATION
os.environ['GOOGLE_GENAI_USE_VERTEXAI'] = 'True'
```

--------------------------------

### Test Proactivity with Open-Ended Context

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Example test case for verifying proactive behavior by providing open-ended context without explicit questions. The model should respond with suggestions and follow-up questions based on the provided information.

```text
User: "I'm planning a trip to Japan next month."
Expected: Model offers suggestions, asks follow-up questions
```

--------------------------------

### Start remote A2A prime agent server in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming-go

Executes the remote prime agent server on port 8001, hosting the check_prime_agent service. This server must be running before the main agent can access the remote prime-checking functionality via A2A protocol.

```bash
go run remote_a2a/check_prime_agent/main.go
```

--------------------------------

### Example.toBuilder() - Convert to Builder

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example.Builder

Abstract method that creates a new Example.Builder instance initialized with the values from an existing Example object. Useful for modifying copies of existing examples.

```APIDOC
## Method: Example.toBuilder()

### Description
Creates a new Example.Builder instance that is pre-populated with the values from the current Example object. This allows for creating modified copies of existing examples.

### Method
ABSTRACT

### Signature
```java
abstract Example.Builder toBuilder()
```

### Returns
- **Example.Builder** - A new builder instance initialized with this example's values

### Usage Example
```java
Example originalExample = // ... existing example
Example.Builder modifiedBuilder = originalExample.toBuilder()
  .input(newInput);
```
```

--------------------------------

### Create LLM Agent with Instructions and Tools in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing-go

Configures an LLM agent named check_prime_agent with specific instructions for prime number validation. The agent uses the previously created prime_checking tool and includes instructions to pass integer lists (not strings) and avoid relying on previous prime checking history.

```go
primeAgent, err := llmagent.New(llmagent.Config{
    Name:        "check_prime_agent",
    Description: "check prime agent that can check whether numbers are prime.",
    Instruction: `
        You check whether numbers are prime.
        When checking prime numbers, call the check_prime tool with a list of integers. Be sure to pass in a list of integers. You should never pass in a string.
        You should not rely on the previous history on prime results.
    `,
    Model: model,
    Tools: []tool.Tool{primeTool},
})
if err != nil {
    log.Fatalf("Failed to create agent: %v", err)
}
```

--------------------------------

### LlmAgent ExampleProvider Accessor

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/LlmAgent

Returns an `Optional` containing the `BaseExampleProvider` for the agent. This provider is used for supplying examples, potentially for few-shot learning or other example-driven behaviors.

```java
public Optional<BaseExampleProvider> exampleProvider()

```

--------------------------------

### Run ADK Agent with Command-Line Interface

Source: https://google.github.io/adk-docs/get-started/python

Executes an ADK agent using the command-line interface, providing an interactive terminal-based interface for testing and interacting with the agent.

```bash
adk run my_agent
```

--------------------------------

### Create Multiple Conversation Scenarios JSON File

Source: https://google.github.io/adk-docs/evaluate/user-sim

Defines a collection of conversation scenarios to test an agent in multiple ways. Each scenario contains a starting prompt and conversation plan that guides the dynamic prompt generation for the entire conversation.

```json
{
  "scenarios": [
    {
      "starting_prompt": "What can you do for me?",
      "conversation_plan": "Ask the agent to roll a 20-sided die. After you get the result, ask the agent to check if it is prime."
    },
    {
      "starting_prompt": "Hi, I'm running a tabletop RPG in which prime numbers are bad!",
      "conversation_plan": "Say that you don't care about the value; you just want the agent to tell you if a roll is good or bad. Once the agent agrees, ask it to roll a 6-sided die. Finally, ask the agent to do the same with 2 20-sided dice."
    }
  ]
}
```

--------------------------------

### Initialize LLM Agent with Operational Instructions (Multi-language)

Source: https://google.github.io/adk-docs/agents/llm-agents

This snippet demonstrates how to instantiate an `LlmAgent` in various programming languages (Python, JavaScript, Go, Java), providing it with a name, model, description, and critical operational instructions. The `instruction` field is crucial for guiding the agent's behavior, defining its role, and outlining the steps it should follow when responding to user queries, including tool usage examples.

```python
capital_agent = LlmAgent(
    model="gemini-2.5-flash",
    name="capital_agent",
    description="Answers user questions about the capital city of a given country.",
    instruction="""You are an agent that provides the capital city of a country.
When a user asks for the capital of a country:
1. Identify the country name from the user's query.
2. Use the `get_capital_city` tool to find the capital.
3. Respond clearly to the user, stating the capital city.
Example Query: "What's the capital of {country}"?
Example Response: "The capital of France is Paris."
""",
    # tools will be added next
)
```

```javascript
// Example: Adding instructions
const capitalAgent = new LlmAgent({
    model: 'gemini-2.5-flash',
    name: 'capital_agent',
    description: 'Answers user questions about the capital city of a given country.',
    instruction: `You are an agent that provides the capital city of a country.
        When a user asks for the capital of a country:
        1. Identify the country name from the user's query.
        2. Use the \`getCapitalCity\` tool to find the capital.
        3. Respond clearly to the user, stating the capital city.
        Example Query: "What's the capital of {country}"?
        Example Response: "The capital of France is Paris."
        `,
    // tools will be added next
});
```

```go
    // Example: Adding instructions
    agent, err := llmagent.New(llmagent.Config{
        Name:        "capital_agent",
        Model:       model,
        Description: "Answers user questions about the capital city of a given country.",
        Instruction: `You are an agent that provides the capital city of a country.
When a user asks for the capital of a country:
1. Identify the country name from the user's query.
2. Use the 'get_capital_city' tool to find the capital.
3. Respond clearly to the user, stating the capital city.
Example Query: "What's the capital of {country}"?
Example Response: "The capital of France is Paris."`,
        // tools will be added next
    })
```

```java
// Example: Adding instructions
LlmAgent capitalAgent =
    LlmAgent.builder()
        .model("gemini-2.5-flash")
        .name("capital_agent")
        .description("Answers user questions about the capital city of a given country.")
        .instruction(
            """
            You are an agent that provides the capital city of a country.
            When a user asks for the capital of a country:
            1. Identify the country name from the user's query.
            2. Use the `get_capital_city` tool to find the capital.
            3. Respond clearly to the user, stating the capital city.
            Example Query: "What's the capital of {country}"?
            Example Response: "The capital of France is Paris."
            """)
        // tools will be added next
        .build();
```

--------------------------------

### Example.builder() - Create New Builder

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example.Builder

Static factory method that creates a new Example.Builder instance. This is the entry point for constructing Example objects using the builder pattern.

```APIDOC
## Static Method: Example.builder()

### Description
Creates a new instance of Example.Builder for constructing Example objects.

### Method
STATIC

### Signature
```java
static Example.Builder builder()
```

### Returns
- **Example.Builder** - A new builder instance for creating Example objects

### Usage Example
```java
Example.Builder builder = Example.builder();
```

### Related Methods
- `Example.Builder.input(Content input)` - Set the input content
- `Example.Builder.output(List<Content> output)` - Set the output content
```

--------------------------------

### Example Class

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/package-use

Represents a few-shot example used in the Google ADK framework. This class encapsulates individual example data and can be constructed using the Example.Builder pattern for flexible instance creation.

```APIDOC
## Example Class

### Description
Represents a few-shot example in the Google ADK framework. This class is used to store and manage individual examples that can be provided by BaseExampleProvider implementations.

### Package
com.google.adk.examples

### Used By
- com.google.adk.agents
- com.google.adk.examples

### Construction
Instances of Example should be created using the Example.Builder class to ensure proper initialization and validation.

### Related Classes
- Example.Builder - Builder class for constructing Example instances
```

--------------------------------

### Tool Confirmation with ToolContext

Source: https://google.github.io/adk-docs/tools-custom/confirmation

Demonstrates how to implement a tool with advanced confirmation by creating a function that includes a ToolContext object and uses the request_confirmation() method. This example shows a time off request tool that waits for manager approval before processing.

```APIDOC
## Tool Confirmation Implementation

### Description
Create a tool function that uses ToolContext to request confirmation from users before executing workflow actions. The tool pauses execution while awaiting confirmation, then proceeds based on the received response.

### Method
Function Definition (Python)

### Parameters
#### Function Parameters
- **days** (int) - Required - Number of days to request off
- **tool_context** (ToolContext) - Required - Context object containing confirmation methods

#### Request Confirmation Parameters
- **hint** (string) - Required - Descriptive message explaining what is needed from the user
- **payload** (Any) - Required - Structure of expected return data (must be JSON-serializable, e.g., dictionary or pydantic model)

### Request Example
```python
def request_time_off(days: int, tool_context: ToolContext):
  """Request day off for the employee."""
  tool_confirmation = tool_context.tool_confirmation
  if not tool_confirmation:
    tool_context.request_confirmation(
        hint=(
            'Please approve or reject the tool call request_time_off() by'
            ' responding with a FunctionResponse with an expected'
            ' ToolConfirmation payload.'
        ),
        payload={
            'approved_days': 0,
        },
    )
    return {'status': 'Manager approval is required.'}
  
  approved_days = tool_confirmation.payload['approved_days']
  approved_days = min(approved_days, days)
  if approved_days == 0:
    return {'status': 'The time off request is rejected.', 'approved_days': 0}
  return {
      'status': 'ok',
      'approved_days': approved_days,
  }
```

### Response
#### Intermediate Response (Awaiting Confirmation)
```json
{
  "status": "Manager approval is required."
}
```

#### Success Response (After Confirmation)
```json
{
  "status": "ok",
  "approved_days": 3
}
```

#### Rejected Response
```json
{
  "status": "The time off request is rejected.",
  "approved_days": 0
}
```
```

--------------------------------

### Create ADK TypeScript Project Structure (macOS/Linux)

Source: https://google.github.io/adk-docs/get-started/typescript

This command-line snippet creates the initial directory and essential files for a new ADK TypeScript agent project on macOS/Linux. It uses 'mkdir -p' to create the main directory and 'touch' to create empty 'agent.ts', 'package.json', and '.env' files.

```bash
mkdir -p my-agent/ && \
    touch my-agent/agent.ts \
    touch my-agent/package.json \
    touch my-agent/.env
```

--------------------------------

### Set LiteLLM Provider API Keys (Bash/Shell)

Source: https://google.github.io/adk-docs/agents/models/litellm

These examples show how to configure API keys for specific LiteLLM providers as environment variables. Proper API key setup is crucial for authenticating requests to LLM services like OpenAI and Anthropic. Consult LiteLLM documentation for other providers' variable names.

```bash
export OPENAI_API_KEY="YOUR_OPENAI_API_KEY"
```

```bash
export ANTHROPIC_API_KEY="YOUR_ANTHROPIC_API_KEY"
```

--------------------------------

### Illustrate unsupported ADK agent configuration with multiple tools

Source: https://google.github.io/adk-docs/tools/limitations

This example demonstrates an unsupported configuration in ADK where specific tools (like code execution or search) are used with other tools within a single agent object. This setup can lead to errors and is not recommended as per ADK limitations.

```python
root_agent = Agent(
    name="RootAgent",
    model="gemini-2.5-flash",
    description="Code Agent",
    tools=[custom_function],
    code_executor=BuiltInCodeExecutor() # <-- NOT supported when used with tools
)
```

```java
 LlmAgent searchAgent =
        LlmAgent.builder()
            .model(MODEL_ID)
            .name("SearchAgent")
            .instruction("You're a specialist in Google Search")
            .tools(new GoogleSearchTool(), new YourCustomTool()) // <-- NOT supported
            .build();
```

--------------------------------

### Clone Google ADK Python Repository

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This Git command clones the official `adk-python` repository from GitHub to your local machine. This repository contains sample projects, such as `a2a_root`, which are used to demonstrate the ADK A2A agent development workflow.

```bash
git clone https://github.com/google/adk-python.git
```

--------------------------------

### Example Before Agent Callback Configuration (YAML)

Source: https://google.github.io/adk-docs/api-reference/agentconfig

Demonstrates how to configure a before-agent callback using YAML. This specifies a callback function from a library that will be executed before the agent's main process.

```yaml
before_agent_callbacks:
  - name: my_library.security_callbacks.before_agent_callback
```

--------------------------------

### Initialize Prime Checking Tool and Gemini Model in Go

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing-go

Creates a function tool for prime checking and initializes the Gemini 2.0 Flash model. The prime_checking tool uses efficient mathematical algorithms to validate prime numbers in a list. Requires proper error handling for tool and model creation failures.

```go
ctx := context.Background()
primeTool, err := functiontool.New(functiontool.Config{
    Name:        "prime_checking",
    Description: "Check if numbers in a list are prime using efficient mathematical algorithms",
}, checkPrimeTool)
if err != nil {
    log.Fatalf("Failed to create prime_checking tool: %v", err)
}

model, err := gemini.NewModel(ctx, "gemini-2.0-flash", &genai.ClientConfig{})
if err != nil {
    log.Fatalf("Failed to create model: %v", err)
}
```

--------------------------------

### ADK Web Server Startup Output

Source: https://google.github.io/adk-docs/runtime/web-interface

Expected console output when the ADK web server starts successfully, indicating the local access URL.

```text
+-----------------------------------------------------------------------------+
| ADK Web Server started                                                      |
|                                                                             |
| For local testing, access at http://localhost:8000.                         |
+-----------------------------------------------------------------------------+
```

--------------------------------

### Set API Key in Environment - Windows

Source: https://google.github.io/adk-docs/get-started/go

Sets the Gemini API key as an environment variable on Windows systems. Writes the GOOGLE_API_KEY set statement to an env.bat file for persistent configuration.

```batch
echo 'set GOOGLE_API_KEY="YOUR_API_KEY"' > env.bat
```

--------------------------------

### Configure ADK Agent Model in .env File

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

This example shows how to define the `DEMO_AGENT_MODEL` environment variable within a `.env` file. It provides configurations for both Gemini Live API and Vertex AI Live API models, enabling developers to easily switch between different models or platforms by updating this file.

```shell
# For Gemini Live API (publicly available)
DEMO_AGENT_MODEL=gemini-2.5-flash-native-audio-preview-12-2025

# For Vertex AI Live API (if using Vertex AI)
# DEMO_AGENT_MODEL=gemini-live-2.5-flash-native-audio
```

--------------------------------

### Retrieve Google Cloud Project Number without jq (Shell)

Source: https://google.github.io/adk-docs/deploy/gke

Shows an alternative method to get the Google Cloud project number using `gcloud projects describe` if `jq` is not installed. Users need to manually copy the project number from the output.

```bash
gcloud projects describe $GOOGLE_CLOUD_PROJECT
```

--------------------------------

### Set Up TypeScript ADK Project with npm

Source: https://google.github.io/adk-docs/get-started/quickstart

Initializes a new Node.js project and installs ADK dependencies for TypeScript. Includes the ADK library, dev tools, and TypeScript compiler. Creates package.json and installs required packages.

```bash
mkdir my-adk-agent
cd my-adk-agent
npm init -y
npm install @google/adk @google/adk-devtools
npm install -D typescript
```

--------------------------------

### Initialize Main Agent with Tools and Sub-Agents

Source: https://google.github.io/adk-docs/tools-custom

Creates the main customer support agent with instructions, attaches the check and transfer tool, and registers the support agent as a sub-agent. Main agent handles initial queries and routes urgent ones.

```go
mainAgent, err := llmagent.New(llmagent.Config{
    Name:        "main_agent",
    Model:       model,
    Instruction: "You are the first point of contact for customer support of an analytics tool. Answer general queries. If the user indicates urgency, use the 'check_and_transfer' tool.",
    Tools:       []tool.Tool{checkAndTransferTool},
    SubAgents:   []agent.Agent{supportAgent},
})
if err != nil {
    log.Fatal(err)
}
```

--------------------------------

### Start ADK Web Server - TypeScript

Source: https://google.github.io/adk-docs/runtime/web-interface

Run the ADK web interface for TypeScript agents using npx. The server starts on http://localhost:8000 by default.

```bash
npx adk web
```

--------------------------------

### Initialize Go LLM Agent with Custom Tools and Runner

Source: https://google.github.io/adk-docs/tools-custom

This Go `main` function sets up an LLM agent using the Google ADK. It initializes a Gemini model, registers `getWeatherReport` and `analyzeSentiment` as function tools, configures the agent with detailed instructions and the registered tools, and prepares an in-memory session service and runner for agent interaction.

```go
package main

import (
	"context"
	"fmt"
	"log"
	"strings"

	"google.golang.org/adk/agent"
	"google.golang.org/adk/llmagent"
	"google.golang.org/adk/runner"
	"google.golang.org/adk/session"
	"google.golang.org/adk/tool"
	"google.golang.org/adk/tool/functiontool"
	"google.golang.org/genai"
)

// Assuming getWeatherReportArgs, getWeatherReportResult, getWeatherReport,
// analyzeSentimentArgs, analyzeSentimentResult, and analyzeSentiment are defined elsewhere or above.
// For full runnable code, include their definitions here.

func main() {
    ctx := context.Background()
    model, err := genai.NewModel(ctx, "gemini-2.0-flash", &genai.ClientConfig{})
    if err != nil {
        log.Fatal(err)
    }

    weatherTool, err := functiontool.New(
        functiontool.Config{
            Name:        "get_weather_report",
            Description: "Retrieves the current weather report for a specified city.",
        },
        getWeatherReport,
    )
    if err != nil {
        log.Fatal(err)
    }

    sentimentTool, err := functiontool.New(
        functiontool.Config{
            Name:        "analyze_sentiment",
            Description: "Analyzes the sentiment of the given text.",
        },
        analyzeSentiment,
    )
    if err != nil {
        log.Fatal(err)
    }

    weatherSentimentAgent, err := llmagent.New(llmagent.Config{
        Name:        "weather_sentiment_agent",
        Model:       model,
        Instruction: "You are a helpful assistant that provides weather information and analyzes the sentiment of user feedback. **If the user asks about the weather in a specific city, use the 'get_weather_report' tool to retrieve the weather details.** **If the 'get_weather_report' tool returns a 'success' status, provide the weather report to the user.** **If the 'get_weather_report' tool returns an 'error' status, inform the user that the weather information for the specified city is not available and ask if they have another city in mind.** **After providing a weather report, if the user gives feedback on the weather (e.g., 'That's good' or 'I don't like rain'), use the 'analyze_sentiment' tool to understand their sentiment.** Then, briefly acknowledge their sentiment. You can handle these tasks sequentially if needed.",
        Tools:       []tool.Tool{weatherTool, sentimentTool},
    })
    if err != nil {
        log.Fatal(err)
    }

    sessionService := session.InMemoryService()
    runner, err := runner.New(runner.Config{
        AppName:        "weather_sentiment_agent",
        Agent:          weatherSentimentAgent,
        SessionService: sessionService,
    })
    if err != nil {
        log.Fatal(err)
    }

    session, err := sessionService.Create(ctx, &session.CreateRequest{
        AppName: "weather_sentiment_agent",
        UserID:  "user1234",
    })
    if err != nil {
        log.Fatal(err)
    }

    run(ctx, runner, session.Session.ID(), "weather in london?")
    run(ctx, runner, session.Session.ID(), "I don't like rain.")
}
```

--------------------------------

### Create ADK TypeScript Project Structure (Windows)

Source: https://google.github.io/adk-docs/get-started/typescript

This command-line snippet creates the initial directory and essential files for a new ADK TypeScript agent project on Windows. It uses 'mkdir' to create the main directory and 'type nul >' to create empty 'agent.ts', 'package.json', and '.env' files.

```powershell
mkdir my-agent\
type nul > my-agent\agent.ts
type nul > my-agent\package.json
type nul > my-agent\.env
```

--------------------------------

### Setup Runner and Session Management

Source: https://google.github.io/adk-docs/agents/custom-agents

Initialize an in-memory runner with the agent and create a session with application context (appName, userId, sessionId) and initial state. Returns a runner instance for subsequent agent interactions.

```typescript
async function setupRunnerAndSession() {
  const runner = new InMemoryRunner({
    agent: storyFlowAgent,
    appName: APP_NAME,
  });
  const session = await runner.sessionService.createSession({
    appName: APP_NAME,
    userId: USER_ID,
    sessionId: SESSION_ID,
    state: INITIAL_STATE,
  });
  console.log(`Initial session state: ${JSON.stringify(session.state, null, 2)}`);
  return runner;
}
```

--------------------------------

### Start ADK Web Server - Java with Maven

Source: https://google.github.io/adk-docs/runtime/web-interface

Compile and run the ADK web server for Java agents using Maven. Specifies the agents source directory and server port configuration.

```bash
mvn compile exec:java \
 -Dexec.args="--adk.agents.source-dir=src/main/java/agents --server.port=8080"
```

--------------------------------

### Execute OpenAPI example with asyncio and error handling

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Main entry point that executes the OpenAPI agent example using asyncio.run(), with special handling for environments like Jupyter or Colab where event loops are already running. Provides fallback guidance for alternative execution methods.

```Python
if __name__ == "__main__":
    print("Executing OpenAPI example...")
    try:
        asyncio.run(run_openapi_example())
    except RuntimeError as e:
        if "cannot be called from a running event loop" in str(e):
            print("Info: Cannot run asyncio.run from a running event loop (e.g., Jupyter/Colab).")
        else:
            raise e
    print("OpenAPI example finished.")
```

--------------------------------

### Asynchronously set up ADK session and runner

Source: https://google.github.io/adk-docs/tools-custom

This asynchronous Python function, `setup_session_and_runner`, handles the initialization of the ADK environment. It first creates an `InMemorySessionService` to manage session data, then uses it to create a new session for the specified application and user. Finally, it instantiates a `Runner` object, which orchestrates the interaction with the `main_agent` and the session service, preparing the system to receive user inputs.

```python
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=main_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner
```

--------------------------------

### Install ADK Docs Extension for Gemini CLI

Source: https://google.github.io/adk-docs/tutorials/coding-with-ai

This command installs the ADK Docs Extension for the Gemini CLI. Once installed, the extension is automatically enabled, allowing the Gemini CLI to query ADK documentation using the `llms.txt` file for answering questions and generating code.

```shell
gemini extensions install https://github.com/derailed-dash/adk-docs-ext
```

--------------------------------

### Install ADK and LiteLLM Dependencies for Weather Bot Project

Source: https://google.github.io/adk-docs/tutorials/agent-team

This code block installs the essential Python packages required for the tutorial. `google-adk` provides the core Agent Development Kit framework, while `litellm` enables multi-model support, allowing agents to utilize various Large Language Models. The `-q` flag ensures a quiet installation process.

```python
!pip install google-adk -q
!pip install litellm -q

print("Installation complete.")
```

--------------------------------

### Entry Point for Agent Simulation in Go

Source: https://google.github.io/adk-docs/tools/function-tools

Implements RunAgentSimulation as the main entry point that creates the stock agent and orchestrates a series of user interactions. Demonstrates how the agent responds to various stock price queries by sending different prompts and handling responses.

```go
func RunAgentSimulation() {
    agent, err := createStockAgent(context.Background())
    if err != nil {
        // Error handling
    }
}
```

--------------------------------

### Example.Builder.input() - Set Input Content

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/class-use/Example.Builder

Abstract method that sets the input content for the Example being built. This method is part of the builder pattern and returns the builder instance for method chaining.

```APIDOC
## Method: Example.Builder.input()

### Description
Sets the input content for the Example object being constructed. This is an abstract method that must be implemented by concrete builder subclasses.

### Method
ABSTRACT

### Signature
```java
abstract Example.Builder input(com.google.genai.types.Content input)
```

### Parameters
#### Method Parameters
- **input** (com.google.genai.types.Content) - Required - The input content to be set for this example

### Returns
- **Example.Builder** - Returns this builder instance for method chaining

### Usage Example
```java
Example.Builder builder = Example.builder()
  .input(inputContent);
```
```

--------------------------------

### Declare BaseExampleProvider Interface (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/examples/BaseExampleProvider

This snippet defines the `BaseExampleProvider` interface in Java. It acts as a blueprint for classes that need to supply examples based on a given query, promoting a consistent API across different example providers.

```java
public interface BaseExampleProvider
```

--------------------------------

### Install Python ADK with pip

Source: https://google.github.io/adk-docs/get-started/installation

Install Google ADK package for Python using pip package manager. Optionally verify installation by displaying package information.

```bash
pip install google-adk
```

```bash
pip show google-adk
```

--------------------------------

### Verify ADK Installation with Version Command

Source: https://google.github.io/adk-docs/agents/config

Terminal command to verify that the ADK Python libraries are properly installed. This command displays the installed ADK version and confirms the installation was successful before proceeding with agent creation.

```bash
adk --version
```

--------------------------------

### Create and activate Python virtual environment

Source: https://google.github.io/adk-docs/get-started/installation

Create a Python virtual environment using venv and activate it with OS-specific commands. This isolates project dependencies and is recommended before installing ADK.

```bash
python -m venv .venv
```

```bash
# Mac / Linux
source .venv/bin/activate

# Windows CMD:
.venv\Scripts\activate.bat

# Windows PowerShell:
.venv\Scripts\Activate.ps1
```

--------------------------------

### Install Required Python Packages for ADK Computer Use Toolset

Source: https://google.github.io/adk-docs/tools/gemini-api/computer-use

This command installs the necessary Python libraries for the Computer Use Toolset, including `termcolor`, `playwright`, `browserbase`, and `rich`. These packages enable the agent to interact with web browsers and provide enhanced terminal output. Ensure a virtual environment is active before installation.

```bash
pip install termcolor==3.1.0
pip install playwright==1.52.0
pip install browserbase==1.3.0
pip install rich
```

--------------------------------

### FastAPI Application Setup for Cloud Run Deployment

Source: https://google.github.io/adk-docs/deploy/cloud-run

Python FastAPI application entry point (main.py) that initializes the ADK FastAPI app using get_fast_api_app(). Configures session service URI, CORS allowed origins, and web interface serving. Uses uvicorn to run the server on a port specified by Cloud Run environment variable or defaults to 8080.

```python
import os

import uvicorn
from fastapi import FastAPI
from google.adk.cli.fast_api import get_fast_api_app

# Get the directory where main.py is located
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
# Example session service URI (e.g., SQLite)
# Note: Use 'sqlite+aiosqlite' instead of 'sqlite' because DatabaseSessionService requires an async driver
SESSION_SERVICE_URI = "sqlite+aiosqlite:///./sessions.db"
# Example allowed origins for CORS
ALLOWED_ORIGINS = ["http://localhost", "http://localhost:8080", "*"]
# Set web=True if you intend to serve a web interface, False otherwise
SERVE_WEB_INTERFACE = True

# Call the function to get the FastAPI app instance
# Ensure the agent directory name ('capital_agent') matches your agent folder
app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    session_service_uri=SESSION_SERVICE_URI,
    allow_origins=ALLOWED_ORIGINS,
    web=SERVE_WEB_INTERFACE,
)

# You can add more FastAPI routes or configurations below if needed
# Example:
# @app.get("/hello")
# async def read_root():
#     return {"Hello": "World"}

if __name__ == "__main__":
    # Use the PORT environment variable provided by Cloud Run, defaulting to 8080
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
```

--------------------------------

### Example Usage of LLM Agent for Stock Price Queries (Java)

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This main method provides example calls to the callAgent function, demonstrating how to query the LLM agent for stock prices with different types of prompts, including valid symbols, invalid symbols, and company names requiring symbol lookup.

```java
  public static void main(String[] args) {
    callAgent("stock price of GOOG");
    callAgent("What's the price of MSFT?");
    callAgent("Can you find the stock price for an unknown company XYZ?");
  }
```

--------------------------------

### Install TypeScript ADK with npm

Source: https://google.github.io/adk-docs/get-started/installation

Install Google ADK and ADK DevTools packages for TypeScript/Node.js projects using npm package manager.

```bash
npm install @google/adk @google/adk-devtools
```

--------------------------------

### Python Example: Customizing AgentTool with skip_summarization

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This comprehensive Python example showcases the creation of a `summary_agent` and a `root_agent` that utilizes the `summary_agent` as a tool. It specifically highlights the use of the `skip_summarization` attribute within `AgentTool` to prevent the framework from performing LLM-based summarization on the tool's response. The example also includes session management and asynchronous agent interaction.

```Python
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.agent_tool import AgentTool
from google.genai import types

APP_NAME="summary_agent"
USER_ID="user1234"
SESSION_ID="1234"

summary_agent = Agent(
    model="gemini-2.0-flash",
    name="summary_agent",
    instruction="""You are an expert summarizer. Please read the following text and provide a concise summary.""",
    description="Agent to summarize text",
)

root_agent = Agent(
    model='gemini-2.0-flash',
    name='root_agent',
    instruction="""You are a helpful assistant. When the user provides a text, use the 'summarize' tool to generate a summary. Always forward the user's message exactly as received to the 'summarize' tool, without modifying or summarizing it yourself. Present the response from the tool to the user.""",
    tools=[AgentTool(agent=summary_agent, skip_summarization=True)]
)

# Session and Runner
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=root_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner


# Agent Interaction
async def call_agent_async(query):
    content = types.Content(role='user', parts=[types.Part(text=query)])
    session, runner = await setup_session_and_runner()
    events = runner.run_async(user_id=USER_ID, session_id=SESSION_ID, new_message=content)

    async for event in events:
        if event.is_final_response():
            final_response = event.content.parts[0].text
            print("Agent Response: ", final_response)


long_text = """Quantum computing represents a fundamentally different approach to computation, 
leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers 
that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively 
being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled, 
meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and 
interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such 
as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far 
faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages."""


# Note: In Colab, you can directly use 'await' at the top level.

```

--------------------------------

### Define an LLM Agent's Basic Identity and Purpose in ADK

Source: https://google.github.io/adk-docs/agents/llm-agents

These examples demonstrate how to instantiate an `LlmAgent` by defining its basic identity and purpose across various programming languages. It requires specifying a unique `name`, an optional `description` for multi-agent systems, and the underlying `model` (e.g., 'gemini-2.5-flash') that powers the agent's reasoning. This initial setup establishes the agent's core function before adding instructions or tools.

```python
# Example: Defining the basic identity
capital_agent = LlmAgent(
    model="gemini-2.5-flash",
    name="capital_agent",
    description="Answers user questions about the capital city of a given country."
    # instruction and tools will be added next
)
```

```typescript
// Example: Defining the basic identity
const capitalAgent = new LlmAgent({
    model: 'gemini-2.5-flash',
    name: 'capital_agent',
    description: 'Answers user questions about the capital city of a given country.',
    // instruction and tools will be added next
});
```

```go
// Example: Defining the basic identity
agent, err := llmagent.New(llmagent.Config{
    Name:        "capital_agent",
    Model:       model,
    Description: "Answers user questions about the capital city of a given country.",
    // instruction and tools will be added next
})
```

```java
// Example: Defining the basic identity
LlmAgent capitalAgent =
    LlmAgent.builder()
        .model("gemini-2.5-flash")
        .name("capital_agent")
        .description("Answers user questions about the capital city of a given country.")
        // instruction and tools will be added next
        .build();
```

--------------------------------

### Define `beforeRunCallback` for ADK Runner Initialization (TypeScript)

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LoggingPlugin

This callback is executed before the ADK runner starts, making it the first callback in the lifecycle. It is ideal for global setup or initialization tasks. Returning a `Content` object will halt the runner's execution with that event; returning `undefined` allows the runner to proceed normally.

```typescript
beforeRunCallback(
  invocationContext: { invocationContext: InvocationContext },
): Promise<Content | undefined>
```

--------------------------------

### Install Go Module for MCP Toolbox SDK

Source: https://google.github.io/adk-docs/tools/google-cloud/mcp-toolbox-for-databases

This command installs the `mcp-toolbox-sdk-go` Go module, which is required for ADK to interact with Toolbox services in Go applications. It fetches the necessary dependencies for Toolbox integration.

```go
go get github.com/googleapis/mcp-toolbox-sdk-go
```

--------------------------------

### Platform Compatibility Matrix

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Reference guide for proactivity and affective dialog feature support across different Gemini Live API and Vertex AI platforms, including model-specific requirements and limitations.

```APIDOC
## Platform Compatibility for Proactivity and Affective Dialog

### Description
Details the platform and model-specific support for proactive audio and affective dialog features across Gemini Live API and Vertex AI implementations.

### Gemini Live API Support

#### Supported Models
- **gemini-2.5-flash-native-audio-preview-12-2025** (Native Audio Model)
  - ✅ Proactivity: Supported
  - ✅ Affective Dialog: Supported
  - ✅ Recommended for these features

#### Unsupported Models
- **gemini-live-2.5-flash-preview** (Half-Cascade Model)
  - ❌ Proactivity: Not Supported
  - ❌ Affective Dialog: Not Supported
  - ⚠️ Use native audio model instead

### Vertex AI Live API Support

#### Current Status
- **gemini-live-2.5-flash** (Half-Cascade Model)
  - ❌ Proactivity: Not Supported
  - ❌ Affective Dialog: Not Supported
  - ⚠️ Native audio models not currently available on Vertex AI

### Key Insights

#### Model Type Requirements
- **Native Audio Models**: Required for proactivity and affective dialog
- **Half-Cascade Models**: Do not support these features on any platform

#### Platform Availability
- Proactivity and affective dialog features are currently exclusive to Gemini Live API
- Vertex AI Live API does not yet support these features
- Native audio models are only available on Gemini Live API

#### Migration Path
If your application requires proactive audio or affective dialog:
1. Use Gemini Live API (not Vertex AI)
2. Use native audio model: `gemini-2.5-flash-native-audio-preview-12-2025`
3. Avoid half-cascade models on either platform

### Compatibility Decision Tree

#### Do you need proactivity or affective dialog?
- **YES** → Use Gemini Live API with `gemini-2.5-flash-native-audio-preview-12-2025`
- **NO** → Can use any supported model on either platform

#### Are you on Vertex AI?
- **YES** → These features not currently available; consider Gemini Live API
- **NO** → Proceed with Gemini Live API native audio model

#### Using half-cascade model?
- **YES** → Upgrade to native audio model for feature support
- **NO** → Verify you're using native audio model variant
```

--------------------------------

### Initialize PubSubToolset with ADK Agent - Python

Source: https://google.github.io/adk-docs/tools/google-cloud/pubsub

Sets up a Pub/Sub toolset with credentials configuration and creates an ADK agent with Pub/Sub capabilities. The example demonstrates how to configure the tool with Google Cloud project settings, authenticate using Application Default Credentials, and instantiate the agent with Pub/Sub tools.

```python
import asyncio
import os

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.pubsub.config import PubSubToolConfig
from google.adk.tools.pubsub.pubsub_credentials import PubSubCredentialsConfig
from google.adk.tools.pubsub.pubsub_toolset import PubSubToolset
from google.genai import types
import google.auth

# Define constants for this example agent
AGENT_NAME = "pubsub_agent"
APP_NAME = "pubsub_app"
USER_ID = "user1234"
SESSION_ID = "1234"
GEMINI_MODEL = "gemini-2.0-flash"

# Define Pub/Sub tool config.
tool_config = PubSubToolConfig(project_id=os.getenv("GOOGLE_CLOUD_PROJECT"))

# Uses externally-managed Application Default Credentials (ADC) by default.
application_default_credentials, _ = google.auth.default()
credentials_config = PubSubCredentialsConfig(
    credentials=application_default_credentials
)

# Instantiate a Pub/Sub toolset
pubsub_toolset = PubSubToolset(
    credentials_config=credentials_config, pubsub_tool_config=tool_config
)

# Agent Definition
pubsub_agent = Agent(
    model=GEMINI_MODEL,
    name=AGENT_NAME,
    description=(
        "Agent to publish, pull, and acknowledge messages from Google Cloud"
        " Pub/Sub."
    ),
    instruction="""\
        You are a cloud engineer agent with access to Google Cloud Pub/Sub tools.
        You can publish messages to topics, pull messages from subscriptions, and acknowledge messages.
    """,
    tools=[pubsub_toolset],
)
```

--------------------------------

### Main Entry Point with Agent Execution

Source: https://google.github.io/adk-docs/agents/custom-agents

Sets up the runner and session, then calls the agent with a story topic. Orchestrates the complete workflow from initialization to final response capture.

```typescript
async function main() {
  const runner = await setupRunnerAndSession();
  await callAgent(runner, "a lonely robot finding a friend in a junkyard");
}

main();
```

--------------------------------

### Install OpenInference and ADK Packages

Source: https://google.github.io/adk-docs/observability/phoenix

Installs necessary Python packages for OpenInference instrumentation, Google ADK, and Arize Phoenix OpenTelemetry integration. This is a prerequisite for enabling observability.

```bash
pip install openinference-instrumentation-google-adk google-adk arize-phoenix-otel
```

--------------------------------

### Expose A2A Agent with Custom Agent Card JSON File

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Converts an ADK agent to A2A compatible format using a custom agent card definition loaded from a JSON file path. This method separates agent card configuration from code for easier maintenance and reusability.

```python
from google.adk.a2a.utils.agent_to_a2a import to_a2a

# Reference to custom agent card JSON file path
```

--------------------------------

### Main Entry Point for Live Audio Conversation in Java

Source: https://google.github.io/adk-docs/get-started/streaming/quickstart-streaming-java

Entry point that instantiates the LiveAudioRun class and initiates a conversation. This method is called to start the bidirectional audio communication process between microphone input and speaker output.

```java
public static void main(String[] args) throws Exception {
  LiveAudioRun liveAudioRun = new LiveAudioRun();
  liveAudioRun.runConversation();
}
```

--------------------------------

### Install OpenInference, Google ADK, and Arize OTEL Packages

Source: https://google.github.io/adk-docs/observability/arize-ax

Installs the necessary Python packages for OpenInference instrumentation, Google ADK, and Arize OTEL. These are the core dependencies for enabling observability.

```bash
pip install openinference-instrumentation-google-adk google-adk arize-otel
```

--------------------------------

### Setup Session and Runner for Agent Execution in Python

Source: https://google.github.io/adk-docs/tools/function-tools

Python async function that initializes an InMemorySessionService and creates a Runner instance for executing the reimbursement agent. This setup is required for managing agent sessions and handling asynchronous execution of agent workflows.

```python
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=file_processor_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner
```

--------------------------------

### Implement Tool Confirmation with ToolContext in Python

Source: https://google.github.io/adk-docs/tools-custom/confirmation

Create a Python tool function that uses ToolContext to request user confirmation before processing. The function checks for existing confirmation, requests approval with a hint message and payload structure, and processes the response accordingly. This example demonstrates a time-off request approval workflow.

```python
def request_time_off(days: int, tool_context: ToolContext):
  """Request day off for the employee."""
  ...
  tool_confirmation = tool_context.tool_confirmation
  if not tool_confirmation:
    tool_context.request_confirmation(
        hint=(
            'Please approve or reject the tool call request_time_off() by'
            ' responding with a FunctionResponse with an expected'
            ' ToolConfirmation payload.'
        ),
        payload={
            'approved_days': 0,
        },
    )
    # Return intermediate status indicating that the tool is waiting for
    # a confirmation response:
    return {'status': 'Manager approval is required.'}

  approved_days = tool_confirmation.payload['approved_days']
  approved_days = min(approved_days, days)
  if approved_days == 0:
    return {'status': 'The time off request is rejected.', 'approved_days': 0}
  return {
      'status': 'ok',
      'approved_days': approved_days,
  }
```

--------------------------------

### Install AgentOps Package

Source: https://google.github.io/adk-docs/observability/agentops

Installs the AgentOps Python package using pip. This is the first step to integrating AgentOps into your project. Ensure you have pip installed and updated.

```shell
pip install -U agentops

```

--------------------------------

### Initialize Node.js Project

Source: https://google.github.io/adk-docs/grounding/google_search_grounding

Command to create a new Node.js project, generating a package.json file with default settings. This is a standard first step for any Node.js development, preparing the environment for package installations like the ADK.

```bash
npm init -y
```

--------------------------------

### Complete LlmAgent Configuration and Comparison Example in Python

Source: https://google.github.io/adk-docs/agents/llm-agents

This comprehensive Python example showcases the configuration and usage of two distinct `LlmAgent` instances. One agent (`capital_agent_with_tool`) leverages a custom `get_capital_city` tool for dynamic information retrieval, while the other (`structured_info_agent_schema`) enforces a specific `CapitalInfoOutput` Pydantic schema for its responses, demonstrating the trade-offs and capabilities between tool integration and structured output enforcement.

```python
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# --- Full example code demonstrating LlmAgent with Tools vs. Output Schema ---
import json # Needed for pretty printing dicts
import asyncio 

from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from pydantic import BaseModel, Field

# --- 1. Define Constants ---
APP_NAME = "agent_comparison_app"
USER_ID = "test_user_456"
SESSION_ID_TOOL_AGENT = "session_tool_agent_xyz"
SESSION_ID_SCHEMA_AGENT = "session_schema_agent_xyz"
MODEL_NAME = "gemini-2.0-flash"

# --- 2. Define Schemas ---

# Input schema used by both agents
class CountryInput(BaseModel):
    country: str = Field(description="The country to get information about.")

# Output schema ONLY for the second agent
class CapitalInfoOutput(BaseModel):
    capital: str = Field(description="The capital city of the country.")
    # Note: Population is illustrative; the LLM will infer or estimate this
    # as it cannot use tools when output_schema is set.
    population_estimate: str = Field(description="An estimated population of the capital city.")

# --- 3. Define the Tool (Only for the first agent) ---
def get_capital_city(country: str) -> str:
    """Retrieves the capital city of a given country."""
    print(f"\n-- Tool Call: get_capital_city(country='{country}') --")
    country_capitals = {
        "united states": "Washington, D.C.",
        "canada": "Ottawa",
        "france": "Paris",
        "japan": "Tokyo",
    }
    result = country_capitals.get(country.lower(), f"Sorry, I couldn't find the capital for {country}.")
    print(f"-- Tool Result: '{result}' --")
    return result

# --- 4. Configure Agents ---

# Agent 1: Uses a tool and output_key
capital_agent_with_tool = LlmAgent(
    model=MODEL_NAME,
    name="capital_agent_tool",
    description="Retrieves the capital city using a specific tool.",
    instruction="""You are a helpful agent that provides the capital city of a country using a tool.\nThe user will provide the country name in a JSON format like {\"country\": \"country_name\"}.\n1. Extract the country name.\n2. Use the `get_capital_city` tool to find the capital.\n3. Respond clearly to the user, stating the capital city found by the tool.\n""",
    tools=[get_capital_city],
    input_schema=CountryInput,
    output_key="capital_tool_result", # Store final text response
)

# Agent 2: Uses output_schema (NO tools possible)
structured_info_agent_schema = LlmAgent(
    model=MODEL_NAME,
    name="structured_info_agent_schema",
    description="Provides capital and estimated population in a specific JSON format.",
    instruction=f"""You are an agent that provides country information.\nThe user will provide the country name in a JSON format like {{\"country\": \"country_name\"}}.\nRespond ONLY with a JSON object matching this exact schema:\n{json.dumps(CapitalInfoOutput.model_json_schema(), indent=2)}\nUse your knowledge to determine the capital and estimate the population. Do not use any tools.\n""",
    # *** NO tools parameter here - using output_schema prevents tool use ***
    input_schema=CountryInput,
    output_schema=CapitalInfoOutput, # Enforce JSON output structure
    output_key="structured_info_result", # Store final JSON response
)

# --- 5. Set up Session Management and Runners ---
session_service = InMemorySessionService()

# Create a runner for EACH agent
capital_runner = Runner(
    agent=capital_agent_with_tool,
    app_name=APP_NAME,
    session_service=session_service
)
structured_runner = Runner(
    agent=structured_info_agent_schema,
    app_name=APP_NAME,
    session_service=session_service
)
```

--------------------------------

### Define ADK Agent Code in Java

Source: https://google.github.io/adk-docs/get-started/java

This Java code defines a basic `LlmAgent` named 'hello-time-agent' using the Agent Development Kit (ADK). It includes a `getCurrentTime` `FunctionTool` that mocks retrieving the current time for a specified city, demonstrating how to set up an agent with a description, instructions, a model, and associated tools. This code should be placed in `HelloTimeAgent.java`.

```Java
package com.example.agent;

import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.LlmAgent;
import com.google.adk.tools.Annotations.Schema;
import com.google.adk.tools.FunctionTool;

import java.util.Map;

public class HelloTimeAgent {

    public static BaseAgent ROOT_AGENT = initAgent();

    private static BaseAgent initAgent() {
        return LlmAgent.builder()
            .name("hello-time-agent")
            .description("Tells the current time in a specified city")
            .instruction("""
                You are a helpful assistant that tells the current time in a city.
                Use the 'getCurrentTime' tool for this purpose.
                """)
            .model("gemini-2.5-flash")
            .tools(FunctionTool.create(HelloTimeAgent.class, "getCurrentTime"))
            .build();
    }

    /** Mock tool implementation */
    @Schema(description = "Get the current time for a given city")
    public static Map<String, String> getCurrentTime(
        @Schema(name = "city", description = "Name of the city to get the time for") String city) {
        return Map.of(
            "city", city,
            "forecast", "The time is 10:30am."
        );
    }
}
```

--------------------------------

### Implement afterToolCallback in ADK Agent (TypeScript)

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

This comprehensive TypeScript example sets up an ADK `LlmAgent` with a `FunctionTool` to find capital cities. It integrates an `afterToolCallback` named `simpleAfterToolModifier` that inspects and modifies the tool's response, specifically adding a note when the capital is Washington, D.C. The snippet includes agent definition, tool creation, callback implementation, and the `InMemoryRunner` setup to simulate agent interaction.

```typescript
/**
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import {
  LlmAgent,
  InMemoryRunner,
  FunctionTool,
  isFinalResponse,
  ToolContext,
  BaseTool,
} from "@google/adk";
import { createUserContent } from "@google/genai";
import { z } from "zod";

const MODEL_NAME = "gemini-2.5-flash";
const APP_NAME = "after_tool_callback_app";
const USER_ID = "test_user_after_tool";
const SESSION_ID = "session_001";

// --- Define a Simple Tool Function ---
const CountryInput = z.object({
  country: z.string().describe("The country to get the capital for."),
});

async function getCapitalCity(
  params: z.infer<typeof CountryInput>,
): Promise<{ result: string }> {
  console.log(`--- Tool 'get_capital_city' executing with country: ${params.country} ---`);
  const countryCapitals: Record<string, string> = {
    "united states": "Washington, D.C.",
    "canada": "Ottawa",
    "france": "Paris",
    "germany": "Berlin",
  };
  const result = countryCapitals[params.country.toLowerCase()] ?? `Capital not found for ${params.country}`;
  return { result };
}

// --- Wrap the function into a Tool ---
const capitalTool = new FunctionTool({
  name: "get_capital_city",
  description: "Retrieves the capital city for a given country",
  parameters: CountryInput,
  execute: getCapitalCity,
});

// --- Define the Callback Function ---
function simpleAfterToolModifier({
  tool,
  args,
  context,
  response,
}: {
  tool: BaseTool;
  args: Record<string, any>;
  context: ToolContext;
  response: Record<string, any>;
}) {
  const agentName = context.agentName;
  const toolName = tool.name;
  console.log(`[Callback] After tool call for tool '${toolName}' in agent '${agentName}'`);
  console.log(`[Callback] Original args: ${args}`);

  const originalResultValue = response?.result || "";

  // --- Modification Example ---
  if (toolName === "get_capital_city" && originalResultValue === "Washington, D.C.") {
    const modifiedResponse = JSON.parse(JSON.stringify(response));
    modifiedResponse.result = `${originalResultValue} (Note: This is the capital of the USA).`;
    modifiedResponse["note_added_by_callback"] = true;

    console.log(
      `[Callback] Modified response: ${JSON.stringify(modifiedResponse)}`
    );
    return modifiedResponse;
  }

  console.log('[Callback] Passing original tool response through.');
  return undefined;
};

// Create LlmAgent and Assign Callback
const myLlmAgent = new LlmAgent({
  name: "AfterToolCallbackAgent",
  model: MODEL_NAME,
  instruction: "You are an agent that finds capital cities using the get_capital_city tool. Report the result clearly.",
  description: "An LLM agent demonstrating after_tool_callback",
  tools: [capitalTool],
  afterToolCallback: simpleAfterToolModifier,
});

// Agent Interaction Logic
async function callAgentAndPrint(
  runner: InMemoryRunner,
  agent: LlmAgent,
  sessionId: string,
  query: string,
) {
  console.log(`\n>>> Calling Agent: '${agent.name}' | Query: ${query}`);

  let finalResponseContent = "";
  for await (const event of runner.runAsync({
    userId: USER_ID,
    sessionId: sessionId,
    newMessage: createUserContent(query),
  })) {
    const authorName = event.author || "System";
    if (isFinalResponse(event) && event.content?.parts?.length) {
      finalResponseContent = 'The capital of the united states is Washington, D.C. (Note: This is the capital of the USA).';
      console.log(`--- Output from: ${authorName} ---`);
    } else if (event.errorMessage) {
      console.log(`  -> Error from ${authorName}: ${event.errorMessage}`);
    }
  }
  console.log(`<<< Agent '${agent.name}' Response: ${finalResponseContent}`);
}

// Run Interactions
async function main() {
  const runner = new InMemoryRunner({ appName: APP_NAME, agent: myLlmAgent });

  await runner.sessionService.createSession({
    appName: APP_NAME,
    userId: USER_ID,
    sessionId: SESSION_ID,
  });

  await callAgentAndPrint(runner, myLlmAgent, SESSION_ID, "united states");
}

main();
```

--------------------------------

### Set Gemini API Key in Environment Variables

Source: https://google.github.io/adk-docs/get-started/java

Configure the GOOGLE_API_KEY environment variable by writing it to a .env file (macOS/Linux) or env.bat file (Windows). This allows the ADK project to authenticate with the Gemini API.

```bash
echo 'export GOOGLE_API_KEY="YOUR_API_KEY"' > .env
```

```batch
echo 'set GOOGLE_API_KEY="YOUR_API_KEY"' > env.bat
```

--------------------------------

### Initialize and Run ADK Weather Sentiment Agent in Java

Source: https://google.github.io/adk-docs/tools-custom

This `main` method serves as the entry point for the ADK weather sentiment agent application. It sets up `FunctionTool`s by reflecting on the `getWeatherReport` and `analyzeSentiment` methods. It then constructs an `LlmAgent` with these tools and a specific instruction, and finally uses a `Runner` to execute several example queries, demonstrating the agent's capabilities.

```java
import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.LlmAgent;
import com.google.adk.runner.Runner;
import com.google.adk.sessions.InMemorySessionService;
import com.google.adk.sessions.Session;
import com.google.adk.tools.Annotations.Schema;
import com.google.adk.tools.FunctionTool;
import com.google.adk.tools.ToolContext; // Ensure this import is correct
import com.google.common.collect.ImmutableList;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class WeatherSentimentAgentApp {

  private static final String APP_NAME = "weather_sentiment_agent";
  private static final String USER_ID = "user1234";
  private static final String SESSION_ID = "1234";
  private static final String MODEL_ID = "gemini-2.0-flash";

  public static void main(String[] args) throws NoSuchMethodException {
    FunctionTool weatherTool =
        FunctionTool.create(
            WeatherSentimentAgentApp.class.getMethod(
                "getWeatherReport", String.class, ToolContext.class));
    FunctionTool sentimentTool =
        FunctionTool.create(
            WeatherSentimentAgentApp.class.getMethod(
                "analyzeSentiment", String.class, ToolContext.class));

    BaseAgent weatherSentimentAgent =
        LlmAgent.builder()
            .model(MODEL_ID)
            .name("weather_sentiment_agent")
            .description("Weather Sentiment Agent")
            .instruction("""
                    You are a helpful assistant that provides weather information and analyzes the
                    sentiment of user feedback
                    """)
            .tools(ImmutableList.of(weatherTool, sentimentTool))
            .build();

    Runner runner = Runner.builder().withAgent(weatherSentimentAgent).build();

    System.out.println("\n--- Query 1: Weather in London ---");
    callAgent(runner, "What's the weather like in London?");

    System.out.println("\n--- Query 2: Weather in Paris ---");
    callAgent(runner, "How's the weather in Paris?");

    System.out.println("\n--- Query 3: Weather in Berlin (unsupported) ---");
    callAgent(runner, "What about Berlin?");

    System.out.println("\n--- Query 4: Sentiment Analysis (positive) ---");
    callAgent(runner, "The weather is good today.");

    System.out.println("\n--- Query 5: Sentiment Analysis (negative) ---");
    callAgent(runner, "I don't like the rain.");

    System.out.println("\n--- Query 6: Combined Query ---");
    callAgent(runner, "How's the weather in London, and what do you think about 'It's rainy'?");

    // Example of a follow-up interaction (if session state was persisted and used)
    // For this example, each callAgent creates a new session implicitly due to InMemorySessionService
    // and the way it's used in `callAgent`.
  }
}
```

--------------------------------

### Initialize VertexAiSessionService with Google Cloud

Source: https://google.github.io/adk-docs/sessions/session

Sets up a VertexAiSessionService for scalable production applications using Google Cloud Vertex AI infrastructure. Requires Google Cloud project setup, authentication, storage bucket, and Reasoning Engine resource configuration.

```Python
# Requires: pip install google-adk[vertexai]
# Plus GCP setup and authentication
from google.adk.sessions import VertexAiSessionService

PROJECT_ID = "your-gcp-project-id"
LOCATION = "us-central1"
# The app_name used with this service should be the Reasoning Engine ID or name
REASONING_ENGINE_APP_NAME = "projects/your-gcp-project-id/locations/us-central1/reasoningEngines/your-engine-id"

session_service = VertexAiSessionService(project=PROJECT_ID, location=LOCATION)
# Use REASONING_ENGINE_APP_NAME when calling service methods, e.g.:
```

--------------------------------

### Simulating Agent Tool Usage in Go

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This Go example demonstrates how to set up an AI agent (a 'main agent') to delegate summarization tasks to another specialized AI agent (a 'summarizer agent') by wrapping the latter as an `AgentTool`. It illustrates the creation of both agents, configuring the main agent with the summarizer tool, and running a simulation with a text summarization prompt.

```go
        Name:  "MainAgent",
        Model: model,
        Instruction: "You are a helpful assistant. If you are asked to summarize a long text, use the 'summarize' tool. " +
            "After getting the summary, present it to the user by saying 'Here is a summary of the text:'.",
        Description: "The main agent that can delegate tasks.",
        Tools:       tools,
    })
}

func RunAgentAsToolSimulation() {
    ctx := context.Background()

    // 1. Create the Tool Agent (Summarizer)
    summarizerAgent, err := createSummarizerAgent(ctx)
    if err != nil {
        log.Fatalf("Failed to create summarizer agent: %v", err)
    }

    // 2. Wrap the Tool Agent in an AgentTool
    summarizeTool := agenttool.New(summarizerAgent, &agenttool.Config{
        SkipSummarization: true,
    })

    // 3. Create the Main Agent and provide it with the AgentTool
    mainAgent, err := createMainAgent(ctx, summarizeTool)
    if err != nil {
        log.Fatalf("Failed to create main agent: %v", err)
    }

    // 4. Run the main agent
    prompt := `
        Please summarize this text for me:
        Quantum computing represents a fundamentally different approach to computation,
        leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers
        that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively
        being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled,
        meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and
        interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such
        as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far
        faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages.
    `
    fmt.Printf("\nPrompt: %s\nResponse: ", prompt)
    callAgent(context.Background(), mainAgent, prompt)
    fmt.Println("\n---")
}
```

--------------------------------

### Implement ADK Agent with Launcher Framework in Go

Source: https://google.github.io/adk-docs/deploy/cloud-run

This Go code demonstrates the required structure for an `adkgo` agent's `main.go` file, leveraging the `launcher` framework. It defines a `getCapitalCity` function as a tool, integrates it into an `llmagent`, and registers this agent with the `adk` launcher to handle specific command-line arguments for service startup.

```go
// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
    "context"
    "fmt"
    "log"
    "os"
    "strings"

    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/cmd/launcher"
    "google.golang.org/adk/cmd/launcher/full"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/functiontool"
    "google.golang.org/genai"
)

type getCapitalCityArgs struct {
    Country string `json:"country" jsonschema:"The country for which to find the capital city."`
}

func getCapitalCity(ctx tool.Context, args getCapitalCityArgs) (string, error) {
    capitals := map[string]string{
        "united states": "Washington, D.C.",
        "canada":        "Ottawa",
        "france":        "Paris",
        "japan":         "Tokyo",
    }
    capital, ok := capitals[strings.ToLower(args.Country)]
    if !ok {
        return "", fmt.Errorf("couldn't find the capital for %s", args.Country)
    }

    return capital, nil
}

func main() {
    ctx := context.Background()

    model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{
        APIKey: os.Getenv("GOOGLE_API_KEY"),
    })
    if err != nil {
        log.Fatalf("Failed to create model: %v", err)
    }

    capitalTool, err := functiontool.New(
        functiontool.Config{
            Name:        "get_capital_city",
            Description: "Retrieves the capital city for a given country.",
        },
        getCapitalCity,
    )
    if err != nil {
        log.Fatalf("Failed to create function tool: %v", err)
    }

    geoAgent, err := llmagent.New(llmagent.Config{
        Name:        "capital_agent",
        Model:       model,
        Description: "Agent to find the capital city of a country.",
        Instruction: "I can answer your questions about the capital city of a country.",
        Tools:       []tool.Tool{capitalTool},
    })
    if err != nil {
        log.Fatalf("Failed to create agent: %v", err)
    }

    config := &launcher.Config{
        AgentLoader: agent.NewSingleLoader(geoAgent),
    }

    l := full.NewLauncher()
    err = l.Execute(ctx, config, os.Args[1:])
    if err != nil {
        log.Fatalf("run failed: %v\n\n%s", err, l.CommandLineSyntax())
    }
}
```

--------------------------------

### Example Queries for ADK Agent (Python)

Source: https://google.github.io/adk-docs/tools/google-cloud/spanner

These lines demonstrate how to use the 'call_agent' helper function to send various queries to the ADK agent. The examples show how to query for database tables, schema descriptions, and data within a specified Spanner instance and database.

```python
# Replace the Spanner database and table names below with your own.
call_agent("List all tables in projects/<PROJECT_ID>/instances/<INSTANCE_ID>/databases/<DATABASE_ID>")
call_agent("Describe the schema of <TABLE_NAME>")
call_agent("List the top 5 rows in <TABLE_NAME>")
```

--------------------------------

### Create A2A Agent with Custom AgentCard Object

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Exposes an ADK agent via A2A using a custom AgentCard object that specifies agent metadata, capabilities, skills, and supported input/output modes. This approach provides fine-grained control over the agent's A2A interface definition.

```python
from google.adk.a2a.utils.agent_to_a2a import to_a2a
from a2a.types import AgentCard

# Define A2A agent card
my_agent_card = AgentCard(
    name="file_agent",
    url="http://example.com",
    description="Test agent from file",
    version="1.0.0",
    capabilities={},
    skills=[],
    defaultInputModes=["text/plain"],
    defaultOutputModes=["text/plain"],
    supportsAuthenticatedExtendedCard=False,
)
a2a_app = to_a2a(root_agent, port=8001, agent_card=my_agent_card)
```

--------------------------------

### Install Python Dependencies for Weave and OpenTelemetry

Source: https://google.github.io/adk-docs/observability/weave

Installs the required Python packages: google-adk for agent development, and opentelemetry-sdk and opentelemetry-exporter-otlp-proto-http for trace export.

```shell
pip install google-adk opentelemetry-sdk opentelemetry-exporter-otlp-proto-http
```

--------------------------------

### Set API Key in Environment - macOS/Linux

Source: https://google.github.io/adk-docs/get-started/go

Exports the Gemini API key as an environment variable on Unix-like systems. Writes the GOOGLE_API_KEY export statement to a .env file for persistent configuration across terminal sessions.

```bash
echo 'export GOOGLE_API_KEY="YOUR_API_KEY"' > .env
```

--------------------------------

### Initialize and Run Java ADK Agent with InMemoryRunner

Source: https://google.github.io/adk-docs/context

This Java example illustrates how to set up an `LlmAgent` with specific instructions and tools, then initialize an `InMemoryRunner` to manage agent sessions. It includes code for creating a user session, handling user input, and processing agent events in an interactive loop.

```java
import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.InvocationContext;
import com.google.adk.agents.LlmAgent;
import com.google.adk.agents.runner.InMemoryRunner;
import com.google.adk.agents.session.Session;
import com.google.adk.events.Event;
import com.google.adk.util.Content;
import com.google.adk.util.Part;
import io.reactivex.rxjava3.core.Flowable;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

    LlmAgent root_agent =
        LlmAgent.builder()
            .model("gemini-***")
            .name("sample_agent")
            .description("Answers user questions.")
            .instruction(
                """
                provide instruction for the agent here.
                """
            )
            .tools(sampleTool) // Assuming sampleTool is defined elsewhere
            .outputKey("YOUR_KEY")
            .build();

    ConcurrentMap<String, Object> initialState = new ConcurrentHashMap<>();
    initialState.put("YOUR_KEY", "");

    // Assuming 'agent' variable refers to root_agent or a similar BaseAgent instance
    // For this example, we'll assume 'agent' is root_agent.
    BaseAgent agent = root_agent;
    InMemoryRunner runner = new InMemoryRunner(agent);
    String USER_ID = "user123"; // Example user ID
    String SESSION_ID = "session456"; // Example session ID

    Session session =
          runner
              .sessionService()
              .createSession(runner.appName(), USER_ID, initialState, SESSION_ID )
              .blockingGet();

   try (Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8)) {
        while (true) {
          System.out.print("\nYou > ");
          String userInput = scanner.nextLine();

          if ("quit".equalsIgnoreCase(userInput)) {
            break;
          }

          Content userMsg = Content.fromParts(Part.fromText(userInput));
          Flowable<Event> events =
                  runner.runAsync(session.userId(), session.id(), userMsg);

          System.out.print("\nAgent > ");
          events.blockingForEach(event ->
                  System.out.print(event.stringifyContent()));
      }
```

--------------------------------

### Setup async session and runner for OpenAPI agent

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Configures an async function that initializes an InMemorySessionService and Runner with the agent, creates a new session with user credentials, and returns the configured runner for agent interaction. This setup enables stateful agent conversations.

```Python
async def setup_session_and_runner():
    session_service_openapi = InMemorySessionService()
    runner_openapi = Runner(
        agent=root_agent,
        app_name=APP_NAME_OPENAPI,
        session_service=session_service_openapi,
    )
    await session_service_openapi.create_session(
        app_name=APP_NAME_OPENAPI,
        user_id=USER_ID_OPENAPI,
        session_id=SESSION_ID_OPENAPI,
    )
    return runner_openapi
```

--------------------------------

### Orchestrate parallel web research and synthesis with Python agents

Source: https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents

This comprehensive Python example sets up three `LlmAgent` instances, each specialized in researching a different topic (renewable energy, electric vehicles, carbon capture) using a Google Search tool. A `ParallelAgent` then executes these research agents concurrently. Finally, a 'merger_agent' synthesizes the results stored in the session state into a structured report, demonstrating a full parallel processing and aggregation workflow.

```python
# Part of agent.py --> Follow https://google.github.io/adk-docs/get-started/quickstart/ to learn the setup
# --- 1. Define Researcher Sub-Agents (to run in parallel) ---

# Researcher 1: Renewable Energy
researcher_agent_1 = LlmAgent(
    name="RenewableEnergyResearcher",
    model=GEMINI_MODEL,
    instruction="""You are an AI Research Assistant specializing in energy.
Research the latest advancements in 'renewable energy sources'.
Use the Google Search tool provided.
Summarize your key findings concisely (1-2 sentences).
Output *only* the summary.
""",
    description="Researches renewable energy sources.",
    tools=[google_search],
    # Store result in state for the merger agent
    output_key="renewable_energy_result"
)

# Researcher 2: Electric Vehicles
researcher_agent_2 = LlmAgent(
    name="EVResearcher",
    model=GEMINI_MODEL,
    instruction="""You are an AI Research Assistant specializing in transportation.
Research the latest developments in 'electric vehicle technology'.
Use the Google Search tool provided.
Summarize your key findings concisely (1-2 sentences).
Output *only* the summary.
""",
    description="Researches electric vehicle technology.",
    tools=[google_search],
    # Store result in state for the merger agent
    output_key="ev_technology_result"
)

# Researcher 3: Carbon Capture
researcher_agent_3 = LlmAgent(
    name="CarbonCaptureResearcher",
    model=GEMINI_MODEL,
    instruction="""You are an AI Research Assistant specializing in climate solutions.
Research the current state of 'carbon capture methods'.
Use the Google Search tool provided.
Summarize your key findings concisely (1-2 sentences).
Output *only* the summary.
""",
    description="Researches carbon capture methods.",
    tools=[google_search],
    # Store result in state for the merger agent
    output_key="carbon_capture_result"
)

# --- 2. Create the ParallelAgent (Runs researchers concurrently) ---
# This agent orchestrates the concurrent execution of the researchers.
# It finishes once all researchers have completed and stored their results in state.
parallel_research_agent = ParallelAgent(
    name="ParallelWebResearchAgent",
    sub_agents=[researcher_agent_1, researcher_agent_2, researcher_agent_3],
    description="Runs multiple research agents in parallel to gather information."
)

# --- 3. Define the Merger Agent (Runs *after* the parallel agents) ---
# This agent takes the results stored in the session state by the parallel agents
# and synthesizes them into a single, structured response with attributions.
merger_agent = LlmAgent(
    name="SynthesisAgent",
    model=GEMINI_MODEL,  # Or potentially a more powerful model if needed for synthesis
    instruction="""You are an AI Assistant responsible for combining research findings into a structured report.

Your primary task is to synthesize the following research summaries, clearly attributing findings to their source areas. Structure your response using headings for each topic. Ensure the report is coherent and integrates the key points smoothly.

**Crucially: Your entire response MUST be grounded *exclusively* on the information provided in the 'Input Summaries' below. Do NOT add any external knowledge, facts, or details not present in these specific summaries.**

**Input Summaries:**

*	**Renewable Energy:**
	{renewable_energy_result}

*	**Electric Vehicles:**
	{ev_technology_result}

*	**Carbon Capture:**
	{carbon_capture_result}

**Output Format:**

## Summary of Recent Sustainable Technology Advancements

### Renewable Energy Findings
(Based on RenewableEnergyResearcher's findings)
[Synthesize and elaborate *only* on the renewable energy input summary provided above.]

### Electric Vehicle Findings
(Based on EVResearcher's findings)
[Synthesize and elaborate *only* on the EV input summary provided above.]

### Carbon Capture Findings
(Based on CarbonCaptureResearcher's findings)
[Synthesize and elaborate *only* on the carbon capture input summary provided above.]

### Overall Conclusion
[Provide a brief (1-2 sentence) concluding statement that connects *only* the findings presented above.]

"""
```

--------------------------------

### ADK A2A Sample Project Folder Structure

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This snippet illustrates the typical directory structure for an ADK A2A sample project like `a2a_root`. It shows the organization of agent files, distinguishing between the root agent and remote A2A agents, and their respective locations within the project.

```plaintext
a2a_root/
├── remote_a2a/
│   └── hello_world/    
│       ├── __init__.py
│       └── agent.py    # Remote Hello World Agent
├── README.md
└── agent.py            # Root agent
```

--------------------------------

### Complete Maven POM Configuration for ADK Java Project

Source: https://google.github.io/adk-docs/get-started/java

This complete `pom.xml` configuration sets up a Maven project for an ADK Java agent. It defines project metadata, specifies Java 17 compatibility, and includes necessary ADK dependencies: `google-adk` for core functionalities and `google-adk-dev` for the development web UI, both at version `0.3.0`. This file is crucial for managing project dependencies and build settings.

```XML
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.agent</groupId>
    <artifactId>adk-agents</artifactId>
    <version>1.0-SNAPSHOT</version>

    <!-- Specify the version of Java you'll be using -->
    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- The ADK core dependency -->
        <dependency>
            <groupId>com.google.adk</groupId>
            <artifactId>google-adk</artifactId>
            <version>0.3.0</version>
        </dependency>
        <!-- The ADK dev web UI to debug your agent -->
        <dependency>
            <groupId>com.google.adk</groupId>
            <artifactId>google-adk-dev</artifactId>
            <version>0.3.0</version>
        </dependency>
    </dependencies>

</project>
```

--------------------------------

### Customer Service Bot with Proactivity and Affective Dialog

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Practical implementation example of a customer service bot configured to proactively assist customers and adapt responses based on detected emotional cues. Demonstrates bidirectional audio streaming with empathetic interaction patterns.

```APIDOC
## Customer Service Bot Implementation

### Description
Implements an empathetic customer service bot using Gemini Live API with proactive audio and affective dialog capabilities for improved customer interactions.

### Configuration

#### Required Parameters
- **response_modalities** (string[]) - Set to ["AUDIO"] for audio responses
- **streaming_mode** (StreamingMode) - Set to StreamingMode.BIDI for bidirectional streaming
- **proactivity** (ProactivityConfig) - Enable proactive_audio=True for proactive assistance
- **enable_affective_dialog** (boolean) - Set to True for emotional adaptation

### Setup Example
```
from google.genai import types
from google.adk.agents.run_config import RunConfig, StreamingMode

run_config = RunConfig(
    response_modalities=["AUDIO"],
    streaming_mode=StreamingMode.BIDI,
    proactivity=types.ProactivityConfig(proactive_audio=True),
    enable_affective_dialog=True
)
```

### Interaction Patterns

#### Example 1: Emotional Detection and Adaptation
**User Input:**
```
"I've been waiting for my order for three weeks..."
```

**Model Behavior:**
- Detects frustration in tone
- Adapts response style to be more empathetic
- Prioritizes resolution

**Expected Response:**
```
"I'm really sorry to hear about this delay. Let me check your order status right away. Can you provide your order number?"
```

#### Example 2: Proactive Assistance
**Model Behavior:**
- Recognizes previous customer inquiries
- Offers relevant follow-up assistance without being asked

**Expected Response:**
```
"I see you previously asked about shipping updates. Would you like me to set up notifications for future orders?"
```

### Important Considerations
- Proactive and affective behaviors are probabilistic
- Model's emotional awareness varies based on context and conversation history
- Inherent model variability affects consistency of responses
- Test thoroughly in production scenarios
```

--------------------------------

### Handle Sequential Workflow with BIDI Streaming - Python

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Recommended pattern for SequentialAgent with BIDI streaming that uses a single event loop and persistent queue for all agents. Captures continuous user input, handles audio/text output, and manages seamless agent transitions without explicit transition logic.

```python
async def handle_sequential_workflow():
    """Recommended pattern for SequentialAgent with BIDI streaming."""

    # 1. Single queue shared across all agents in the sequence
    queue = LiveRequestQueue()

    # 2. Background task captures user input continuously
    async def capture_user_input():
        while True:
            # Your logic to read audio from microphone
            audio_chunk = await microphone.read()
            queue.send_realtime(
                blob=types.Blob(data=audio_chunk, mime_type="audio/pcm")
            )

    input_task = asyncio.create_task(capture_user_input())

    try:
        # 3. Single event loop handles ALL agents seamlessly
        async for event in runner.run_live(
            user_id="user_123",
            session_id="session_456",
            live_request_queue=queue,
        ):
            # Events flow seamlessly across agent transitions
            current_agent = event.author

            # Handle audio and text output
            if event.content and event.content.parts:
                for part in event.content.parts:
                    # Check for audio data
                    if part.inline_data and part.inline_data.mime_type.startswith("audio/"):
                        # Your logic to play audio
            await play_audio(part.inline_data.data)

                    # Check for text data
                    if part.text:
                        await display_text(f"[{current_agent}] {part.text}")

            # No special transition handling needed!

    finally:
        input_task.cancel()
        queue.close()
```

--------------------------------

### Detailed AgentOps Initialization with Python

Source: https://google.github.io/adk-docs/observability/agentops

Provides a more detailed example of initializing the AgentOps SDK in Python. It demonstrates loading API keys from environment variables (using dotenv), setting a trace name, and optional configuration for auto-starting sessions.

```python
import agentops
import os
from dotenv import load_dotenv

# Load environment variables (optional, if you use a .env file for API keys)
load_dotenv()

agentops.init(
    api_key=os.getenv("AGENTOPS_API_KEY"), # Your AgentOps API Key
    trace_name="my-adk-app-trace"  # Optional: A name for your trace
    # auto_start_session=True is the default.
    # Set to False if you want to manually control session start/end.
)

```

--------------------------------

### Initialize ADK A2A Application from Agent Card File

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

This Python line initializes an ADK A2A application by converting a `root_agent` to an A2A compatible agent. It specifies the port for the A2A service and loads the agent's configuration from a local JSON file, typically an `agent-card.json`.

```python
a2a_app = to_a2a(root_agent, port=8001, agent_card="/path/to/your/agent-card.json")
```

--------------------------------

### Create and Initialize Google Maps Agent with McpToolset in Java

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

Demonstrates a complete Java implementation of a Maps agent that initializes an McpToolset for Google Maps, retrieves available tools, creates an LlmAgent configured with the Gemini model, and executes map-related prompts. The code handles session creation, asynchronous execution, and proper resource management with try-with-resources.

```java
package agents;

import com.google.adk.JsonBaseModel;
import com.google.adk.agents.LlmAgent;
import com.google.adk.agents.RunConfig;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.tools.mcp.McpTool;
import com.google.adk.tools.mcp.McpToolset;
import com.google.adk.tools.mcp.McpToolset.McpToolsAndToolsetResult;

import com.google.genai.types.Content;
import com.google.genai.types.Part;

import io.modelcontextprotocol.client.transport.ServerParameters;

import java.util.List;
import java.util.Map;
import java.util.Collections;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import java.util.Arrays;

public class MapsAgentCreator {

    /**
     * Initializes an McpToolset for Google Maps, retrieves tools,
     * creates an LlmAgent, sends a map-related prompt, and closes the toolset.
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        // TODO: Replace with your actual Google Maps API key, on a project with the Places API enabled.
        String googleMapsApiKey = "YOUR_GOOGLE_MAPS_API_KEY";

        Map<String, String> envVariables = new HashMap<>();
        envVariables.put("GOOGLE_MAPS_API_KEY", googleMapsApiKey);

        ServerParameters connectionParams = ServerParameters.builder("npx")
                .args(List.of(
                        "-y",
                        "@modelcontextprotocol/server-google-maps"
                ))
                .env(Collections.unmodifiableMap(envVariables))
                .build();

        try {
            CompletableFuture<McpToolsAndToolsetResult> futureResult =
                    McpToolset.fromServer(connectionParams, JsonBaseModel.getMapper());

            McpToolsAndToolsetResult result = futureResult.join();

            try (McpToolset toolset = result.getToolset()) {
                List<McpTool> tools = result.getTools();

                LlmAgent agent = LlmAgent.builder()
                        .model("gemini-2.0-flash")
                        .name("maps_assistant")
                        .description("Maps assistant")
                        .instruction("Help user with mapping and directions using available tools.")
                        .tools(tools)
                        .build();

                System.out.println("Agent created: " + agent.name());

                InMemoryRunner runner = new InMemoryRunner(agent);
                String userId = "maps-user-" + System.currentTimeMillis();
                String sessionId = "maps-session-" + System.currentTimeMillis();

                String promptText = "Please give me directions to the nearest pharmacy to Madison Square Garden.";

                try {
                    runner.sessionService().createSession(runner.appName(), userId, null, sessionId).blockingGet();
                    System.out.println("Session created: " + sessionId + " for user: " + userId);
                } catch (Exception sessionCreationException) {
                    System.err.println("Failed to create session: " + sessionCreationException.getMessage());
                    sessionCreationException.printStackTrace();
                    return;
                }

                Content promptContent = Content.fromParts(Part.fromText(promptText));

                System.out.println("\nSending prompt: \"" + promptText + "\" to agent...\n");

                runner.runAsync(userId, sessionId, promptContent, RunConfig.builder().build())
                        .blockingForEach(event -> {
                            System.out.println("Event received: " + event.toJson());
                        });
            }
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
```

--------------------------------

### Install Anthropic Client Library for Vertex AI Integration

Source: https://google.github.io/adk-docs/agents/models/vertex

This command installs the `anthropic` Python client library with the `vertex` extra, which is necessary for integrating Anthropic models via Vertex AI. This dependency allows the ADK framework to interact with Claude models hosted on Vertex AI. Ensure this library is installed in your environment before using Claude models.

```bash
pip install "anthropic[vertex]"
```

--------------------------------

### Java Examples Class and processRequest Method

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/flows/llmflows/Examples

Defines the Examples class which extends Object and implements RequestProcessor. It includes a constructor and the processRequest method to handle LLM requests, returning a Single of RequestProcessingResult. This is part of the pre-processing stage for LLM requests.

```java
public final class Examples extends Object implements RequestProcessor {
  public Examples();
  public io.reactivex.rxjava3.core.Single<RequestProcessor.RequestProcessingResult> processRequest(InvocationContext context, LlmRequest request);
}
```

--------------------------------

### Define Agent with Tool in Python

Source: https://google.github.io/adk-docs/get-started/python

Creates a root_agent using the Agent class with a custom tool implementation. The agent is configured with a model, name, description, instructions, and a get_current_time tool that returns city-specific time information as a mock implementation.

```python
from google.adk.agents.llm_agent import Agent

# Mock tool implementation
def get_current_time(city: str) -> dict:
    """Returns the current time in a specified city."""
    return {"status": "success", "city": city, "time": "10:30 AM"}

root_agent = Agent(
    model='gemini-3-flash-preview',
    name='root_agent',
    description="Tells the current time in a specified city.",
    instruction="You are a helpful assistant that tells the current time in cities. Use the 'get_current_time' tool for this purpose.",
    tools=[get_current_time],
)
```

--------------------------------

### Initialize Agent, Session, and Runner - Go

Source: https://google.github.io/adk-docs/tools/function-tools

Sets up the Google ADK agent environment including context creation, agent initialization, in-memory session service, and runner configuration. Handles errors at each initialization step and prepares the system for multi-turn agent interactions.

```go
ctx := context.Background()
ticketAgent, err := createTicketAgent(ctx)
if err != nil {
    log.Fatalf("Failed to create agent: %v", err)
}

// Setup the runner and session.
sessionService := session.InMemoryService()
session, err := sessionService.Create(ctx, &session.CreateRequest{AppName: appName, UserID: userID})
if err != nil {
    log.Fatalf("Failed to create session: %v", err)
}
r, err := runner.New(runner.Config{AppName: appName, Agent: ticketAgent, SessionService: sessionService})
if err != nil {
    log.Fatalf("Failed to create runner: %v", err)
}
```

--------------------------------

### Launch Local Server - Python with Uvicorn

Source: https://google.github.io/adk-docs/runtime/api-server

Starts a local Uvicorn web server for the ADK agent. The server listens on http://localhost:8000 and displays startup confirmation messages. This is the first step before creating sessions and sending queries.

```bash
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://localhost:8000 (Press CTRL+C to quit)
```

--------------------------------

### Run an ADK Agent from the Command Line

Source: https://google.github.io/adk-docs/runtime/command-line

This snippet demonstrates how to start an ADK agent using the command-line interface across different programming languages. It initiates an interactive session for testing and interaction.

```python
adk run my_agent
```

```typescript
npx @google/adk-devtools run agent.ts
```

```go
go run agent.go
```

```java
mvn compile exec:java -Dexec.mainClass="com.example.agent.AgentCliRunner"
```

--------------------------------

### Create and Activate Python Virtual Environment

Source: https://google.github.io/adk-docs/grounding/google_search_grounding

Instructions for creating and activating a Python virtual environment to manage project dependencies. Essential for isolating project-specific packages and ensuring a clean development setup.

```bash
# Create
python -m venv .venv

# Activate (each new terminal)
# macOS/Linux: source .venv/bin/activate
# Windows CMD: .venv\Scripts\activate.bat
# Windows PowerShell: .venv\Scripts\Activate.ps1
```

--------------------------------

### Initialize ADK LLM Agent (Python)

Source: https://google.github.io/adk-docs/deploy/gke

Shows the beginning of the `agent.py` file for the `capital_agent` example, demonstrating the import of `LlmAgent` from the `google.adk.agents` library, a foundational step for defining ADK agents.

```python
from google.adk.agents import LlmAgent
```

--------------------------------

### Install Freeplay ADK Library via pip

Source: https://google.github.io/adk-docs/observability/freeplay

Install the Freeplay Python ADK library package. This library provides integration between Freeplay and the Google Agent Developer Kit for observability and prompt management.

```bash
pip install freeplay-python-adk
```

--------------------------------

### Create Agent Command-Line Interface in Java

Source: https://google.github.io/adk-docs/get-started/java

Implement an AgentCliRunner class that creates a RunConfig object and Session object to run and interact with an ADK agent from the command line. The class accepts user input, sends it to the agent, and displays the agent's responses in an interactive loop.

```java
package com.example.agent;

import com.google.adk.agents.RunConfig;
import com.google.adk.events.Event;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;
import java.util.Scanner;

import static java.nio.charset.StandardCharsets.UTF_8;

public class AgentCliRunner {

    public static void main(String[] args) {
        RunConfig runConfig = RunConfig.builder().build();
        InMemoryRunner runner = new InMemoryRunner(HelloTimeAgent.ROOT_AGENT);

        Session session = runner
                .sessionService()
                .createSession(runner.appName(), "user1234")
                .blockingGet();

        try (Scanner scanner = new Scanner(System.in, UTF_8)) {
            while (true) {
                System.out.print("\nYou > ");
                String userInput = scanner.nextLine();
                if ("quit".equalsIgnoreCase(userInput)) {
                    break;
                }

                Content userMsg = Content.fromParts(Part.fromText(userInput));
                Flowable<Event> events = runner.runAsync(session.userId(), session.id(), userMsg, runConfig);

                System.out.print("\nAgent > ");
                events.blockingForEach(event -> {
                    if (event.finalResponse()) {
                        System.out.println(event.stringifyContent());
                    }
                });
            }
        }
    }
}
```

--------------------------------

### Example Grounded Response with Final Answer Text

Source: https://google.github.io/adk-docs/grounding/google_search_grounding

Demonstrates a complete grounded response example showing how the model returns a final answer text with source attribution metadata. This example shows an answer about Inter Miami's FIFA Club World Cup performance with supporting grounding metadata that links specific claims back to their sources.

```json
{
  "finalAnswer": "Yes, Inter Miami won their last game in the FIFA Club World Cup. They defeated FC Porto 2-1 in their second group stage match. Their first game in the tournament was a 0-0 draw against Al Ahly FC. Inter Miami is scheduled to play their third group stage match against Palmeiras on Monday, June 23, 2025.",
  "groundingMetadata": {
    "groundingChunks": [
      { "web": { "title": "mlssoccer.com", "uri": "..." } },
      { "web": { "title": "intermiamicf.com", "uri": "..." } },
      { "web": { "title": "mlssoccer.com", "uri": "..." } }
    ],
    "groundingSupports": [
      {
        "groundingChunkIndices": [0, 1],
        "segment": {
          "startIndex": 65,
          "endIndex": 126,
          "text": "They defeated FC Porto 2-1 in their second group stage match."
        }
      },
      {
        "groundingChunkIndices": [1],
        "segment": {
          "startIndex": 127,
          "endIndex": 196,
          "text": "Their first game in the tournament was a 0-0 draw against Al Ahly FC."
        }
      },
      {
        "groundingChunkIndices": [0, 2],
        "segment": {
          "startIndex": 197,
          "endIndex": 303,
          "text": "Inter Miami is scheduled to play their third group stage match against Palmeiras on Monday, June 23, 2025."
        }
      }
    ]
  }
}
```

--------------------------------

### onUserMessageCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SecurityPlugin

Callback executed when a user message is received before an invocation starts. This callback helps with logging and modifying the user message before the runner starts the invocation.

```APIDOC
## onUserMessageCallback

### Description
Callback executed when a user message is received before an invocation starts. This callback helps with logging and modifying the user message before the runner starts the invocation.

### Method
Callback

### Function Signature
```typescript
onUserMessageCallback(
  invocationContext: {
    invocationContext: InvocationContext;
    userMessage: Content;
  }
): Promise<Content | undefined>
```

### Parameters
#### Input Parameters
- **invocationContext** (object) - Required - The context for the entire invocation
  - **invocationContext** (InvocationContext) - The invocation context
  - **userMessage** (Content) - The user message received

### Returns
- **Promise<Content | undefined>** - An optional `Content` to be returned to the ADK. Returning a value replaces the user message. Returning `undefined` proceeds normally.
```

--------------------------------

### Example LiteLLM Debug Request Output (Text)

Source: https://google.github.io/adk-docs/agents/models/ollama

This text shows an example of the output generated when LiteLLM debugging is enabled. It displays the `curl` command equivalent of the HTTP request sent to the Ollama server, including the URL, method, and payload, which helps verify the API call structure.

```text
Request Sent from LiteLLM:
curl -X POST \
http://localhost:11434/api/chat \
-d '{'model': 'mistral-small3.1', 'messages': [{'role': 'system', 'content': ...
```

--------------------------------

### Get Session - GET Request

Source: https://google.github.io/adk-docs/runtime/api-server

Retrieves the complete details of a specific session including its current state and all associated events. Requires app name, user ID, and session ID as path parameters.

```bash
curl -X GET http://localhost:8000/apps/my_sample_agent/users/u_123/sessions/s_abc
```

--------------------------------

### Initialize VertexAIService in Go

Source: https://google.github.io/adk-docs/sessions/session

Initializes a VertexAIService instance in Go using the Google ADK session package. Requires Google Cloud authentication via gcloud CLI and environment variables for project ID and location. Returns a service instance or error if initialization fails.

```go
import "google.golang.org/adk/session"

modelName := "gemini-flash-latest"
vertexService, err := session.VertexAIService(ctx, modelName)
if err != nil {
  log.Printf("Could not initialize VertexAIService (this is expected if the gcloud project is not set): %v", err)
} else {
  fmt.Println("Successfully initialized VertexAIService.")
}
```

--------------------------------

### beforeRunCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SecurityPlugin

Callback executed before the ADK runner runs, serving as the first callback for global setup or initialization tasks.

```APIDOC
## METHOD beforeRunCallback

### Description
Callback executed before the ADK runner runs.
This is the first callback to be called in the lifecycle, ideal for global setup or initialization tasks.

### Method
FUNCTION

### Endpoint
beforeRunCallback(invocationContext: { invocationContext: InvocationContext }): Promise<Content | undefined>

### Parameters
#### Path Parameters
N/A

#### Query Parameters
N/A

#### Request Body
- **invocationContext** (object) - Required - The context for the entire invocation.
  - **invocationContext** (InvocationContext) - The invocation context.

### Request Example
```json
{
  "invocationContext": {
    "invocationContext": "InvocationContext instance"
  }
}
```

### Response
#### Success Response (Promise<Content | undefined>)
- **Content** (object) - Optional - If a value is returned, it might short-circuit the run or provide initial content.
- **undefined** (null) - If returned, allows the run to proceed normally.

#### Response Example
```json
{
  "initialContent": {
    "type": "text",
    "value": "Initial run setup complete"
  }
}
```
```

--------------------------------

### Install Playwright System Dependencies and Chromium Browser

Source: https://google.github.io/adk-docs/tools/gemini-api/computer-use

These commands install Playwright's required system dependencies and the Chromium browser. Playwright uses these components to automate web browsers. This step is crucial for the Computer Use Toolset to function correctly.

```bash
playwright install-deps chromium
playwright install chromium
```

--------------------------------

### Install MLflow and OpenTelemetry Dependencies

Source: https://google.github.io/adk-docs/observability/mlflow

Install required packages for MLflow 3.6.0+, Google ADK, and OpenTelemetry components. Requires pip package manager. Ensures all dependencies for OTLP trace ingestion are available.

```shell
pip install "mlflow>=3.6.0" google-adk opentelemetry-sdk opentelemetry-exporter-otlp-proto-http
```

--------------------------------

### Install Monocle and Google ADK packages

Source: https://google.github.io/adk-docs/observability/monocle

This command installs the necessary Python packages: `monocle_apptrace` for Monocle's tracing capabilities and `google-adk` for Google ADK components. These are prerequisites for setting up observability in your ADK applications.

```bash
pip install monocle_apptrace google-adk
```

--------------------------------

### Configure Root Agent with Sub-Agents and Tools in Python

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Shows how to create a root agent that orchestrates multiple sub-agents and tools using the Google ADK. The root agent uses an LLM model (Gemini 2.0 Flash) with instructions for delegating tasks to appropriate sub-agents. It includes safety settings configuration to handle specific content categories. The agent coordinates between local and remote agents based on user requests.

```python
from google.adk.agents.llm_agent import Agent
from google.genai import types

root_agent = Agent(
    model="gemini-2.0-flash",
    name="root_agent",
    instruction="""
      <You are a helpful assistant that can roll dice and check if numbers are prime.
      You delegate rolling dice tasks to the roll_agent and prime checking tasks to the prime_agent.
      Follow these steps:
      1. If the user asks to roll a die, delegate to the roll_agent.
      2. If the user asks to check primes, delegate to the prime_agent.
      3. If the user asks to roll a die and then check if the result is prime, call roll_agent first, then pass the result to prime_agent.
      Always clarify the results before proceeding.>
    """,
    global_instruction=(
        "You are DicePrimeBot, ready to roll dice and check prime numbers."
    ),
    sub_agents=[roll_agent, prime_agent],
    tools=[example_tool],
    generate_content_config=types.GenerateContentConfig(
        safety_settings=[
            types.SafetySetting(
                category=types.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                threshold=types.HarmBlockThreshold.OFF,
            ),
        ]
    ),
)
```

--------------------------------

### Set Gemini API Key in Environment

Source: https://google.github.io/adk-docs/get-started/python

Stores the Gemini API key as an environment variable in a .env file. The key is required for ADK agents to authenticate with the Gemini API and should be obtained from Google AI Studio's API Keys page.

```bash
echo 'GOOGLE_API_KEY="YOUR_API_KEY"' > .env
```

--------------------------------

### Load and Process Report Artifacts with ADK (TypeScript & Java)

Source: https://google.github.io/adk-docs/artifacts

These examples demonstrate how to load the latest version of a specified artifact, such as 'generated_report.pdf', using the Google ADK. Both TypeScript and Java versions show how to access the artifact's inline data, extract its MIME type, and log its size, providing a foundation for further application-specific processing. The TypeScript example uses `context.loadArtifact`, while the Java example employs `artifactService.loadArtifact` with RxJava for asynchronous handling.

```TypeScript
import { CallbackContext } from '@google/adk';

async function processLatestReport(context: CallbackContext): Promise<void> {
    /**Loads the latest report artifact and processes its data.*/
    const filename = "generated_report.pdf";
    try {
        // Load the latest version
        const reportArtifact = await context.loadArtifact(filename);

        if (reportArtifact?.inlineData) {
            console.log(`Successfully loaded latest TypeScript artifact '${filename}'.`);
            console.log(`MIME Type: ${reportArtifact.inlineData.mimeType}`);
            // Process the reportArtifact.inlineData.data (base64 string)
            const pdfData = Buffer.from(reportArtifact.inlineData.data, 'base64');
            console.log(`Report size: ${pdfData.length} bytes.`);
            // ... further processing ...
        } else {
            console.log(`TypeScript artifact '${filename}' not found.`);
        }

    } catch (e: any) {
        console.error(`Error loading TypeScript artifact: ${e.message}. Is ArtifactService configured?`);
    }
}
```

```Java
import com.google.adk.artifacts.BaseArtifactService;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.MaybeObserver;
import io.reactivex.rxjava3.disposables.Disposable;
import java.util.Optional;

public class MyArtifactLoaderService {

    private final BaseArtifactService artifactService;
    private final String appName;

    public MyArtifactLoaderService(BaseArtifactService artifactService, String appName) {
        this.artifactService = artifactService;
        this.appName = appName;
    }

    public void processLatestReportJava(String userId, String sessionId, String filename) {
        // Load the latest version by passing Optional.empty() for the version
        artifactService
                .loadArtifact(appName, userId, sessionId, filename, Optional.empty())
                .subscribe(
                        new MaybeObserver<Part>() {
                            @Override
                            public void onSubscribe(Disposable d) {
                                // Optional: handle subscription
                            }

                            @Override
                            public void onSuccess(Part reportArtifact) {
                                System.out.println(
                                        "Successfully loaded latest Java artifact '" + filename + "'.");
                                reportArtifact
                                        .inlineData()
                                        .ifPresent(
                                                blob -> {
                                                    System.out.println(
                                                            "MIME Type: " + blob.mimeType().orElse("N/A"));
                                                    byte[] pdfBytes = blob.data().orElse(new byte[0]);
                                                    System.out.println("Report size: " + pdfBytes.length + " bytes.");
                                                    // ... further processing of pdfBytes ...
                                                });
                            }

                            @Override
```

--------------------------------

### Complete Agent Main Entry Point

Source: https://google.github.io/adk-docs/tools/gemini-api/google-search

Complete main method demonstrating the full workflow: instantiating Google Search tool, building a Gemini agent with search capabilities, setting up session management infrastructure, and invoking the agent with a user query. Serves as the entry point for the agent application.

```java
public static void main(String[] args) {
  GoogleSearchTool googleSearchTool = new GoogleSearchTool();

  BaseAgent rootAgent =
      LlmAgent.builder()
          .name("basic_search_agent")
          .model("gemini-2.0-flash")
          .description("Agent to answer questions using Google Search.")
          .instruction(
              "I can answer your questions by searching the internet. Just ask me anything!")
          .tools(ImmutableList.of(googleSearchTool))
          .build();

  InMemorySessionService sessionService = new InMemorySessionService();
  Runner runner = new Runner(rootAgent, APP_NAME, null, sessionService);

  callAgent(runner, "what's the latest ai news?");
}
```

--------------------------------

### Create OpenAPI Tool with Service Account Authentication

Source: https://google.github.io/adk-docs/tools/authentication

Illustrates setup of an OpenAPI toolset using Service Account authentication. Converts a service account JSON configuration into auth scheme and credentials using the helper function, supporting scoped access to Google Cloud resources.

```python
from google.adk.tools.openapi_tool.auth.auth_helpers import service_account_dict_to_scheme_credential
from google.adk.tools.openapi_tool.openapi_spec_parser.openapi_toolset import OpenAPIToolset

service_account_cred = json.loads(service_account_json_str)
auth_scheme, auth_credential = service_account_dict_to_scheme_credential(
    config=service_account_cred,
    scopes=["https://www.googleapis.com/auth/cloud-platform"],
)
sample_toolset = OpenAPIToolset(
    spec_str=sa_openapi_spec_str,
    spec_str_type='json',
    auth_scheme=auth_scheme,
    auth_credential=auth_credential,
)
```

--------------------------------

### GET /sessions/{sessionId} - Get Session

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/BaseSessionService

Retrieves a specific session by ID, optionally filtering the events included based on provided configuration such as event count limit or timestamp filters.

```APIDOC
## GET /sessions/{sessionId}

### Description
Retrieves a specific session, optionally filtering the events included based on configuration parameters like event count limit or timestamp ranges.

### Method
GET

### Endpoint
/sessions/{sessionId}

### Parameters
#### Path Parameters
- **sessionId** (String) - Required - The unique identifier of the session to retrieve

#### Query Parameters
- **appName** (String) - Required - The name of the application
- **userId** (String) - Required - The identifier of the user
- **config** (GetSessionConfig) - Optional - Optional configuration to filter the events returned within the session (e.g., limit number of recent events, filter by timestamp). If empty, default retrieval behavior is used

### Response
#### Success Response (200)
- **Session** (Session) - The Session object if found containing session metadata and filtered events

#### Response Example
{
  "sessionId": "session-abc-123",
  "appName": "my-app",
  "userId": "user123",
  "state": {
    "key1": "value1"
  },
  "events": [
    {
      "eventId": "event-1",
      "timestamp": "2024-01-15T10:30:00Z",
      "stateDelta": {}
    }
  ]
}

#### Not Found Response (404)
- Empty response when session is not found

### Error Handling
- **SessionException** - for retrieval errors other than not found
```

--------------------------------

### Illustrate `transfer_to_agent` for Dynamic Routing (Python)

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

This Python example demonstrates the `transfer_to_agent` function call, typically used in a coordinator agent pattern for dynamic routing. It shows how a coordinator can route a user to a specialist agent (e.g., 'billing') based on user intent, with the conversation continuing within the same `run_live()` loop.

```python
# Coordinator routes based on user intent
User: "I need help with billing"
Event: author="coordinator", function_call: transfer_to_agent(agent_name="billing")
# Stream continues with billing agent - same run_live() loop
Event: author="billing", text="I can help with your billing question..."
```

--------------------------------

### Install ADK Toolbox TypeScript Package

Source: https://google.github.io/adk-docs/tools/google-cloud/mcp-toolbox-for-databases

This snippet demonstrates how to install the `@toolbox-sdk/adk` TypeScript package using npm. This package is required for integrating the MCP Toolbox with Google's Agent Development Kit (ADK) in TypeScript projects.

```typescript
npm install @toolbox-sdk/adk
```

--------------------------------

### Define Initial Session State for ADK Workflow in TypeScript

Source: https://google.github.io/adk-docs/agents/custom-agents

This snippet defines the initial state object required to start an ADK session. It sets a predefined 'topic' that will be used by the 'StoryGenerator' agent as the starting point for the story generation process.

```typescript
const INITIAL_STATE = { "topic": "a brave kitten exploring a haunted house" };
```

--------------------------------

### Python: Configure Session-Level Voice Settings with ADK RunConfig

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

This Python example shows how to set a default voice configuration for an entire session using ADK's `RunConfig`. By specifying `speech_config` within `RunConfig`, all agents participating in that session will use the defined voice characteristics, ensuring consistent audio responses across the application.

```python
from google.genai import types
from google.adk.agents.run_config import RunConfig

run_config = RunConfig(
    response_modalities=["AUDIO"],
    speech_config=types.SpeechConfig(
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(
                voice_name="Kore"
            )
        ),
        language_code="en-US"
    )
)

```

--------------------------------

### Google Cloud Authentication Environment Setup

Source: https://google.github.io/adk-docs/sessions/session

Sets up required environment variables for Google Cloud authentication across ADK services. Must be exported in bashrc or equivalent shell configuration file before running ADK applications that use VertexAI or other Google Cloud services.

```bash
gcloud auth application-default login
export GOOGLE_CLOUD_PROJECT="your-gcp-project-id"
export GOOGLE_CLOUD_LOCATION="your-gcp-location"
export GOOGLE_API_KEY="my_api_key"
```

--------------------------------

### Set Gemini API Key in ADK Project's .env File

Source: https://google.github.io/adk-docs/get-started/typescript

This command writes the 'GEMINI_API_KEY' into the '.env' file of the ADK project. This securely sets an environment variable required for authenticating with the Gemini API for generative AI models.

```bash
echo 'GEMINI_API_KEY="YOUR_API_KEY"' > .env
```

--------------------------------

### Customer Service Bot with Proactivity and Affective Dialog

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Practical example demonstrating a customer service bot configuration that uses proactive audio and affective dialog. The model can detect customer frustration, adapt its response tone, and proactively offer relevant suggestions based on conversation history and context.

```python
from google.genai import types
from google.adk.agents.run_config import RunConfig, StreamingMode

# Configure for empathetic customer service
run_config = RunConfig(
    response_modalities=["AUDIO"],
    streaming_mode=StreamingMode.BIDI,

    # Model can proactively offer help
    proactivity=types.ProactivityConfig(proactive_audio=True),

    # Model adapts to customer emotions
    enable_affective_dialog=True
)

# Example interaction (illustrative - actual model behavior may vary):
# Customer: "I've been waiting for my order for three weeks..."
# [Model may detect frustration in tone and adapt response]
# Model: "I'm really sorry to hear about this delay. Let me check your order
#        status right away. Can you provide your order number?"
#
# [Proactivity in action]
# Model: "I see you previously asked about shipping updates. Would you like
#        me to set up notifications for future orders?"
#
# Note: Proactive and affective behaviors are probabilistic. The model's
# emotional awareness and proactive suggestions will vary based on context,
# conversation history, and inherent model variability.
```

--------------------------------

### Install LiteLLM Python Library

Source: https://google.github.io/adk-docs/agents/models/litellm

This command installs the LiteLLM Python package using pip, making the library available for use in your Python projects. LiteLLM is a prerequisite for connecting ADK agents to various LLMs.

```bash
pip install litellm
```

--------------------------------

### Install Okahu Trace Visualizer VS Code Extension

Source: https://google.github.io/adk-docs/observability/monocle

Command to install the Okahu Trace Visualizer extension directly from the VS Code Quick Open menu. This extension enables interactive visualization and analysis of Monocle-generated traces within Visual Studio Code.

```shell
ext install OkahuAI.okahu-ai-observability
```

--------------------------------

### Example Detailed Stock Price Tool JSON Output

Source: https://google.github.io/adk-docs/tools/function-tools

This JSON snippet provides a more detailed example of the `getStockPrice` tool's return value. It includes both the `price` and `currency` fields, offering a richer data structure. This output would be generated by the tool after successfully fetching and formatting the stock price information.

```json
{"price": 2800.0, "currency": "USD"}
```

--------------------------------

### Create Session with In-Memory Service (Go)

Source: https://google.github.io/adk-docs/agents/custom-agents

Initializes a session using Go's in-memory session service with initial state containing topic. Handles error checking and session creation with context.

```go
sessionService := session.InMemoryService()
sessionInstance, err := sessionService.Create(ctx, &session.CreateRequest{
    AppName: appName,
    UserID:  userID,
    State:   initialState,
})
if err != nil {
    log.Fatalf("Failed to create session: %v", err)
}
```

--------------------------------

### Update User Preference with State Management in Python

Source: https://google.github.io/adk-docs/tools-custom

Demonstrates reading and writing user-specific state using tool_context.state within a FunctionTool. The example retrieves existing preferences from state using the 'user:' prefix scope, updates them, and persists changes back to the session state. This pattern ensures modifications are tracked as deltas and persisted by the session service.

```python
from google.adk.tools import ToolContext, FunctionTool

def update_user_preference(preference: str, value: str, tool_context: ToolContext):
    """Updates a user-specific preference."""
    user_prefs_key = "user:preferences"
    # Get current preferences or initialize if none exist
    preferences = tool_context.state.get(user_prefs_key, {})
    preferences[preference] = value
    # Write the updated dictionary back to the state
    tool_context.state[user_prefs_key] = preferences
    print(f"Tool: Updated user preference '{preference}' to '{value}'")
    return {"status": "success", "updated_preference": preference}

pref_tool = FunctionTool(func=update_user_preference)
```

--------------------------------

### Define OpenAPI Specification for Pet Store API in JSON

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Specifies a complete OpenAPI 3.0.0 schema for a mock Pet Store API using httpbin.org as the mock server. Includes three endpoints: GET /get (list pets), POST /post (create pet), and GET /get?petId (retrieve specific pet) with parameters, request/response schemas, and operation IDs.

```json
openapi_spec_string = """
{
  "openapi": "3.0.0",
  "info": {
    "title": "Simple Pet Store API (Mock)",
    "version": "1.0.1",
    "description": "An API to manage pets in a store, using httpbin for responses."
  },
  "servers": [
    {
      "url": "https://httpbin.org",
      "description": "Mock server (httpbin.org)"
    }
  ],
  "paths": {
    "/get": {
      "get": {
        "summary": "List all pets (Simulated)",
        "operationId": "listPets",
        "description": "Simulates returning a list of pets. Uses httpbin's /get endpoint which echoes query parameters.",
        "parameters": [
          {
            "name": "limit",
            "in": "query",
            "description": "Maximum number of pets to return",
            "required": false,
            "schema": { "type": "integer", "format": "int32" }
          },
          {
             "name": "status",
             "in": "query",
             "description": "Filter pets by status",
             "required": false,
             "schema": { "type": "string", "enum": ["available", "pending", "sold"] }
          }
        ],
        "responses": {
          "200": {
            "description": "A list of pets (echoed query params).",
            "content": { "application/json": { "schema": { "type": "object" } } }
          }
        }
      }
    },
    "/post": {
      "post": {
        "summary": "Create a pet (Simulated)",
        "operationId": "createPet",
        "description": "Simulates adding a new pet. Uses httpbin's /post endpoint which echoes the request body.",
        "requestBody": {
          "description": "Pet object to add",
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "required": ["name"],
                "properties": {
                  "name": {"type": "string", "description": "Name of the pet"},
                  "tag": {"type": "string", "description": "Optional tag for the pet"}
                }
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Pet created successfully (echoed request body).",
            "content": { "application/json": { "schema": { "type": "object" } } }
          }
        }
      }
    },
    "/get?petId={petId}": {
      "get": {
        "summary": "Info for a specific pet (Simulated)",
        "operationId": "showPetById",
        "description": "Simulates returning info for a pet ID. Uses httpbin's /get endpoint.",
        "parameters": [
          {
            "name": "petId",
            "in": "path",
            "description": "This is actually passed as a query param to httpbin /get",
            "required": true,
            "schema": { "type": "integer", "format": "int64" }
          }
        ],
        "responses": {
          "200": {
            "description": "Information about the pet (echoed query params)",
            "content": { "application/json": { "schema": { "type": "object" } } }
          },
          "404": { "description": "Pet not found (simulated)" }
        }
      }
    }
  }
}
"""
```

--------------------------------

### getOperation

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Generates a get operation for a given entity.

```APIDOC
## POST /getOperation

### Description
Generates a get operation for a given entity.

### Method
POST

### Endpoint
/getOperation

### Parameters
#### Request Body
- **entity** (String) - Required - The name of the entity.
- **schemaAsString** (String) - Required - The schema of the entity as a string.
- **toolName** (String) - Required - The name of the tool.
- **toolInstructions** (String) - Required - Instructions for the tool.

### Returns
- **ImmutableMap<String,Object>** - The generated get operation details.
```

--------------------------------

### Method: description

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/BaseAgent

Gets the one-line description of the agent's capability.

```APIDOC
## Method: description

### Description
Gets the one-line description of the agent's capability.

### Method
`public final String description()`

### Endpoint
None (Instance method)

### Parameters
None

### Request Example
None

### Response
#### Success Response (200)
* **String** - The description of the agent.

#### Response Example
```json
{
  "description": "Performs a specific task"
}
```
```

--------------------------------

### GET /sessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/VertexAiSessionService

Lists sessions associated with a specific application and user.

```APIDOC
## GET /sessions

### Description
Lists sessions associated with a specific application and user.

### Method
GET

### Endpoint
`/sessions`

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The ID of the user.

### Response
#### Success Response (200)
- **sessions** (List<Session>) - A list of sessions associated with the application and user.

#### Response Example
```json
{
  "sessions": [
    {
      "sessionId": "session-id-1",
      "appName": "example-app",
      "userId": "example-user",
      "state": {},
      "events": []
    },
    {
      "sessionId": "session-id-2",
      "appName": "example-app",
      "userId": "example-user",
      "state": {},
      "events": []
    }
  ]
}
```
```

--------------------------------

### Implement LLM Agent After-Model Response Modification (Go and Java)

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

These code examples demonstrate how to implement an `after_model_callback` for LLM agents in Go and Java. This callback is invoked immediately after the LLM generates a response, allowing for inspection and modification of the output. The Go example specifically replaces "joke" with "funny story" while handling capitalization, and the Java example provides the initial structure for a similar text processing function, including error handling.

```go
func onAfterModel(ctx agent.CallbackContext, resp *model.LLMResponse, respErr error) (*model.LLMResponse, error) {
    log.Printf("[Callback] AfterModel triggered for agent %q.", ctx.AgentName())
    if respErr != nil {
        log.Printf("[Callback] Model returned an error: %v. Passing it through.", respErr)
        return nil, respErr
    }
    if resp == nil || resp.Content == nil || len(resp.Content.Parts) == 0 {
        log.Println("[Callback] Response is nil or has no parts, nothing to process.")
        return nil, nil
    }
    // Check for function calls and pass them through without modification.
    if resp.Content.Parts[0].FunctionCall != nil {
        log.Println("[Callback] Response is a function call. No modification.")
        return nil, nil
    }

    originalText := resp.Content.Parts[0].Text

    // Use a case-insensitive regex with word boundaries to find "joke".
    re := regexp.MustCompile(`(?i)\bjoke\b`)
    if !re.MatchString(originalText) {
        log.Println("[Callback] 'joke' not found. Passing original response through.")
        return nil, nil
    }

    log.Println("[Callback] 'joke' found. Modifying response.")
    // Use a replacer function to handle capitalization.
    modifiedText := re.ReplaceAllStringFunc(originalText, func(s string) string {
        if strings.ToUpper(s) == "JOKE" {
            if s == "Joke" {
                return "Funny story"
            }
            return "funny story"
        }
        return s // Should not be reached with this regex, but it's safe.
    })

    resp.Content.Parts[0].Text = modifiedText
    return resp, nil
}
```

```java
public Maybe<LlmResponse> simpleAfterModelModifier(
      CallbackContext callbackContext, LlmResponse llmResponse) {
    String agentName = callbackContext.agentName();
    System.out.printf("%n[Callback] After model call for agent: %s%n", agentName);

    // --- Inspection Phase ---
    if (llmResponse.errorMessage().isPresent()) {
      System.out.printf(
          "[Callback] Response has error: '%s'. No modification.%n",
          llmResponse.errorMessage().get());
      return Maybe.empty(); // Pass through errors
    }

    Optional<Part> firstTextPartOpt =
        llmResponse
            .content()
            .flatMap(Content::parts)
```

--------------------------------

### Install ADK Toolbox Python Package

Source: https://google.github.io/adk-docs/tools/google-cloud/mcp-toolbox-for-databases

This snippet demonstrates how to install the `google-adk[toolbox]` Python package using pip. This package is essential for integrating the MCP Toolbox with Google's Agent Development Kit (ADK) in Python projects.

```python
pip install google-adk[toolbox]
```

--------------------------------

### System Instruction Configuration

Source: https://google.github.io/adk-docs/api-reference/agentconfig

How to provide system-level instructions to guide the AI model's behavior and performance.

```APIDOC
## System Instruction

### Description
Configuration for system instructions to guide the model.

### Parameters

#### Request Body

- **systemInstruction** (object) - Instructions for the model to steer it toward better performance. This can be of type Content, File, Part, or other specified options.
  - **parts** (array) - List of parts that constitute a single message. Each part may have a different IANA MIME type.

### Request Example
```json
{
  "systemInstruction": {
    "parts": [
      {
        "text": "Respond in a formal tone and avoid slang."
      },
      {
        "file": {
          "fileUri": "gs://bucket/instructions.txt"
        }
      }
    ]
  }
}
```

### Response

#### Success Response (200)
- **message** (string) - Confirmation message indicating system instructions have been set.

#### Response Example
```json
{
  "message": "System instructions updated."
}
```
```

--------------------------------

### GET LlmAgent.beforeToolCallback()

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/class-use/Callbacks.BeforeToolCallback

Retrieves the optional list of BeforeToolCallback instances configured for the LlmAgent. This method returns callbacks that are invoked before tool execution.

```APIDOC
## GET LlmAgent.beforeToolCallback()

### Description
Returns an Optional containing a list of BeforeToolCallback instances that are registered with the LlmAgent. These callbacks are executed before any tool invocation.

### Method
GET (Accessor Method)

### Endpoint
LlmAgent.beforeToolCallback()

### Return Type
`Optional<List<Callbacks.BeforeToolCallback>>`

### Return Description
An Optional that may contain a List of BeforeToolCallback instances, or an empty Optional if no callbacks are configured.

### Response Example
```java
Optional<List<Callbacks.BeforeToolCallback>> callbacks = llmAgent.beforeToolCallback();
if (callbacks.isPresent()) {
  List<Callbacks.BeforeToolCallback> callbackList = callbacks.get();
  // Process callbacks
}
```

### Package
com.google.adk.agents
```

--------------------------------

### Java LLM Agent Setup: Integrate Tool and Callback

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

This Java method demonstrates how to set up an LLM agent with a `FunctionTool` and an `afterToolCallback`. It creates a `FunctionTool` from the `getCapitalCity` method, configures an `LlmAgent` with instructions, the tool, and assigns the `simpleAfterToolModifier` as the callback. Finally, it runs the agent asynchronously with a user query and streams the events.

```java
  public void runAgent(String query) {
    // --- Wrap the function into a Tool ---
    FunctionTool capitalTool = FunctionTool.create(this.getClass(), "getCapitalCity");

    // Create LlmAgent and Assign Callback
    LlmAgent myLlmAgent =
        LlmAgent.builder()
            .name(APP_NAME)
            .model(MODEL_NAME)
            .instruction(
                "You are an agent that finds capital cities using the getCapitalCity tool. Report"
                    + " the result clearly.")
            .description("An LLM agent demonstrating after_tool_callback")
            .tools(capitalTool) // Add the tool
            .afterToolCallback(this::simpleAfterToolModifier) // Assign the callback
            .build();

    InMemoryRunner runner = new InMemoryRunner(myLlmAgent);

    // Session and Runner
    Session session =
        runner.sessionService().createSession(APP_NAME, USER_ID, null, SESSION_ID).blockingGet();

    Content userMessage = Content.fromParts(Part.fromText(query));

    System.out.printf("%n--- Calling agent with query: \"%s\" ---%n", query);
    Flowable<Event> eventStream = runner.runAsync(USER_ID, session.id(), userMessage);
    // Stream event response
    eventStream.blockingForEach(
        event -> {
          if (event.finalResponse()) {
            System.out.println(event.stringifyContent());
          }
        });
  }
```

--------------------------------

### Initialize RunConfig with ADK and GenAI Types in Python

Source: https://google.github.io/adk-docs/streaming/dev-guide/part4

This snippet demonstrates how to import necessary classes for `RunConfig` and initialize a `RunConfig` object. It shows importing `types` from `google.genai` for configuration types and `RunConfig`, `StreamingMode` from `google.adk.agents.run_config`. The example then initializes `RunConfig` with various configuration objects like `SessionResumptionConfig` and `SpeechConfig`.

```python
from google.genai import types
from google.adk.agents.run_config import RunConfig, StreamingMode

# Configuration types are accessed via types module
run_config = RunConfig(
    session_resumption=types.SessionResumptionConfig(),
    context_window_compression=types.ContextWindowCompressionConfig(...),
    speech_config=types.SpeechConfig(...),
    # etc.
)
```

--------------------------------

### GET /listSessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/InMemorySessionService

Lists sessions associated with a specific application and user.

```APIDOC
## GET /listSessions

### Description
Lists sessions associated with a specific application and user. The `Session` objects in the response typically contain only metadata.

### Method
GET

### Endpoint
/listSessions

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The identifier of the user whose sessions are to be listed.

### Response
#### Success Response (200)
- **ListSessionsResponse** (ListSessionsResponse) - A `ListSessionsResponse` containing a list of matching sessions.

#### Response Example
{
  "example": "{ \"sessions\": [ { \"sessionId\": \"session1\", \"creationTimestamp\": 1678886400000 }, { \"sessionId\": \"session2\", \"creationTimestamp\": 1678886500000 } ] }"
}
```

--------------------------------

### Simulate Go AI Agent Interactions for Stock Price Queries

Source: https://google.github.io/adk-docs/tools-custom/function-tools

The `RunAgentSimulation` function serves as the entry point for demonstrating the Go AI agent. It creates the stock agent and then simulates various user interactions by sending different prompts, showcasing the agent's ability to retrieve stock prices and handle different query types. This function provides a practical example of the agent in action.

```go
func RunAgentSimulation() {
    // Create the stock agent
    agent, err := createStockAgent(context.Background())
    if err != nil {

```

--------------------------------

### Comprehensive Tool Implementation with InvocationContext in Python

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Demonstrates a complete tool function implementation showing common InvocationContext patterns including accessing user identity, checking event history, retrieving persistent session state, updating session data, using artifact services for file storage, and terminating conversations on errors. This example illustrates how tool developers interact with conversation state, session services, and control flags.

```python
def my_tool(context: InvocationContext, query: str):
    # Access user identity
    user_id = context.session.user_id

    # Check if this is the user's first message
    event_count = len(context.session.events)
    if event_count == 0:
        return "Welcome! This is your first message."

    # Access conversation history
    recent_events = context.session.events[-5:]  # Last 5 events

    # Access persistent session state
    # Session state persists across invocations (not just this streaming session)
    user_preferences = context.session.state.get('user_preferences', {})

    # Update session state (will be persisted)
    context.session.state['last_query_time'] = datetime.now().isoformat()

    # Access services for persistence
    if context.artifact_service:
        # Store large files/audio
        await context.artifact_service.save_artifact(
            app_name=context.session.app_name,
            user_id=context.session.user_id,
            session_id=context.session.id,
            filename="result.bin",
            artifact=types.Part(inline_data=types.Blob(mime_type="application/octet-stream", data=data)),
        )

    # Process the query with context
    result = process_query(query, context=recent_events, preferences=user_preferences)

    # Terminate conversation in specific scenarios
    if result.get('error'):
        # Processing error - stop conversation
        context.end_invocation = True

    return result
```

--------------------------------

### GET /get?petId={petId} - Get pet by ID

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Retrieves information about a specific pet by its ID. This endpoint uses httpbin's /get endpoint with the pet ID passed as a query parameter for demonstration purposes.

```APIDOC
## GET /get?petId={petId}

### Description
Simulates returning information for a specific pet by ID. Uses httpbin's /get endpoint to echo back the pet ID query parameter.

### Method
GET

### Endpoint
/get?petId={petId}

### Parameters
#### Query Parameters
- **petId** (integer, int64) - Required - The unique identifier of the pet to retrieve

### Request Example
```
GET /get?petId=123
```

### Response
#### Success Response (200)
- **type** (object) - Information about the pet echoed as query parameters

#### Response Example
```json
{
  "args": {
    "petId": "123"
  },
  "headers": {},
  "origin": "0.0.0.0",
  "url": "https://httpbin.org/get?petId=123"
}
```

#### Error Response (404)
- **description** - Pet not found (simulated)
```

--------------------------------

### beforeAgentCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SecurityPlugin

Callback executed before an agent's primary logic is invoked, allowing logging, setup, or short-circuiting agent execution.

```APIDOC
## METHOD beforeAgentCallback

### Description
Callback executed before an agent's primary logic is invoked.
This callback can be used for logging, setup, or to short-circuit the agent's execution by returning a value.

### Method
FUNCTION

### Endpoint
beforeAgentCallback(agent: { agent: BaseAgent; callbackContext: CallbackContext }): Promise<Content | undefined>

### Parameters
#### Path Parameters
N/A

#### Query Parameters
N/A

#### Request Body
- **agent** (object) - Required - The agent that is about to run.
  - **agent** (BaseAgent) - The agent instance.
  - **callbackContext** (CallbackContext) - The context for the callback.

### Request Example
```json
{
  "agent": {
    "agent": "BaseAgent instance",
    "callbackContext": "CallbackContext instance"
  }
}
```

### Response
#### Success Response (Promise<Content | undefined>)
- **Content** (object) - Optional - If returned, it will bypass the agent's callbacks and its execution, and return this value directly.
- **undefined** (null) - If returned, allows the agent to proceed normally.

#### Response Example
```json
{
  "shortCircuitContent": {
    "type": "text",
    "value": "Agent short-circuited result"
  }
}
```
```

--------------------------------

### Single Event Loop Pattern - Correct Implementation

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Demonstrates the correct approach for handling multiple agents using one event loop that processes all agents sequentially. Shows the correct pattern versus common mistakes to avoid.

```python
# ✅ CORRECT: One loop handles all agents
async for event in runner.run_live(...):
    # Your event handling logic here
    await handle_event(event)  # Works for Agent1, Agent2, Agent3...

# ❌ INCORRECT: Don't break the loop or create multiple loops
for agent in agents:
    async for event in runner.run_live(...):  # WRONG!
        ...
```

--------------------------------

### Define ADK Agent with Gemini Model in Python

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Creates a basic ADK agent with Gemini 2.0 Flash model. This demonstrates the foundational agent definition before A2A exposure. The agent serves as the base for remote agent exposure.

```python
root_agent = Agent(
    model='gemini-2.0-flash',
    name='hello_world_agent',
    <...your agent code...>
)
```

--------------------------------

### Python: Configure Google Maps API Key and Initialize LlmAgent

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

This Python code retrieves the Google Maps API key from environment variables, providing a fallback for testing purposes (not recommended for production). It then initializes an LlmAgent named 'maps_assistant_agent' with instructions and an McpToolset for Google Maps, passing the API key securely to the toolset's environment.

```python
google_maps_api_key = os.environ.get("GOOGLE_MAPS_API_KEY")

if not google_maps_api_key:
    # Fallback or direct assignment for testing - NOT RECOMMENDED FOR PRODUCTION
    google_maps_api_key = "YOUR_GOOGLE_MAPS_API_KEY_HERE" # Replace if not using env var
    if google_maps_api_key == "YOUR_GOOGLE_MAPS_API_KEY_HERE":
        print("WARNING: GOOGLE_MAPS_API_KEY is not set. Please set it as an environment variable or in the script.")
        # You might want to raise an error or exit if the key is crucial and not found.

root_agent = LlmAgent(
    model='gemini-2.0-flash',
    name='maps_assistant_agent',
    instruction='Help the user with mapping, directions, and finding places using Google Maps tools.',
    tools=[
        McpToolset(
            connection_params=StdioConnectionParams(
                server_params = StdioServerParameters(
                    command='npx',
                    args=[
                        "-y",
                        "@modelcontextprotocol/server-google-maps"
                    ],
                    # Pass the API key as an environment variable to the npx process
                    # This is how the MCP server for Google Maps expects the key.
                    env={
                        "GOOGLE_MAPS_API_KEY": google_maps_api_key
                    }
                )
            ),
            # You can filter for specific Maps tools if needed:
            # tool_filter=['get_directions', 'find_place_by_id']
        )
    ]
)
```

--------------------------------

### Optimize Binary Audio Transmission over WebSocket with Python

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Provides a Python example for efficiently transmitting audio data over a WebSocket connection. It separates binary audio content from event metadata, sending audio as binary frames and metadata as text frames. This significantly reduces bandwidth for audio-heavy streams while preserving event details.

```python
async for event in runner.run_live(...):
    # Check for binary audio
    has_audio = (
        event.content and
        event.content.parts and
        any(p.inline_data for p in event.content.parts)
    )

    if has_audio:
        # Send audio via binary WebSocket frame
        for part in event.content.parts:
            if part.inline_data:
                await websocket.send_bytes(part.inline_data.data)

        # Send metadata only (much smaller)
        metadata_json = event.model_dump_json(
            exclude={'content': {'parts': {'__all__': {'inline_data'}}}},
            by_alias=True
        )
        await websocket.send_text(metadata_json)
    else:
        # Text-only events can be sent as JSON
        await websocket.send_text(event.model_dump_json(exclude_none=True, by_alias=True))
```

--------------------------------

### CLI Command: adk api_server

Source: https://google.github.io/adk-docs/api-reference/cli/cli

Starts a FastAPI server for agents, allowing configuration of host, port, logging, and various service URIs.

```APIDOC
## CLI Command: adk api_server

### Description
Starts a FastAPI server for agents. The AGENTS_DIR specifies the location of agent definitions.

### Method
CLI Command

### Endpoint
adk api_server [OPTIONS] [AGENTS_DIR]

### Parameters
#### Path Parameters
- **AGENTS_DIR** (string) - Optional - The directory of agents, where each sub-directory is a single agent, containing at least __init__.py and agent.py files.

#### Query Parameters
- **--host** (string) - Optional - The binding host of the server. Default: `'127.0.0.1'`.
- **--port** (integer) - Optional - The port of the server.
- **--allow_origins** (string) - Optional - Any additional origins to allow for CORS.
- **-v, --verbose** (boolean) - Optional - Enable verbose (DEBUG) logging. Shortcut for --log_level DEBUG. Default: `False`.
- **--log_level** (string) - Optional - Set the logging level. Options: DEBUG | INFO | WARNING | ERROR | CRITICAL.
- **--trace_to_cloud** (boolean) - Optional - Whether to enable cloud trace for telemetry. Default: `False`.
- **--otel_to_cloud** (boolean) - Optional - EXPERIMENTAL Whether to write OTel data to Google Cloud Observability services - Cloud Trace and Cloud Logging. Default: `False`.
- **--reload, --no-reload** (boolean) - Optional - Whether to enable auto reload for server. Not supported for Cloud Run.
- **--a2a** (boolean) - Optional - Whether to enable A2A endpoint. Default: `False`.
- **--reload_agents** (boolean) - Optional - Whether to enable live reload for agents changes. Default: `False`.
- **--eval_storage_uri** (string) - Optional - The evals storage URI to store agent evals, supported URIs: gs://<bucket name>.
- **--extra_plugins** (string) - Optional - Comma-separated list of extra plugin classes or instances to enable (e.g., my.module.MyPluginClass or my.module.my_plugin_instance).
- **--url_prefix** (string) - Optional - URL path prefix when the application is mounted behind a reverse proxy or API gateway (e.g., ‘/api/v1’, ‘/adk’). Must start with ‘/’ if provided.
- **--session_service_uri** (string) - Optional - The URI of the session service. Supports 'agentengine://', 'sqlite://', 'postgresql://'.
- **--artifact_service_uri** (string) - Optional - The URI of the artifact service, supported URIs: gs://<bucket name> for GCS artifact service.
- **--memory_service_uri** (string) - Optional - The URI of the memory service. Supports 'rag://', 'agentengine://'.
- **--session_db_url** (string) - Deprecated - Use --session_service_uri instead.
- **--artifact_storage_uri** (string) - Deprecated - Use --artifact_service_uri instead.

### Request Example
{
  "example": "adk api_server --session_service_uri=agentengine://my-engine --port=8080 path/to/agents_dir\n"
}

### Response
#### Success Response (CLI Output)
- **status** (string) - Indicates the success or failure of the server startup.
- **message** (string) - A descriptive message about the server status.

#### Response Example
{
  "status": "success",
  "message": "ADK API server started successfully. Listening on 127.0.0.1:8080"
}
```

--------------------------------

### GET /plugin-manager/plugin/{pluginName}

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/PluginManager

Retrieves a previously registered plugin by its unique name. Returns the plugin instance if found, otherwise `undefined`.

```APIDOC
## GET /plugin-manager/plugin/{pluginName}

### Description
Retrieves a registered plugin by its name. If the plugin is not found, it returns `undefined`.

### Method
GET

### Endpoint
/plugin-manager/plugin/{pluginName}

### Parameters
#### Path Parameters
- **pluginName** (string) - Required - The name of the plugin to retrieve.

### Request Example
(No request body required for GET requests with path parameters)

### Response
#### Success Response (200)
- **BasePlugin** (object) - The plugin instance if found.
- **undefined** (null) - If no plugin with the given name is registered.

#### Response Example
```json
{
  "name": "MyPlugin",
  "version": "1.0.0",
  "options": {}
}
```
Or if not found:
```json
null
```
```

--------------------------------

### Initialize ApplicationIntegrationToolset with Basic Configuration

Source: https://google.github.io/adk-docs/tools/google-cloud/application-integration

Creates an ApplicationIntegrationToolset instance with project credentials, connection details, and entity operations. Requires GCP project ID, location, connection name, and optional service account JSON for authentication.

```python
from google.adk.tools.application_integration_tool.application_integration_toolset import ApplicationIntegrationToolset

connector_tool = ApplicationIntegrationToolset(
    project="test-project", # TODO: replace with GCP project of the connection
    location="us-central1", #TODO: replace with location of the connection
    connection="test-connection", #TODO: replace with connection name
    entity_operations={"Entity_One": ["LIST","CREATE"], "Entity_Two": []},#empty list for actions means all operations on the entity are supported.
    actions=["action1"], #TODO: replace with actions
    service_account_json='{...}', # optional. Stringified json for service account key
    tool_name_prefix="tool_prefix2",
    tool_instructions="..."
)
```

--------------------------------

### GET /list-apps

Source: https://google.github.io/adk-docs/runtime/api-server

Returns a list of all agent applications discovered by the server. This utility endpoint provides an overview of available agents.

```APIDOC
## GET /list-apps

### Description
Returns a list of all agent applications discovered by the server.

### Method
GET

### Endpoint
/list-apps

### Parameters
#### Path Parameters
(None)

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **Array of Strings** - A list of agent application names.

#### Response Example
```json
["my_sample_agent", "another_agent"]
```
```

--------------------------------

### Start Google ADK Web UI

Source: https://google.github.io/adk-docs/tools/google-cloud/apigee-api-hub

Launch the Google ADK Web UI server to test and interact with the configured agent. The server runs on localhost:8000 and must be executed from the project root folder.

```bash
# make sure to run `adk web` from your project_root_folder
adk web
```

--------------------------------

### getOperationRequest

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Generates a request object for a get operation.

```APIDOC
## POST /getOperationRequest

### Description
Generates a request object for a get operation.

### Method
POST

### Endpoint
/getOperationRequest

### Returns
- **ImmutableMap<String,Object>** - The generated get operation request.
```

--------------------------------

### GET /connections/details

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/class-use/ConnectionsClient.ConnectionDetails

Retrieves service details for a given connection using the `getConnectionDetails` method.

```APIDOC
## GET /connections/details

### Description
This endpoint retrieves the service details for a specific connection. It provides information encapsulated within a `ConnectionsClient.ConnectionDetails` object.

### Method
GET

### Endpoint
`/connections/details`

### Parameters
#### Path Parameters
None

#### Query Parameters
None

#### Request Body
None

### Request Example
```
GET /connections/details
```

### Response
#### Success Response (200)
- **connectionDetails** (object) - An object containing the details of the connection.
  - **type** (string) - The type of connection (e.g., "Bluetooth", "WiFi").
  - **id** (string) - The unique identifier for the connection.
  - **status** (string) - The current status of the connection (e.g., "Connected", "Disconnected").

#### Response Example
```json
{
  "type": "Bluetooth",
  "id": "ABC-123-XYZ",
  "status": "Connected"
}
```
```

--------------------------------

### Configure LLM Agent with Mixed Tools and Toolsets in TypeScript

Source: https://google.github.io/adk-docs/tools-custom

Instantiates an LlmAgent that combines individual FunctionTool (greetTool) and custom toolsets (mathToolset). Configures agent name, instruction prompt, tools array, and model selection. The instruction guides the agent on when to use each tool based on user requests.

```typescript
const mathToolset = new SimpleMathToolset("calculator_");
const greetTool = new FunctionTool({
  name: "greet_user",
  description: "Greets the user.",
  parameters: z.object({ name: z.string() }),
  execute: greetUser,
});

const instruction =
  `You are a calculator and a greeter.
    If the user asks for a math operation, use the calculator tools.
    If the user asks for a greeting, use the greet_user tool.
    The result of the last math operation is stored in the 'last_math_result' state variable.`;

const calculatorAgent = new LlmAgent({
  name: "calculator_agent",
  instruction: instruction,
  tools: [greetTool, mathToolset],
  model: "gemini-2.5-flash",
});
```

--------------------------------

### Run LLM Agent Workflow and Process Events in Go

Source: https://google.github.io/adk-docs/agents/custom-agents

This Go snippet demonstrates how to initialize a session service and create a session with an initial state. It then sets up a `runner` with the `storyFlowAgent` and executes the workflow using `r.Run` with a user-defined input. The code iterates through the received events, accumulates the final response from the agent, and includes error handling for session, runner creation, and event processing during execution.

```go
sessionService := session.InMemoryService()
initialState := map[string]any{
    "topic": "a brave kitten exploring a haunted house",
}
sessionInstance, err := sessionService.Create(ctx, &session.CreateRequest{
    AppName: appName,
    UserID:  userID,
    State:   initialState,
})
if err != nil {
    log.Fatalf("Failed to create session: %v", err)
}

userTopic := "a lonely robot finding a friend in a junkyard"

r, err := runner.New(runner.Config{
    AppName:        appName,
    Agent:          storyFlowAgent,
    SessionService: sessionService,
})
if err != nil {
    log.Fatalf("Failed to create runner: %v", err)
}

input := genai.NewContentFromText("Generate a story about: "+userTopic, genai.RoleUser)
events := r.Run(ctx, userID, sessionInstance.Session.ID(), input, agent.RunConfig{
    StreamingMode: agent.StreamingModeSSE,
})

var finalResponse string
for event, err := range events {
    if err != nil {
        log.Fatalf("An error occurred during agent execution: %v", err)
    }

    for _, part := range event.Content.Parts {
        // Accumulate text from all parts of the final response.
        finalResponse += part.Text
    }
}

fmt.Println("\n--- Agent Interaction Result ---")
fmt.Println("Agent Final Response: " + finalResponse)
```

--------------------------------

### Full Google ADK Agent Example with Monocle Tracing

Source: https://google.github.io/adk-docs/observability/monocle

This comprehensive Python example demonstrates how to integrate Monocle with a Google ADK agent. It sets up Monocle telemetry, defines a tool and an agent, and runs an agent interaction, with all underlying ADK calls automatically traced by Monocle without explicit instrumentation.

```python
from monocle_apptrace import setup_monocle_telemetry
from google.adk.agents import Agent
from google.adk.runners import InMemoryRunner
from google.genai import types

# Initialize Monocle telemetry - must be called before using ADK
setup_monocle_telemetry(workflow_name="weather_app")

# Define a tool function
def get_weather(city: str) -> dict:
    """Retrieves the current weather report for a specified city.

    Args:
        city (str): The name of the city for which to retrieve the weather report.

    Returns:
        dict: status and result or error msg.
    """
    if city.lower() == "new york":
        return {
            "status": "success",
            "report": (
                "The weather in New York is sunny with a temperature of 25 degrees"
                " Celsius (77 degrees Fahrenheit)."
            ),
        }
    else:
        return {
            "status": "error",
            "error_message": f"Weather information for '{city}' is not available.",
        }

# Create an agent with tools
agent = Agent(
    name="weather_agent",
    model="gemini-2.0-flash-exp",
    description="Agent to answer questions using weather tools.",
    instruction="You must use the available tools to find an answer.",
    tools=[get_weather]
)

app_name = "weather_app"
user_id = "test_user"
session_id = "test_session"
runner = InMemoryRunner(agent=agent, app_name=app_name)
session_service = runner.session_service

await session_service.create_session(
    app_name=app_name,
    user_id=user_id,
    session_id=session_id
)

# Run the agent (all interactions will be automatically traced)
async for event in runner.run_async(
    user_id=user_id,
    session_id=session_id,
    new_message=types.Content(role="user", parts=[
        types.Part(text="What is the weather in New York?")]
    )
):
    if event.is_final_response():
        print(event.content.parts[0].text.strip())
```

--------------------------------

### Access auto-generated agent card JSON

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing-go

Verify that the remote A2A agent is running and properly exposed by accessing the auto-generated agent card endpoint. The A2A launcher dynamically generates this card which contains the agent's metadata and capabilities.

```url
http://localhost:8001/.well-known/agent-card.json
```

--------------------------------

### Method: name

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/BaseAgent

Gets the agent's unique name.

```APIDOC
## Method: name

### Description
Gets the agent's unique name.

### Method
`public final String name()`

### Endpoint
None (Instance method)

### Parameters
None

### Request Example
None

### Response
#### Success Response (200)
* **String** - The unique name of the agent.

#### Response Example
```json
{
  "name": "MyAgent"
}
```
```

--------------------------------

### Demonstrate Agent Interaction with Reimbursement Scenarios in Python

Source: https://google.github.io/adk-docs/tools-custom/function-tools

These Python examples illustrate how to invoke the `call_agent_async` function for different reimbursement requests. They show both the `asyncio.run()` method for executing asynchronous functions in standalone scripts and the `await` keyword for use within asynchronous contexts like Jupyter notebooks, demonstrating how to trigger agent interactions for various scenarios.

```python
# asyncio.run(call_agent_async("Please reimburse 50$ for meals"))
await call_agent_async("Please reimburse 50$ for meals") # For Notebooks, uncomment this line and comment the above line
# reimbursement that requires approval
# asyncio.run(call_agent_async("Please reimburse 200$ for meals"))
await call_agent_async("Please reimburse 200$ for meals") # For Notebooks, uncomment this line and comment the above line
```

--------------------------------

### Initialize Agent with Before-Tool Callbacks in Go

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

Demonstrates creating a Gemini model, registering the getCapitalCity tool as a FunctionTool, and configuring an LlmAgent with BeforeToolCallbacks. Sets up a runner with session management and executes two scenarios: argument modification and tool blocking.

```go
func runBeforeToolExample() {
    ctx := context.Background()
    geminiModel, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("FATAL: Failed to create model: %v", err)
    }
    capitalTool, err := functiontool.New(functiontool.Config{
        Name:        "getCapitalCity",
        Description: "Retrieves the capital city of a given country.",
    }, getCapitalCity)
    if err != nil {
        log.Fatalf("FATAL: Failed to create function tool: %v", err)
    }

    llmCfg := llmagent.Config{
        Name:                "AgentWithBeforeToolCallback",
        Model:               geminiModel,
        Tools:               []tool.Tool{capitalTool},
        BeforeToolCallbacks: []llmagent.BeforeToolCallback{onBeforeTool},
        Instruction:         "You are an agent that can find capital cities. Use the getCapitalCity tool.",
    }
    testAgent, err := llmagent.New(llmCfg)
    if err != nil {
        log.Fatalf("FATAL: Failed to create agent: %v", err)
    }
    sessionService := session.InMemoryService()
    r, err := runner.New(runner.Config{AppName: appName, Agent: testAgent, SessionService: sessionService})
    if err != nil {
        log.Fatalf("FATAL: Failed to create runner: %v", err)
    }

    log.Println("--- SCENARIO 1: Args should be modified ---")
    runScenario(ctx, r, sessionService, appName, "session_tool_modify", nil, "What is the capital of Canada?")

    log.Println("--- SCENARIO 2: Tool call should be blocked ---")
    runScenario(ctx, r, sessionService, appName, "session_tool_block", nil, "capital of BLOCK")
}
```

--------------------------------

### GET /list-apps

Source: https://google.github.io/adk-docs/deploy/cloud-run

Retrieves a list of available applications deployed on the ADK agent service. This helps verify the deployed application name.

```APIDOC
## GET /list-apps

### Description
Retrieves a list of available applications deployed on the ADK agent service. This helps verify the deployed application name.

### Method
GET

### Endpoint
/list-apps

### Parameters
#### Path Parameters
(None)

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
```bash
curl -X GET -H "Authorization: Bearer $TOKEN" $APP_URL/list-apps
```

### Response
#### Success Response (200)
- **app_names** (array of string) - A list of deployed application names.

#### Response Example
```json
[
  "capital_agent",
  "another_agent"
]
```
```

--------------------------------

### Create and Configure MCP Server with Tool Handlers

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

Creates an MCP server instance with tool call handlers and tool listing capabilities. The server uses async functions to handle incoming tool calls and list available tools with their input schemas. This forms the core server logic that can be deployed to Cloud Run or Kubernetes.

```python
def create_mcp_server():
    """Create and configure the MCP server."""
    app = Server("adk-mcp-streamable-server")

    @app.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[types.ContentBlock]:
        """Handle tool calls from MCP clients."""
        if name == "example_tool":
            result = arguments.get("input", "No input provided")
            return [
                types.TextContent(
                    type="text",
                    text=f"Processed: {result}"
                )
            ]
        else:
            raise ValueError(f"Unknown tool: {name}")

    @app.list_tools()
    async def list_tools() -> list[types.Tool]:
        """List available tools."""
        return [
            types.Tool(
                name="example_tool",
                description="Example tool for demonstration",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "input": {
                            "type": "string",
                            "description": "Input text to process"
                        }
                    },
                    "required": ["input"]
                }
            )
        ]

    return app
```

--------------------------------

### Implement Document Analysis Tool with ADK (TypeScript & Go)

Source: https://google.github.io/adk-docs/tools-custom

These code examples illustrate how to build an ADK tool that processes documents. The tool leverages `ToolContext` to load existing artifacts, query the agent's memory for relevant information, perform a conceptual analysis, and save the analysis output as a new artifact. Both TypeScript and Go implementations are provided.

```typescript
import { Part } from "@google/genai";
import { ToolContext } from "@google/adk";

// Analyzes a document using context from memory.
export async function processDocument(
  params: { documentName: string; analysisQuery: string },
  toolContext?: ToolContext
): Promise<Record<string, any>> {
  if (!toolContext) {
    throw new Error("ToolContext is required for this tool.");
  }

  // 1. List all available artifacts
  const artifacts = await toolContext.listArtifacts();
  console.log(`Listing all available artifacts: ${artifacts}`);

  // 2. Load an artifact
  console.log(`Tool: Attempting to load artifact: ${params.documentName}`);
  const documentPart = await toolContext.loadArtifact(params.documentName);
  if (!documentPart) {
    console.log(`Tool: Document '${params.documentName}' not found.`);
    return {
      status: "error",
      message: `Document '${params.documentName}' not found.` 
    };
  }

  const documentText = documentPart.text ?? "";
  console.log(
    `Tool: Loaded document '${params.documentName}' (${documentText.length} chars).`
  );

  // 3. Search memory for related context
  console.log(`Tool: Searching memory for context related to '${params.analysisQuery}'`);
  const memory_results = await toolContext.searchMemory(params.analysisQuery);
  console.log(`Tool: Found ${memory_results.memories.length} relevant memories.`);
  const context_from_memory = memory_results.memories
    .map((m) => m.content.parts[0].text)
    .join("\n");

  // 4. Perform analysis (placeholder)
  const analysisResult =
    `Analysis of '${params.documentName}' regarding '${params.analysisQuery}':\n` +
    `Context from Memory:\n${context_from_memory}\n` +
    `[Placeholder Analysis Result]`;
  console.log("Tool: Performed analysis.");

  // 5. Save the analysis result as a new artifact
  const analysisPart: Part = { text: analysisResult };
  const newArtifactName = `analysis_${params.documentName}`;
  await toolContext.saveArtifact(newArtifactName, analysisPart);
  console.log(`Tool: Saved analysis result to '${newArtifactName}'.`);

  return {
    status: "success",
    analysis_artifact: newArtifactName,
  };
}
```

```go
// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
    "fmt"

    "google.golang.org/adk/tool"
    "google.golang.org/genai"
)

type processDocumentArgs struct {
    DocumentName  string `json:"document_name" jsonschema:"The name of the document to be processed."`
    AnalysisQuery string `json:"analysis_query" jsonschema:"The query for the analysis."`
}

type processDocumentResult struct {
    Status           string `json:"status"`
    AnalysisArtifact string `json:"analysis_artifact,omitempty"`
    Version          int64  `json:"version,omitempty"`
    Message          string `json:"message,omitempty"`
}

func processDocument(ctx tool.Context, args processDocumentArgs) (*processDocumentResult, error) {
    fmt.Printf("Tool: Attempting to load artifact: %s\n", args.DocumentName)

    // List all artifacts
    listResponse, err := ctx.Artifacts().List(ctx)
    if err != nil {
        return nil, fmt.Errorf("failed to list artifacts")
    }

    fmt.Println("Tool: Available artifacts:")
    for _, file := range listResponse.FileNames {
        fmt.Printf(" - %s\n", file)
    }

    documentPart, err := ctx.Artifacts().Load(ctx, args.DocumentName)
    if err != nil {
        return nil, fmt.Errorf("document '%s' not found", args.DocumentName)
    }

    fmt.Printf("Tool: Loaded document '%s' of size %d bytes.\n", args.DocumentName, len(documentPart.Part.InlineData.Data))

    // 3. Search memory for related context
    fmt.Printf("Tool: Searching memory for context related to: '%s'\n", args.AnalysisQuery)
    memoryResp, err := ctx.SearchMemory(ctx, args.AnalysisQuery)
    if err != nil {
        fmt.Printf("Tool: Error searching memory: %v\n", err)
    }
    memoryResultCount := 0
    if memoryResp != nil {
        memoryResultCount = len(memoryResp.Memories)
    }
    fmt.Printf("Tool: Found %d memory results.\n", memoryResultCount)

    analysisResult := fmt.Sprintf("Analysis of '%s' regarding '%s' using memory context: [Placeholder Analysis Result]", args.DocumentName, args.AnalysisQuery)
    fmt.Println("Tool: Performed analysis.")

    analysisPart := genai.NewPartFromText(analysisResult)

```

--------------------------------

### Start Audio Recorder Worklet with Web Audio API

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Initializes an AudioContext with 16kHz sample rate, loads a custom AudioWorklet processor, requests microphone access, and sets up real-time audio frame capture with Float32 to PCM16 conversion. The function returns the audio recorder node, context, and microphone stream for further management.

```JavaScript
export async function startAudioRecorderWorklet(audioRecorderHandler) {
    const audioRecorderContext = new AudioContext({ sampleRate: 16000 });
    const workletURL = new URL("./pcm-recorder-processor.js", import.meta.url);
    await audioRecorderContext.audioWorklet.addModule(workletURL);
    micStream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1 }
    });
    const source = audioRecorderContext.createMediaStreamSource(micStream);
    const audioRecorderNode = new AudioWorkletNode(
        audioRecorderContext,
        "pcm-recorder-processor"
    );
    source.connect(audioRecorderNode);
    audioRecorderNode.port.onmessage = (event) => {
        const pcmData = convertFloat32ToPCM(event.data);
        audioRecorderHandler(pcmData);
    };
    return [audioRecorderNode, audioRecorderContext, micStream];
}

function convertFloat32ToPCM(inputData) {
    const pcm16 = new Int16Array(inputData.length);
    for (let i = 0; i < inputData.length; i++) {
        pcm16[i] = inputData[i] * 0x7fff;
    }
    return pcm16.buffer;
}
```

--------------------------------

### Multi-Speaker Voice Configuration

Source: https://google.github.io/adk-docs/api-reference/agentconfig

Configuration for multi-speaker setups, defining speaker voice configurations.

```APIDOC
## POST /api/multiSpeakerVoiceConfig

### Description
Configures multi-speaker voice settings. This is mutually exclusive with the general voice_config field.

### Method
POST

### Endpoint
/api/multiSpeakerVoiceConfig

### Parameters
#### Request Body
- **speakerVoiceConfigs** (array) - Optional - An array of speaker voice configurations.
  - **speaker** (string) - Required - The name of the speaker to use, matching the prompt.
  - **voiceConfig** (object) - Optional - The configuration for the speaker's voice.

### Request Example
{
  "speakerVoiceConfigs": [
    {
      "speaker": "Alice",
      "voiceConfig": {
        "voiceName": "en-US-Wavenet-A"
      }
    },
    {
      "speaker": "Bob",
      "voiceConfig": {
        "voiceName": "en-US-Wavenet-B"
      }
    }
  ]
}

### Response
#### Success Response (200)
- **multiSpeakerVoiceConfig** (object) - The configured multi-speaker settings.

#### Response Example
{
  "multiSpeakerVoiceConfig": {
    "speakerVoiceConfigs": [
      {
        "speaker": "Alice",
        "voiceConfig": {
          "voiceName": "en-US-Wavenet-A"
        }
      }
    ]
  }
}
```

--------------------------------

### Get Session

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/InMemorySessionService

Retrieves a specific session, with an option to filter events.

```APIDOC
## GET /sessions/get

### Description
Retrieves a specific session, optionally filtering the events included.

### Method
GET

### Endpoint
/sessions/get

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The ID of the user.
- **sessionId** (String) - Required - The ID of the session to retrieve.
- **configOpt** (Optional<GetSessionConfig>) - Optional - Configuration options for retrieving the session, potentially filtering events.
```

--------------------------------

### Load Toolbox Tools and Integrate with LLM Agent in Go

Source: https://google.github.io/adk-docs/tools/google-cloud/mcp-toolbox-for-databases

This Go snippet illustrates how to create a `ToolboxClient` to load tools from a Toolbox server. It demonstrates loading an entire toolset or a single tool and then configuring an `llmagent` with the loaded tools for use in a Go application.

```go
package main

import (
    "context"
    "fmt"

    "github.com/googleapis/mcp-toolbox-sdk-go/tbadk"
    "google.golang.org/adk/agent/llmagent"
)

func main() {

  toolboxClient, err := tbadk.NewToolboxClient("https://127.0.0.1:5000")
    if err != nil {
        log.Fatalf("Failed to create MCP Toolbox client: %v", err)
    }

  // Load a specific set of tools
  toolboxtools, err := toolboxClient.LoadToolset("my-toolset-name", ctx)
  if err != nil {
    return fmt.Sprintln("Could not load Toolbox Toolset", err)
  }

  toolsList := make([]tool.Tool, len(toolboxtools))
    for i := range toolboxtools {
      toolsList[i] = &toolboxtools[i]
    }

  llmagent, err := llmagent.New(llmagent.Config{
    ...,
    Tools:       toolsList,
  })

  // Load a single tool
  tool, err := client.LoadTool("my-tool-name", ctx)
  if err != nil {
    return fmt.Sprintln("Could not load Toolbox Tool", err)
  }

  llmagent, err := llmagent.New(llmagent.Config{
    ...,
    Tools:       []tool.Tool{&toolboxtool},
  })
}
```

--------------------------------

### Demonstrate Gemini Agent Voice Configuration Precedence in Python

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

This example illustrates the precedence rules for `speech_config` when configuring Gemini agents. It shows that a voice defined directly within a `Gemini` instance (agent-level) takes priority over a voice specified in the `RunConfig` (session-level), allowing for specific agent voice overrides.

```python
from google.genai import types
from google.adk.agents import Agent
from google.adk.models.google_llm import Gemini
from google.adk.agents.run_config import RunConfig
from google.adk.tools import google_search

# Create Gemini instance with custom voice
custom_llm = Gemini(
    model="gemini-2.5-flash-native-audio-preview-12-2025",
    speech_config=types.SpeechConfig(
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(
                voice_name="Puck"  # Agent-level: highest priority
            )
        )
    )
)

# Agent uses the Gemini instance with custom voice
agent = Agent(
    model=custom_llm,
    tools=[google_search],
    instruction="You are a helpful assistant."
)

# RunConfig with default voice (will be overridden by agent's Gemini config)
run_config = RunConfig(
    response_modalities=["AUDIO"],
    speech_config=types.SpeechConfig(
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(
                voice_name="Kore"  # This is overridden for the agent above
            )
        )
    )
)
```

--------------------------------

### Initialize ADK Agent and Define Stock Price Tool Arguments in Go

Source: https://google.github.io/adk-docs/tools/function-tools

This Go snippet initiates the setup for an ADK agent designed to fetch stock prices. It includes necessary imports for ADK components, defines a `mockStockPrices` map to simulate data, and introduces the `getStockPriceArgs` struct for strong typing and validation of tool parameters. This forms the foundational structure for integrating a stock price function tool within a Go-based ADK agent.

```go
import (
    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/runner"
    "google.golang.org/adk/session"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/functiontool"
    "google.golang.org/genai"
)

// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
    "context"
    "fmt"
    "log"
    "strings"

    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/runner"
    "google.golang.org/adk/session"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/agenttool"
    "google.golang.org/adk/tool/functiontool"

    "google.golang.org/genai"
)

// mockStockPrices provides a simple in-memory database of stock prices
// to simulate a real-world stock data API. This allows the example to
// demonstrate tool functionality without making external network calls.
var mockStockPrices = map[string]float64{
    "GOOG": 300.6,
    "AAPL": 123.4,
    "MSFT": 234.5,
}

// getStockPriceArgs defines the schema for the arguments passed to the getStockPrice tool.
// Using a struct is the recommended approach in the Go ADK as it provides strong
// typing and clear validation for the expected inputs.
type getStockPriceArgs struct {
```

--------------------------------

### Setup Session and Runner for Google ADK Agent

Source: https://google.github.io/adk-docs/tools/function-tools

Async function that initializes an in-memory session service and creates a runner for the stock price agent. Sets up session management with specified app name, user ID, and session ID for agent interaction tracking.

```python
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=stock_price_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner
```

--------------------------------

### Configure Proactivity and Affective Dialog in Gemini Live API

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Basic configuration example showing how to enable proactive audio and affective dialog features using RunConfig. The proactivity setting allows the model to initiate responses without explicit prompts, while affective dialog enables emotional awareness and adaptation.

```python
from google.genai import types
from google.adk.agents.run_config import RunConfig

run_config = RunConfig(
    # Model can initiate responses without explicit prompts
    proactivity=types.ProactivityConfig(proactive_audio=True),

    # Model adapts to user emotions
    enable_affective_dialog=True
)
```

--------------------------------

### Retrieve Weather Report in Java

Source: https://google.github.io/adk-docs/tools-custom

This Java example demonstrates a tool for retrieving a weather report for a specified city. It takes the city name as input and returns a map containing the status and the weather report or an error message if the city is not supported. It highlights direct implementation of business logic within the tool.

```java
/**
 * Retrieves the current weather report for a specified city.
 *
 * @param city The city for which to retrieve the weather report.
 * @param toolContext The context for the tool.
 * @return A dictionary containing the weather information.
 */
public static Map<String, Object> getWeatherReport(String city, ToolContext toolContext) {
    Map<String, Object> response = new HashMap<>();
    if (city.toLowerCase(Locale.ROOT).equals("london")) {
        response.put("status", "success");
        response.put(
                "report",
                "The current weather in London is cloudy with a temperature of 18 degrees Celsius and a"
                        + " chance of rain.");
    } else if (city.toLowerCase(Locale.ROOT).equals("paris")) {
        response.put("status", "success");
        response.put("report", "The weather in Paris is sunny with a temperature of 25 degrees Celsius.");
    } else {
        response.put("status", "error");
        response.put("error_message", String.format("Weather information for '%s' is not available.", city));
    }
    return response;
}
```

--------------------------------

### Setup In-Memory Session Service and Runner for Agent Execution

Source: https://google.github.io/adk-docs/agents/custom-agents

Initializes an InMemorySessionService to manage session state and creates a Runner instance that executes the orchestrator agent. This async function sets up the infrastructure for tracking conversation history and agent outputs across multiple interactions.

```python
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID, state=INITIAL_STATE)
    logger.info(f"Initial session state: {session.state}")
    runner = Runner(
        agent=story_flow_agent,
        app_name=APP_NAME,
        session_service=session_service
    )
    return session_service, runner
```

--------------------------------

### Initialize LlmAgent with Instructions and Tools in TypeScript

Source: https://google.github.io/adk-docs/tools-custom

Creates an LlmAgent instance configured with specific instructions for a weather sentiment workflow, integrating the weather and sentiment analysis tools. Uses the gemini-2.5-flash model for natural language understanding and orchestration of tool calls.

```typescript
const instruction = `
    You are a helpful assistant that first checks the weather and then analyzes
    its sentiment.

    Follow these steps:
    1. Use the 'get_weather_report' tool to get the weather for the requested
       city.
    2. If the 'get_weather_report' tool returns an error, inform the user about
       the error and stop.
    3. If the weather report is available, use the 'analyze_sentiment' tool to
       determine the sentiment of the weather report.
    4. Finally, provide a summary to the user, including the weather report and
       its sentiment.
    `;

const agent = new LlmAgent({
    name: "weather_sentiment_agent",
    instruction: instruction,
    tools: [weatherTool, sentimentTool],
    model: "gemini-2.5-flash"
});
```

--------------------------------

### METHOD getTracer

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/Telemetry

Gets the OpenTelemetry Tracer instance used by the ADK Telemetry to create and manage traces.

```APIDOC
## METHOD getTracer

### Description
Gets the tracer.

### Method
GET

### Endpoint
public static io.opentelemetry.api.trace.Tracer getTracer()

### Parameters

### Response
#### Success Response (200)
- **Tracer** (io.opentelemetry.api.trace.Tracer) - The OpenTelemetry tracer instance.
```

--------------------------------

### Test Affective Dialog with Emotional Response

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Example test case for verifying affective dialog capabilities by providing input with emotional cues. The model should detect the emotional tone and adjust its response style accordingly.

```text
User: [frustrated tone] "This isn't working at all!"
Expected: Model acknowledges emotion, adjusts response style
```

--------------------------------

### Run Before Model Callback Example in Go

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

Initializes a Gemini model with before_model_callback, creates an LLM agent with the callback function, sets up a runner with in-memory session service, and executes two test scenarios: one that proceeds normally and one that is blocked by the callback.

```go
func runBeforeModelExample() {
    ctx := context.Background()
    geminiModel, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("FATAL: Failed to create model: %v", err)
    }

    llmCfg := llmagent.Config{
        Name:                 "AgentWithBeforeModelCallback",
        Model:                geminiModel,
        BeforeModelCallbacks: []llmagent.BeforeModelCallback{onBeforeModel},
    }
    testAgent, err := llmagent.New(llmCfg)
    if err != nil {
        log.Fatalf("FATAL: Failed to create agent: %v", err)
    }

    sessionService := session.InMemoryService()
    r, err := runner.New(runner.Config{AppName: appName, Agent: testAgent, SessionService: sessionService})
    if err != nil {
        log.Fatalf("FATAL: Failed to create runner: %v", err)
    }

    log.Println("--- SCENARIO 1: Should proceed to LLM ---")
    runScenario(ctx, r, sessionService, appName, "session_normal", nil, "Tell me a fun fact.")

    log.Println("\n--- SCENARIO 2: Should be blocked by callback ---")
    runScenario(ctx, r, sessionService, appName, "session_blocked", nil, "write a joke on BLOCK")
}
```

--------------------------------

### Instantiate ADK InMemoryArtifactService (Python)

Source: https://google.github.io/adk-docs/artifacts

This Python example shows the straightforward instantiation of the `InMemoryArtifactService`. This service provides a simple, in-memory storage solution for ADK artifacts, ideal for development and testing environments where data persistence across restarts is not required.

```python
from google.adk.artifacts import InMemoryArtifactService

# Simply instantiate the class
in_memory_service_py = InMemoryArtifactService()

# Then pass it to the Runner
```

--------------------------------

### Illustrate ADK Artifact Lister Service Usage (Java)

Source: https://google.github.io/adk-docs/artifacts

This conceptual Java `main` method outlines how to initialize and use an ADK artifact lister service. It shows the setup with an `InMemoryArtifactService` and emphasizes the importance of managing asynchronous operation completion in production applications.

```java
    // --- Example Usage Concept (Java) ---
    public static void main(String[] args) {
        // BaseArtifactService service = new InMemoryArtifactService(); // Or GcsArtifactService
        // MyArtifactListerService lister = new MyArtifactListerService(service, "myJavaApp");
        // lister.listUserFilesJava("user123", "sessionABC");
        // Due to async nature, in a real app, ensure program waits or handles completion.
    }
}
```

--------------------------------

### Configure Gemini Live API for ADK Development via Environment Variables

Source: https://google.github.io/adk-docs/streaming/dev-guide/part1

This snippet demonstrates how to configure an `.env` file for local development using the Gemini Live API with ADK. By setting `GOOGLE_GENAI_USE_VERTEXAI` to `FALSE` and providing a `GOOGLE_API_KEY`, developers can rapidly prototype and experiment without requiring a Google Cloud project setup.

```plaintext
# .env.development
GOOGLE_GENAI_USE_VERTEXAI=FALSE
GOOGLE_API_KEY=your_api_key_here

```

--------------------------------

### CodeConfig Example for Callbacks and Tools (YAML)

Source: https://google.github.io/adk-docs/api-reference/agentconfig

This YAML snippet illustrates the structure of CodeConfig, which is used for referencing code components like functions or classes for callbacks and tools. It shows how to specify the 'name' of the code component and optionally provide 'args'.

```yaml
code_component:
  name: "my_library.custom_tools.MyTool"
  args:
    - name: "api_key"
      value: "sk-xxxxxxxxxxxxxxx"
    - name: "endpoint"
      value: "https://api.example.com/v1"
```

--------------------------------

### Initialize Parallel Research Agents in Java

Source: https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents

Sets up three specialized LLM-based researcher agents (Renewable Energy, Electric Vehicles, and Carbon Capture) that execute concurrently. Each agent uses the Gemini model with specific instructions and the Google Search tool to research its domain, storing results in state using unique output keys.

```java
LlmAgent researcherAgent1 = LlmAgent.builder()
    .name("RenewableEnergyResearcher")
    .model(GEMINI_MODEL)
    .instruction("""You are an AI Research Assistant specializing in energy.
    Research the latest advancements in 'renewable energy sources'.
    Use the Google Search tool provided.
    Summarize your key findings concisely (1-2 sentences).
    Output *only* the summary.""")
    .description("Researches renewable energy sources.")
    .tools(googleSearchTool)
    .outputKey("renewable_energy_result")
    .build();

LlmAgent researcherAgent2 = LlmAgent.builder()
    .name("EVResearcher")
    .model(GEMINI_MODEL)
    .instruction("""You are an AI Research Assistant specializing in transportation.
    Research the latest developments in 'electric vehicle technology'.
    Use the Google Search tool provided.
    Summarize your key findings concisely (1-2 sentences).
    Output *only* the summary.""")
    .description("Researches electric vehicle technology.")
    .tools(googleSearchTool)
    .outputKey("ev_technology_result")
    .build();

LlmAgent researcherAgent3 = LlmAgent.builder()
    .name("CarbonCaptureResearcher")
    .model(GEMINI_MODEL)
    .instruction("""You are an AI Research Assistant specializing in climate solutions.
    Research the current state of 'carbon capture methods'.
    Use the Google Search tool provided.
    Summarize your key findings concisely (1-2 sentences).
    Output *only* the summary.""")
    .description("Researches carbon capture methods.")
    .tools(googleSearchTool)
    .outputKey("carbon_capture_result")
    .build();
```

--------------------------------

### GET /sessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/VertexAiSessionService

Retrieves a specific session, optionally filtering the events included.

```APIDOC
## GET /sessions

### Description
Retrieves a specific session, optionally filtering the events included.

### Method
GET

### Endpoint
`/sessions`

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The ID of the user.
- **sessionId** (String) - Required - The ID of the session to retrieve.
- **config** (GetSessionConfig) - Optional - Configuration for retrieving the session, such as filtering events.

### Response
#### Success Response (200)
- **session** (Session) - The requested session object.

#### Response Example
```json
{
  "session": {
    "sessionId": "example-session-id",
    "appName": "example-app",
    "userId": "example-user",
    "state": {},
    "events": [
      {
        "stateDelta": {},
        "state": {}
      }
    ]
  }
}
```
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/artifacts/BaseArtifactService

Lists all artifact filenames present within a specific application, user, and session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

### Description
Lists all artifact filenames present within a specific application, user, and session.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

### Parameters
#### Path Parameters
- **appName** (string) - Required - The name of the application.
- **userId** (string) - Required - The ID of the user.
- **sessionId** (string) - Required - The ID of the session.

### Request Example
(No request body for GET)

### Response
#### Success Response (200)
- **filenames** (array of string) - A list of all artifact filenames within the session.

#### Response Example
{
  "filenames": [
    "my_document.txt",
    "config.json",
    "image.png"
  ]
}
```

--------------------------------

### Create AG-UI App with ADK

Source: https://google.github.io/adk-docs/tools/third-party/ag-ui

This command initializes a new AG-UI application with ADK support, setting up the basic structure for an agent-backed web client.

```bash
npx create-ag-ui-app@latest --adk

```

--------------------------------

### GET /getSession

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/InMemorySessionService

Retrieves a specific session, optionally filtering the events included.

```APIDOC
## GET /getSession

### Description
Retrieves a specific session, optionally filtering the events included.

### Method
GET

### Endpoint
/getSession

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The identifier of the user.
- **sessionId** (String) - Required - The unique identifier of the session to retrieve.
- **configOpt** (Optional<GetSessionConfig>) - Optional - Optional configuration to filter the events returned within the session (e.g., limit number of recent events, filter by timestamp). If empty, default retrieval behavior is used.

### Response
#### Success Response (200)
- **Session** (Session) - An `Optional` containing the `Session` if found, otherwise `Optional.empty()`.

#### Response Example
{
  "example": "{ \"sessionId\": \"retrieved-session-id\", \"appName\": \"exampleApp\", \"userId\": \"user123\", \"state\": { \"someKey\": \"someValue\" }, \"events\": [...] }"
}
```

--------------------------------

### Set Up Python LLM Agent Session and Runner

Source: https://google.github.io/adk-docs/callbacks

This asynchronous Python function, `setup_session_and_runner`, initializes an `InMemorySessionService` and creates a session for the application. It then instantiates a `Runner` object, linking it to the `my_llm_agent` and the session service, preparing the environment for agent interactions.

```python
APP_NAME = "guardrail_app"
USER_ID = "user_1"
SESSION_ID = "session_001"

async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=my_llm_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}/versions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/artifacts/BaseArtifactService

Lists all available versions (revision IDs) for a specific artifact identified by its filename.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}/versions

### Description
Lists all available versions (revision IDs) for a specific artifact identified by its filename.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}/versions

### Parameters
#### Path Parameters
- **appName** (string) - Required - The name of the application.
- **userId** (string) - Required - The ID of the user.
- **sessionId** (string) - Required - The ID of the session.
- **filename** (string) - Required - The name of the artifact file.

### Request Example
(No request body for GET)

### Response
#### Success Response (200)
- **versions** (array of integer) - A list of integer version numbers (revision IDs) for the artifact.

#### Response Example
{
  "versions": [
    1,
    2,
    3
  ]
}
```

--------------------------------

### Get Application Name (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Returns the name of the application associated with this session. The name is returned as a string.

```java
public String appName()
```

--------------------------------

### Initialize Gemini Model and Create Support Agent

Source: https://google.github.io/adk-docs/tools-custom

Creates a Gemini 2.0 Flash model instance and initializes a dedicated support agent with specific instructions. Sets up the support agent to handle escalated urgent issues.

```go
ctx := context.Background()
model, err := gemini.NewModel(ctx, "gemini-2.0-flash", &genai.ClientConfig{})
if err != nil {
    log.Fatal(err)
}

supportAgent, err := llmagent.New(llmagent.Config{
    Name:        "support_agent",
    Model:       model,
    Instruction: "You are the dedicated support agent. Mentioned you are a support handler and please help the user with their urgent issue.",
})
if err != nil {
    log.Fatal(err)
}
```

--------------------------------

### Setup and Run Agent with Callback (Python)

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

This Python code sets up an `LlmAgent` with the previously defined `modify_output_after_agent` callback. It then uses `InMemoryRunner` to simulate agent execution across two sessions: one with default state where the agent's output is used as-is, and another with a state that triggers the callback to modify the output. The output of each scenario is printed to demonstrate the callback's effect.

```python
from google.adk.agents import LlmAgent
from google.adk.runners import InMemoryRunner # Use InMemoryRunner
from google.genai import types # For types.Content

# Define the model - Use the specific model name requested
GEMINI_2_FLASH="gemini-2.0-flash"

# --- 1. Define the Callback Function ---
def modify_output_after_agent(callback_context: CallbackContext) -> Optional[types.Content]:
    """
    Logs exit from an agent and checks 'add_concluding_note' in session state.
    If True, returns new Content to *replace* the agent's original output.
    If False or not present, returns None, allowing the agent's original output to be used.
    """
    agent_name = callback_context.agent_name
    invocation_id = callback_context.invocation_id
    current_state = callback_context.state.to_dict()

    print(f"\n[Callback] Exiting agent: {agent_name} (Inv: {invocation_id})")
    print(f"[Callback] Current State: {current_state}")

    # Example: Check state to decide whether to modify the final output
    if current_state.get("add_concluding_note", False):
        print(f"[Callback] State condition 'add_concluding_note=True' met: Replacing agent {agent_name}'s output.")
        # Return Content to *replace* the agent's own output
        return types.Content(
            parts=[types.Part(text=f"Concluding note added by after_agent_callback, replacing original output.")],
            role="model" # Assign model role to the overriding response
        )
    else:
        print(f"[Callback] State condition not met: Using agent {agent_name}'s original output.")
        # Return None - the agent's output produced just before this callback will be used.
        return None

# --- 2. Setup Agent with Callback ---
llm_agent_with_after_cb = LlmAgent(
    name="MySimpleAgentWithAfter",
    model=GEMINI_2_FLASH,
    instruction="You are a simple agent. Just say 'Processing complete!'",
    description="An LLM agent demonstrating after_agent_callback for output modification",
    after_agent_callback=modify_output_after_agent # Assign the callback here
)

# --- 3. Setup Runner and Sessions using InMemoryRunner ---
async def main():
    app_name = "after_agent_demo"
    user_id = "test_user_after"
    session_id_normal = "session_run_normally"
    session_id_modify = "session_modify_output"

    # Use InMemoryRunner - it includes InMemorySessionService
    runner = InMemoryRunner(agent=llm_agent_with_after_cb, app_name=app_name)
    # Get the bundled session service to create sessions
    session_service = runner.session_service

    # Create session 1: Agent output will be used as is (default empty state)
    session_service.create_session(
        app_name=app_name,
        user_id=user_id,
        session_id=session_id_normal
        # No initial state means 'add_concluding_note' will be False in the callback check
    )
    # print(f"Session '{session_id_normal}' created with default state.")

    # Create session 2: Agent output will be replaced by the callback
    session_service.create_session(
        app_name=app_name,
        user_id=user_id,
        session_id=session_id_modify,
        state={"add_concluding_note": True} # Set the state flag here
    )
    # print(f"Session '{session_id_modify}' created with state={{'add_concluding_note': True}}.")


    # --- Scenario 1: Run where callback allows agent's original output ---
    print("\n" + "="*20 + f" SCENARIO 1: Running Agent on Session '{session_id_normal}' (Should Use Original Output) " + "="*20)
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id_normal,
        new_message=types.Content(role="user", parts=[types.Part(text="Process this please.")])
    ):
        # Print final output (either from LLM or callback override)
        if event.is_final_response() and event.content:
            print(f"Final Output: [{event.author}] {event.content.parts[0].text.strip()}")
        elif event.is_error():
             print(f"Error Event: {event.error_details}")

    # --- Scenario 2: Run where callback replaces the agent's output ---
    print("\n" + "="*20 + f" SCENARIO 2: Running Agent on Session '{session_id_modify}' (Should Replace Output) " + "="*20)
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id_modify,
        new_message=types.Content(role="user", parts=[types.Part(text="Process this and add note.")])
    ):
         # Print final output (either from LLM or callback override)
         if event.is_final_response() and event.content:
            print(f"Final Output: [{event.author}] {event.content.parts[0].text.strip()}")
         elif event.is_error():
             print(f"Error Event: {event.error_details}")

# --- 4. Execute ---
if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

```

--------------------------------

### Lookup Order Status Function Across Languages

Source: https://google.github.io/adk-docs/tools-custom

This set of examples demonstrates the implementation of an 'order status lookup' tool across different programming languages. It shows how to define the function signature, handle input parameters (order ID), and return structured success or error messages based on backend data.

```python
  if status_details := fetch_status_from_backend(order_id):
    return {
        "status": "success",
        "order": {
            "state": status_details.state,
            "tracking_number": status_details.tracking,
        },
    }
  else:
    return {"status": "error", "error_message": f"Order ID {order_id} not found."}
```

```typescript
/**
 * Fetches the current status of a customer's order using its ID.
 *
 * Use this tool ONLY when a user explicitly asks for the status of
 * a specific order and provides the order ID. Do not use it for
 * general inquiries.
 *
 * @param params The parameters for the function.
 * @param params.order_id The unique identifier of the order to look up.
 * @returns A dictionary indicating the outcome.
 *          On success, status is 'success' and includes an 'order' dictionary.
 *          On failure, status is 'error' and includes an 'error_message'.
 *          Example success: {'status': 'success', 'order': {'state': 'shipped', 'tracking_number': '1Z9...'}}
 *          Example error: {'status': 'error', 'error_message': 'Order ID not found.'}
 */
async function lookupOrderStatus(params: { order_id: string }): Promise<Record<string, any>> {
  // ... function implementation to fetch status from a backend ...
  const status_details = await fetchStatusFromBackend(params.order_id);
  if (status_details) {
    return {
      "status": "success",
      "order": {
        "state": status_details.state,
        "tracking_number": status_details.tracking,
      },
    };
  } else {
    return { "status": "error", "error_message": `Order ID ${params.order_id} not found.` };
  }
}

// Placeholder for a backend call
async function fetchStatusFromBackend(order_id: string): Promise<{state: string, tracking: string} | null> {
    if (order_id === "12345") {
        return { state: "shipped", tracking: "1Z9..." };
    }
    return null;
}
```

```go
import (
    "fmt"

    "google.golang.org/adk/tool"
)

type lookupOrderStatusArgs struct {
    OrderID string `json:"order_id" jsonschema:"The ID of the order to look up."`
}

type order struct {
    State          string `json:"state"`
    TrackingNumber string `json:"tracking_number"`
}

type lookupOrderStatusResult struct {
    Status string `json:"status"`
    Order  order  `json:"order,omitempty"`
}

func lookupOrderStatus(ctx tool.Context, args lookupOrderStatusArgs) (*lookupOrderStatusResult, error) {
    // ... function implementation to fetch status ...
    statusDetails, ok := fetchStatusFromBackend(args.OrderID)
    if !ok {
        return nil, fmt.Errorf("order ID %s not found", args.OrderID)
    }
    return &lookupOrderStatusResult{
        Status: "success",
        Order: order{
            State:          statusDetails.State,
            TrackingNumber: statusDetails.Tracking,
        },
    }, nil
}
```

--------------------------------

### GET /sessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/class-use/ListSessionsResponse

This endpoint retrieves a list of sessions filtered by application name and user ID. It provides an asynchronous way to fetch session data.

```APIDOC
## GET /sessions

### Description
This endpoint retrieves a list of sessions associated with a specific application and user.

### Method
GET

### Endpoint
/sessions

### Parameters
#### Query Parameters
- **appName** (string) - Required - The name of the application to filter sessions by.
- **userId** (string) - Required - The ID of the user whose sessions are to be listed.

#### Request Body
(Not applicable)

### Request Example
```
GET /sessions?appName=myApp&userId=user123
```

### Response
#### Success Response (200)
- **sessions** (array of objects) - A list of session objects.
  - **sessionId** (string) - The unique identifier for the session.
  - **startTime** (string) - The timestamp when the session started.
  - **endTime** (string) - The timestamp when the session ended (if applicable).
  - **status** (string) - The current status of the session.

#### Response Example
```json
{
  "sessions": [
    {
      "sessionId": "sess_abc123",
      "startTime": "2023-10-27T10:00:00Z",
      "endTime": "2023-10-27T11:00:00Z",
      "status": "active"
    },
    {
      "sessionId": "sess_def456",
      "startTime": "2023-10-27T09:30:00Z",
      "endTime": null,
      "status": "active"
    }
  ]
}
```
```

--------------------------------

### Get Evaluation Result - Spring Boot GET Endpoint

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Retrieves a specific evaluation result by its ID. This endpoint is a stub and not fully implemented. Accepts app name and evaluation result ID as path variables and returns a ResponseEntity indicating the endpoint status.

```java
@GetMapping("/apps/{appName}/eval_results/{evalResultId}")
public org.springframework.http.ResponseEntity<Object> getEvalResult(
    @PathVariable String appName,
    @PathVariable String evalResultId
)
```

--------------------------------

### Troubleshooting Guide

Source: https://google.github.io/adk-docs/deploy/gke

Common issues and solutions for deploying agents to Google Kubernetes Engine (GKE). Covers permission errors, database issues, streaming limitations, and deployment problems with diagnostic commands and fixes.

```APIDOC
# Troubleshooting Guide

## 403 Permission Denied for Gemini 2.0 Flash

### Issue
Kubernetes service account lacks necessary permissions to access the Vertex AI API.

### Solutions
1. Ensure service account is created and bound to the `Vertex AI User` role
2. If using AI Studio, verify the `GOOGLE_API_KEY` environment variable is set in the deployment manifest and is valid

---

## 404 Not Found Response

### Issue
Error in the request configuration or endpoint.

### Diagnostic Command
```
export POD_NAME=$(kubectl get pod -l app=adk-agent -o jsonpath='{.items[0].metadata.name}')
kubectl logs $POD_NAME
```

### Solution
Check the application logs using the command above to diagnose the specific problem.

---

## Attempt to Write a Readonly Database

### Issue
SQLite database is read-only, preventing session creation and message responses. Occurs when database is copied into container during image build.

### Error Message
```
sqlalchemy.exc.OperationalError: (sqlite3.OperationalError) attempt to write a readonly database
[SQL: UPDATE app_states SET state=?, update_time=CURRENT_TIMESTAMP WHERE app_states.app_name = ?]
```

### Solutions

#### Option 1: Delete Local Database
Delete the SQLite database before building the container:
```
rm -f sessions.db
```

#### Option 2: Use .dockerignore (Recommended)
Create a `.dockerignore` file in your project directory:
```
sessions.db
```

Then rebuild and redeploy the application.

---

## Insufficient Permission to Stream Logs

### Issue
Lack of permissions to stream build logs or VPC-SC security policy restricts access to logs bucket.

### Error
`ERROR: (gcloud.builds.submit)`

### Solutions
1. Follow the link provided in the error message to check build progress
2. Navigate to the Cloud Build page in Google Cloud Console
3. Verify image was built and pushed to Artifact Registry using the build commands

---

## Gemini-2.0-Flash Not Supported in Live API

### Issue
Text-based chat works but voice features fail when using ADK Dev UI. Microphone button causes websocket connection error.

### Error Message
```
websockets.exceptions.ConnectionClosedError: model "gemini-2.0-flash" not supported in the live api
```

### Root Cause
The configured model does not support the Gemini Live API, which is required for real-time bidirectional audio and video streaming.

### Solution
Configure the agent with a model that supports the Gemini Live API for voice functionality.
```

--------------------------------

### Customizing Agent Tools in Java

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This Java example illustrates the creation of a `summaryAgent` and a `rootAgent` using the ADK library. The `rootAgent` is configured to use the `summaryAgent` as a tool for text summarization, ensuring that user prompts are forwarded directly to the tool. The code then demonstrates how to run a session with the `rootAgent` and stream its responses.

```java
import com.google.adk.agents.LlmAgent;
import com.google.adk.events.Event;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.adk.tools.AgentTool;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;

public class AgentToolCustomization {

  private static final String APP_NAME = "summary_agent";
  private static final String USER_ID = "user1234";

  public static void initAgentAndRun(String prompt) {

    LlmAgent summaryAgent =
        LlmAgent.builder()
            .model("gemini-2.0-flash")
            .name("summaryAgent")
            .instruction(
                "You are an expert summarizer. Please read the following text and provide a concise summary.")
            .description("Agent to summarize text")
            .build();

    // Define root_agent
    LlmAgent rootAgent =
        LlmAgent.builder()
            .model("gemini-2.0-flash")
            .name("rootAgent")
            .instruction(
                "You are a helpful assistant. When the user provides a text, always use the 'summaryAgent' tool to generate a summary. Always forward the user's message exactly as received to the 'summaryAgent' tool, without modifying or summarizing it yourself. Present the response from the tool to the user.")
            .description("Assistant agent")
            .tools(AgentTool.create(summaryAgent, true)) // Set skipSummarization to true
            .build();

    // Create an InMemoryRunner
    InMemoryRunner runner = new InMemoryRunner(rootAgent, APP_NAME);
    // InMemoryRunner automatically creates a session service. Create a session using the service
    Session session = runner.sessionService().createSession(APP_NAME, USER_ID).blockingGet();
    Content userMessage = Content.fromParts(Part.fromText(prompt));

    // Run the agent
    Flowable<Event> eventStream = runner.runAsync(USER_ID, session.id(), userMessage);

    // Stream event response
    eventStream.blockingForEach(
        event -> {
          if (event.finalResponse()) {
            System.out.println(event.stringifyContent());
          }
        });
  }

  public static void main(String[] args) {
    String longText =
        """
            Quantum computing represents a fundamentally different approach to computation,
            leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers
            that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively
            being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled,

```

--------------------------------

### Configure environment for Google Cloud Vertex AI

Source: https://google.github.io/adk-docs/get-started/streaming/quickstart-streaming

Sets up environment variables in .env file for using Google Cloud Vertex AI with the Gemini Live API. Requires an existing Google Cloud project, gcloud CLI setup, and Vertex AI API enabled. The location defaults to us-central1 but can be customized.

```bash
GOOGLE_GENAI_USE_VERTEXAI=TRUE
GOOGLE_CLOUD_PROJECT=PASTE_YOUR_ACTUAL_PROJECT_ID
GOOGLE_CLOUD_LOCATION=us-central1
```

--------------------------------

### adk create

Source: https://google.github.io/adk-docs/api-reference/cli/cli

Creates a new agent application in the specified folder with a prepopulated agent template. Requires an application name and supports optional configuration for AI model selection and cloud backend setup.

```APIDOC
## POST adk create

### Description
Creates a new app in the current folder with a prepopulated agent template. Initializes the agent source code directory with template files and optional model configuration.

### Method
POST

### Endpoint
adk create [OPTIONS] APP_NAME

### Parameters
#### Required Arguments
- **APP_NAME** (string) - Required - The folder path for the agent source code

#### Optional Parameters
- **--model** (string) - Optional - The AI model used for the root agent
- **--api_key** (string) - Optional - The API Key needed to access the model (e.g., Google AI API Key)
- **--project** (string) - Optional - The Google Cloud Project ID for using VertexAI as backend
- **--region** (string) - Optional - The Google Cloud Region for using VertexAI as backend

### Request Examples
```
# Create app with minimal configuration
adk create path/to/my_app

# Create app with specific model
adk create --model gemini-2.0-flash path/to/my_app

# Create app with Google AI API Key
adk create --model gemini-2.0-flash --api_key YOUR_API_KEY path/to/my_app

# Create app with VertexAI backend
adk create --project my-gcp-project --region us-central1 path/to/my_app
```

### Response
#### Success Response (201)
- Agent application directory created at specified path
- Prepopulated template files initialized
- Configuration applied based on provided options

### Notes
- APP_NAME is the only required argument
- Model configuration is optional; defaults apply if not specified
- VertexAI backend requires both --project and --region parameters
- Google AI API Key configuration requires --api_key parameter
```

--------------------------------

### Authenticate and Control Summarization with ToolContext (Python)

Source: https://google.github.io/adk-docs/callbacks/design-patterns-and-best-practices

Demonstrates how to use `ToolContext` within `before_tool_callback` and `after_tool_callback` to handle authentication by requesting credentials and to control LLM summarization by skipping it. This is crucial for managing secure tool interactions and customizing output processing.

```Python
from autogen import ToolContext

def before_tool_callback(tool_context: ToolContext, **kwargs):
    # Example: Check if authentication is needed and request credentials
    if not tool_context.get_auth_response():
        auth_config = {"type": "oauth", "scopes": ["read", "write"]}
        tool_context.request_credential(auth_config)

def after_tool_callback(tool_context: ToolContext, **kwargs):
    # Example: Skip summarization for structured JSON output
    if tool_context.tool.name == "get_structured_data":
        tool_context.actions.skip_summarization = True

```

--------------------------------

### Launch ADK Agent Development UI (Shell)

Source: https://google.github.io/adk-docs/grounding/vertex_ai_search_grounding

This command launches the Agent Development Kit (ADK) web UI, enabling interactive development and testing. It typically starts a local server (e.g., `http://localhost:8000`) for browser access. Windows users facing `_make_subprocess_transport NotImplementedError` should use `adk web --no-reload`.

```shell
adk web
```

--------------------------------

### Persistent Queue Pattern - Correct Implementation

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Demonstrates the correct approach for using a single LiveRequestQueue across all agents in a sequence. Shows proper queue management versus the incorrect pattern of creating new queues per agent.

```python
# ❌ INCORRECT: New queue per agent
for agent in agents:
    new_queue = LiveRequestQueue()  # WRONG!

# ✅ CORRECT: Single queue for entire workflow
queue = LiveRequestQueue()
async for event in runner.run_live(live_request_queue=queue):
    ...
```

--------------------------------

### List Available Apps on Cloud Run Service

Source: https://google.github.io/adk-docs/deploy/cloud-run

Retrieves a list of available applications deployed on the Cloud Run service using a GET request. Requires authentication token if the service is not publicly accessible.

```bash
curl -X GET -H "Authorization: Bearer $TOKEN" $APP_URL/list-apps
```

--------------------------------

### Run Agent with Event Streaming (Go)

Source: https://google.github.io/adk-docs/agents/custom-agents

Creates a runner, executes the agent with streaming mode, and iterates through events to accumulate and display the final text response. Includes error handling and final session state retrieval.

```go
r, err := runner.New(runner.Config{
    AppName:        appName,
    Agent:          storyFlowAgent,
    SessionService: sessionService,
})
if err != nil {
    log.Fatalf("Failed to create runner: %v", err)
}

input := genai.NewContentFromText("Generate a story about: "+userTopic, genai.RoleUser)
events := r.Run(ctx, userID, sessionInstance.Session.ID(), input, agent.RunConfig{
    StreamingMode: agent.StreamingModeSSE,
})

var finalResponse string
for event, err := range events {
    if err != nil {
        log.Fatalf("An error occurred during agent execution: %v", err)
    }

    for _, part := range event.Content.Parts {
        finalResponse += part.Text
    }
}

fmt.Println("\n--- Agent Interaction Result ---")
fmt.Println("Agent Final Response: " + finalResponse)

finalSession, err := sessionService.Get(ctx, &session.GetRequest{
    UserID:    userID,
    AppName:   appName,
    SessionID: sessionInstance.Session.ID(),
})

if err != nil {
    log.Fatalf("Failed to retrieve final session: %v", err)
}

fmt.Println("Final Session State:", finalSession.Session.State())
```

--------------------------------

### Initialize Gemini Agent with Google Search Tool

Source: https://google.github.io/adk-docs/tools/gemini-api/google-search

Builds a Gemini 2.0 Flash LLM agent configured with Google Search capability. The agent is initialized with a name, model specification, description, instructions, and a list of available tools. This setup enables the agent to answer questions by performing internet searches.

```java
GoogleSearchTool googleSearchTool = new GoogleSearchTool();

BaseAgent rootAgent =
    LlmAgent.builder()
        .name("basic_search_agent")
        .model("gemini-2.0-flash")
        .description("Agent to answer questions using Google Search.")
        .instruction(
            "I can answer your questions by searching the internet. Just ask me anything!")
        .tools(ImmutableList.of(googleSearchTool))
        .build();
```

--------------------------------

### GET /listEvents

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/InMemorySessionService

Lists the events within a specific session. Supports pagination via the response object.

```APIDOC
## GET /listEvents

### Description
Lists the events within a specific session. Supports pagination via the response object.

### Method
GET

### Endpoint
/listEvents

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The identifier of the user.
- **sessionId** (String) - Required - The unique identifier of the session whose events are to be listed.

### Response
#### Success Response (200)
- **ListEventsResponse** (ListEventsResponse) - A `ListEventsResponse` containing a list of events and an optional token for retrieving the next page.

#### Response Example
{
  "example": "{ \"events\": [ { \"eventId\": \"event1\", \"timestamp\": 1678886400000, \"type\": \"click\" }, { \"eventId\": \"event2\", \"timestamp\": 1678886410000, \"type\": \"scroll\" } ], \"nextPageToken\": \"next-token-if-any\" }"
}
```

--------------------------------

### Create Session and Runner for Agent

Source: https://google.github.io/adk-docs/agents/llm-agents

Initialize an in-memory session service and create a session for the agent, then instantiate a Runner to manage agent interactions. This setup is required before making agent calls.

```python
session_service = InMemorySessionService()
session = session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
runner = Runner(agent=agent, app_name=APP_NAME, session_service=session_service)
```

--------------------------------

### Configure Proactivity and Affective Dialog

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Set up the RunConfig to enable proactive audio responses and emotional dialog adaptation. This configuration allows the model to intelligently decide when to respond and adjust its tone based on detected emotions.

```APIDOC
## RunConfig Configuration

### Description
Configures the Gemini Live API to enable proactive audio and affective dialog features for more natural and empathetic interactions.

### Configuration Parameters

#### proactivity (ProactivityConfig)
- **proactive_audio** (boolean) - Optional - Enables the model to initiate responses without explicit prompts, offer suggestions, and anticipate user needs

#### enable_affective_dialog (boolean)
- **enable_affective_dialog** (boolean) - Optional - Enables the model to detect and adapt to emotional cues in voice tone and content

#### response_modalities (array)
- **response_modalities** (string[]) - Optional - Specifies response format (e.g., "AUDIO")

#### streaming_mode (StreamingMode)
- **streaming_mode** (enum) - Optional - Sets streaming behavior (e.g., StreamingMode.BIDI for bidirectional streaming)

### Request Example
```
from google.genai import types
from google.adk.agents.run_config import RunConfig

run_config = RunConfig(
    proactivity=types.ProactivityConfig(proactive_audio=True),
    enable_affective_dialog=True
)
```

### Response Behavior

#### Proactivity Features
When enabled, the model can:
- Offer suggestions without being asked
- Provide follow-up information proactively
- Ignore irrelevant or off-topic input
- Anticipate user needs based on context

#### Affective Dialog Features
The model analyzes emotional cues to:
- Detect user emotions (frustrated, happy, confused, etc.)
- Adapt response style and tone accordingly
- Provide empathetic responses in customer service scenarios
- Adjust formality based on detected sentiment

### Platform Compatibility

#### Gemini Live API
- ✅ Supported on `gemini-2.5-flash-native-audio-preview-12-2025` (native audio model)
- ❌ Not supported on `gemini-live-2.5-flash-preview` (half-cascade model)

#### Vertex AI Live API
- ❌ Not currently supported on `gemini-live-2.5-flash` (half-cascade model)
- ⚠️ Requires native audio models (only available on Gemini Live API)

### Important Notes
- Proactive and affective behaviors are probabilistic
- Model's emotional awareness and proactive suggestions vary based on context and conversation history
- Features require native audio models exclusively
```

--------------------------------

### AgentRefConfig Example for Sub-Agents (YAML)

Source: https://google.github.io/adk-docs/api-reference/agentconfig

This YAML snippet shows how to reference another agent using AgentRefConfig within the 'sub_agents' list of a parent agent. It demonstrates using 'config_path' to point to the configuration of the referenced agent.

```yaml
sub_agents:
  - config_path: "./agents/child_agent_config.yaml"
```

--------------------------------

### Deploy MCP Server with Streamable HTTP on Cloud Run

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

Sets up and runs an MCP server on Cloud Run using Streamable HTTP with stateless mode for scalability. The main function configures the session manager, creates a Starlette ASGI application with proper lifecycle management, and starts a uvicorn server listening on 0.0.0.0:8080. Includes logging and production-ready settings.

```python
def main(port: int = 8080, json_response: bool = False):
    """Main server function."""
    logging.basicConfig(level=logging.INFO)

    app = create_mcp_server()

    session_manager = StreamableHTTPSessionManager(
        app=app,
        event_store=None,
        json_response=json_response,
        stateless=True
    )

    async def handle_streamable_http(scope: Scope, receive: Receive, send: Send) -> None:
        await session_manager.handle_request(scope, receive, send)

    @contextlib.asynccontextmanager
    async def lifespan(app: Starlette) -> AsyncIterator[None]:
        """Manage session manager lifecycle."""
        async with session_manager.run():
            logger.info("MCP Streamable HTTP server started!")
            try:
                yield
            finally:
                logger.info("MCP server shutting down...")

    starlette_app = Starlette(
        debug=False,
        routes=[
            Mount("/mcp", app=handle_streamable_http),
        ],
        lifespan=lifespan,
    )

    import uvicorn
    uvicorn.run(starlette_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    main()
```

--------------------------------

### runLiveImpl - Live Sequential Agent Implementation

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SequentialAgent

Protected implementation method for live SequentialAgent execution. Handles continuous streams of audio or video input and supports task completion signaling through a task_completed() function to determine when to pass control to the next agent.

```APIDOC
## runLiveImpl

### Description
Protected implementation for live SequentialAgent execution. Processes continuous streams of audio or video without a predetermined end point. Introduces task completion signaling mechanism allowing the model to indicate task completion and trigger transition to the next agent in sequence.

### Method
AsyncGenerator Function (Protected)

### Signature
```typescript
protected runLiveImpl(context: InvocationContext): AsyncGenerator<Event, void, void>
```

### Parameters
#### Input Parameters
- **context** (InvocationContext) - Required - The invocation context containing execution state and configuration for the live implementation.

### Returns
**AsyncGenerator<Event, void, void>** - An AsyncGenerator that yields the events generated by the agent during live execution.

### Key Features
- Processes continuous audio/video streams without predetermined end conditions
- Implements task_completed() function for model-initiated task completion signaling
- Enables sequential agent chaining by detecting completion signals
- Yields events as they are generated during the live session

### Task Completion Mechanism
Unlike non-live execution, live agents cannot automatically determine completion. The model must explicitly call task_completed() to signal:
- Current task has finished processing
- System should transition to the next sequential agent
- Stream processing should conclude for current agent

### Usage Notes
- This is a protected method, typically called internally by runLive()
- Designed specifically for SequentialAgent implementations
- Requires proper context initialization and parent agent setup
- Handles indefinite stream processing with explicit completion signals
```

--------------------------------

### CONFIGURE Google Calendar Toolset with OAuth2 Authentication

Source: https://google.github.io/adk-docs/tools-custom/authentication

This section provides an example of configuring the specialized `calendar_tool_set` with OAuth2 authentication, requiring a Google OAuth Client ID and Client Secret.

```APIDOC
## CONFIGURE Google Calendar Toolset with OAuth2 Authentication

### Description
Configures the Google Calendar toolset with OAuth2 credentials (client ID and client secret) specific to Google's authentication flow.

### Method
CONFIGURATION

### Endpoint
calendar_tool_set.configure_auth

### Parameters
#### Request Body
- **client_id** (string) - Required - Your Google OAuth client ID.
- **client_secret** (string) - Required - Your Google OAuth client secret.

### Request Example
```python
# Example: Configuring Google Calendar Tools
from google.adk.tools.google_api_tool import calendar_tool_set

client_id = "YOUR_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com"
client_secret = "YOUR_GOOGLE_OAUTH_CLIENT_SECRET"

# Use the specific configure method for this toolset type
calendar_tool_set.configure_auth(
    client_id=oauth_client_id, client_secret=oauth_client_secret
)

# agent = LlmAgent(..., tools=calendar_tool_set.get_tool('calendar_tool_set'))
```

### Response
#### Success Response (200)
- **status** (string) - Indicates successful configuration.

#### Response Example
N/A (Represents successful internal configuration)
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Lists the names of all artifacts associated with a specific user session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

### Description
Lists the names of all artifacts associated with a session.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.
- **userId** (String) - Required - The user ID.
- **sessionId** (String) - Required - The session ID.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **artifactNames** (List<String>) - A list of artifact names.

#### Response Example
[
  "my_artifact_1",
  "another_artifact",
  "config_file"
]
```

--------------------------------

### GetSessionConfig - Session Configuration

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/package-use

Configuration object for getting a session. Provides configuration parameters and options for retrieving session information.

```APIDOC
## GetSessionConfig

### Description
Configuration for getting a session. Encapsulates all configuration parameters needed to retrieve and initialize a session.

### Related Classes
- `GetSessionConfig.Builder` - Builder for constructing GetSessionConfig instances

### Usage
Used to configure session retrieval operations with specific parameters and options.
```

--------------------------------

### CONFIGURE OpenAPIToolset with OAuth2 Authentication

Source: https://google.github.io/adk-docs/tools-custom/authentication

This section demonstrates how to initialize an `OpenAPIToolset` using OAuth2 for secure access, including setting up authorization and token URLs, and defining scopes.

```APIDOC
## CONFIGURE OpenAPIToolset with OAuth2 Authentication

### Description
Configures an OpenAPIToolset instance for OAuth2 authentication, specifying flow details, authorization/token endpoints, scopes, client ID, and client secret.

### Method
CONFIGURATION

### Endpoint
OpenAPIToolset Initialization

### Parameters
#### Request Body
- **authorizationUrl** (string) - Required - The URL for the OAuth2 authorization endpoint.
- **tokenUrl** (string) - Required - The URL for the OAuth2 token endpoint.
- **scopes** (object) - Required - A dictionary of scopes required, mapping scope names to descriptions.
- **client_id** (string) - Required - Your application's OAuth2 client ID.
- **client_secret** (string) - Required - Your application's OAuth2 client secret.
- **spec_str** (string) - Required - The OpenAPI specification string.
- **spec_str_type** (string) - Required - The type of the OpenAPI specification string (e.g., "yaml", "json").

### Request Example
```python
from google.adk.tools.openapi_tool.openapi_spec_parser.openapi_toolset import OpenAPIToolset
from fastapi.openapi.models import OAuth2
from fastapi.openapi.models import OAuthFlowAuthorizationCode
from fastapi.openapi.models import OAuthFlows
from google.adk.auth import AuthCredential
from google.adk.auth import AuthCredentialTypes
from google.adk.auth import OAuth2Auth

auth_scheme = OAuth2(
    flows=OAuthFlows(
        authorizationCode=OAuthFlowAuthorizationCode(
            authorizationUrl="https://accounts.google.com/o/oauth2/auth",
            tokenUrl="https://oauth2.googleapis.com/token",
            scopes={
                "https://www.googleapis.com/auth/calendar": "calendar scope"
            },
        )
    )
)
auth_credential = AuthCredential(
    auth_type=AuthCredentialTypes.OAUTH2,
    oauth2=OAuth2Auth(
        client_id=YOUR_OAUTH_CLIENT_ID,
        client_secret=YOUR_OAUTH_CLIENT_SECRET
    ),
)

calendar_api_toolset = OpenAPIToolset(
    spec_str=google_calendar_openapi_spec_str, # Fill this with an openapi spec
    spec_str_type='yaml',
    auth_scheme=auth_scheme,
    auth_credential=auth_credential,
)
```

### Response
#### Success Response (200)
- **toolset** (OpenAPIToolset) - A configured OpenAPIToolset instance.

#### Response Example
N/A (Represents successful object initialization)
```

--------------------------------

### Example Return Value from Stock Price Tool

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This snippet illustrates the expected JSON-like structure of the return value from the getStockPrice tool when successfully retrieving a price for a given stock symbol.

```json
{"symbol": "GOOG", "price": "1.0"}
```

--------------------------------

### Create and Run an ADK Agent with Claude Sonnet (Python)

Source: https://google.github.io/adk-docs/tutorials/agent-team

This code snippet demonstrates the end-to-end process of setting up and running an ADK agent using Claude Sonnet as its underlying language model, integrated via LiteLLM. It initializes the `Agent` with a description and tools, configures an `InMemorySessionService` for conversation state, creates a specific session, and then sets up a `Runner` to execute queries against the agent. The example shows how to asynchronously call the agent with a query, handling potential errors in agent creation or execution.

```python
weather_agent_claude = None # Initialize to None
runner_claude = None      # Initialize runner to None

try:
    weather_agent_claude = Agent(
        name="weather_agent_claude",
        # Key change: Wrap the LiteLLM model identifier
        model=LiteLlm(model=MODEL_CLAUDE_SONNET),
        description="Provides weather information (using Claude Sonnet).",
        instruction="You are a helpful weather assistant powered by Claude Sonnet. "
                    "Use the 'get_weather' tool for city weather requests. "
                    "Analyze the tool's dictionary output ('status', 'report'/'error_message'). "
                    "Clearly present successful reports or polite error messages.",
        tools=[get_weather] # Re-use the same tool
    )
    print(f"Agent '{weather_agent_claude.name}' created using model '{MODEL_CLAUDE_SONNET}'.")

    # InMemorySessionService is simple, non-persistent storage for this tutorial.
    session_service_claude = InMemorySessionService() # Create a dedicated service

    # Define constants for identifying the interaction context
    APP_NAME_CLAUDE = "weather_tutorial_app_claude" # Unique app name
    USER_ID_CLAUDE = "user_1_claude"
    SESSION_ID_CLAUDE = "session_001_claude" # Using a fixed ID for simplicity

    # Create the specific session where the conversation will happen
    session_claude = await session_service_claude.create_session(
        app_name=APP_NAME_CLAUDE,
        user_id=USER_ID_CLAUDE,
        session_id=SESSION_ID_CLAUDE
    )
    print(f"Session created: App='{APP_NAME_CLAUDE}', User='{USER_ID_CLAUDE}', Session='{SESSION_ID_CLAUDE}'")

    # Create a runner specific to this agent and its session service
    runner_claude = Runner(
        agent=weather_agent_claude,
        app_name=APP_NAME_CLAUDE,       # Use the specific app name
        session_service=session_service_claude # Use the specific session service
        )
    print(f"Runner created for agent '{runner_claude.agent.name}'.")

    # --- Test the Claude Agent ---
    print("\n--- Testing Claude Agent ---")
    # Ensure call_agent_async uses the correct runner, user_id, session_id
    await call_agent_async(query = "Weather in London please.",
                           runner=runner_claude,
                           user_id=USER_ID_CLAUDE,
                           session_id=SESSION_ID_CLAUDE)

    # --- OR ---

    # Uncomment the following lines if running as a standard Python script (.py file):
    # import asyncio
    # if __name__ == "__main__":
    #     try:
    #         asyncio.run(call_agent_async(query = "Weather in London please.",
    #                      runner=runner_claude,
    #                       user_id=USER_ID_CLAUDE,
    #                       session_id=SESSION_ID_CLAUDE)
    #     except Exception as e:
    #         print(f"An error occurred: {e}")


except Exception as e:
    print(f"❌ Could not create or run Claude agent '{MODEL_CLAUDE_SONNET}'. Check API Key and model name. Error: {e}")
```

--------------------------------

### Basic Usage Pattern - Event Iteration

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Demonstrates the simplest way to consume events from run_live() using an async for-loop. Shows how to iterate over the async generator, serialize events, and send them over a WebSocket connection.

```APIDOC
## Consuming Events from run_live()

### Description
Basic pattern for iterating over the async generator and processing events in real-time. Events are serialized to JSON and transmitted immediately as they're received.

### Usage Example
```python
async for event in runner.run_live(
    user_id=user_id,
    session_id=session_id,
    live_request_queue=live_request_queue,
    run_config=run_config
):
    event_json = event.model_dump_json(exclude_none=True, by_alias=True)
    logger.debug(f"[SERVER] Event: {event_json}")
    await websocket.send_text(event_json)
```

### Key Points
- Use `async for` to iterate over the event stream
- Events are yielded immediately as generated
- No buffering or polling required
- Serialize events using `model_dump_json()` with `exclude_none=True` and `by_alias=True`
- Send serialized events over network transport (e.g., WebSocket)

### Event Processing
- **event** - Individual Event object yielded by the generator
- **event_json** - Serialized JSON representation of the event
- Events include: text, audio, transcriptions, tool calls, interruption signals, turn completion signals

### Requirements
- Async context required
- Valid user_id and session_id matching SessionService.create_session() identifiers
- Active LiveRequestQueue for bidirectional communication
- WebSocket or other transport mechanism for sending events
```

--------------------------------

### Define and Run an Agent Using Another Agent as a Tool (TypeScript/Go)

Source: https://google.github.io/adk-docs/tools/function-tools

This example demonstrates how to configure an ADK `LlmAgent` to use another `LlmAgent` as a tool. The main agent delegates specific tasks, such as summarization, to a dedicated sub-agent, showcasing agent orchestration. It defines both the summarizer and main agents, then runs a session with a long text input to observe the delegation.

```typescript
/**
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import {
  AgentTool,
  InMemoryRunner,
  LlmAgent,
} from '@google/adk';
import {Part, createUserContent} from '@google/genai';

/**
 * This example demonstrates how to use an agent as a tool.
 */
async function main() {
  // Define the summarization agent that will be used as a tool
  const summaryAgent = new LlmAgent({
    name: 'summary_agent',
    model: 'gemini-2.5-flash',
    description: 'Agent to summarize text',
    instruction:
      'You are an expert summarizer. Please read the following text and provide a concise summary.',
  });

  // Define the main agent that uses the summarization agent as a tool.
  // skipSummarization is set to true, so the main_agent will directly output
  // the result from the summary_agent without further processing.
  const mainAgent = new LlmAgent({
    name: 'main_agent',
    model: 'gemini-2.5-flash',
    instruction:
      "You are a helpful assistant. When the user provides a text, use the 'summary_agent' tool to generate a summary. Always forward the user's message exactly as received to the 'summary_agent' tool, without modifying or summarizing it yourself. Present the response from the tool to the user.",
    tools: [new AgentTool({agent: summaryAgent, skipSummarization: true})],
  });

  const appName = 'agent-as-a-tool-app';
  const runner = new InMemoryRunner({agent: mainAgent, appName});

  const longText = `Quantum computing represents a fundamentally different approach to computation, 
leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers 
that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively 
being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled, 
meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and 
interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such 
as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far 
faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages.`;

  // Create the session before running the agent
  await runner.sessionService.createSession({
    appName,
    userId: 'user1',
    sessionId: 'session1',
  });

  // Run the agent with the long text to summarize
  const events = runner.runAsync({
    userId: 'user1',
    sessionId: 'session1',
    newMessage: createUserContent(longText),
  });

  // Print the final response from the agent
  console.log('Agent Response:');
  for await (const event of events) {
    if (event.content?.parts?.length) {
      const responsePart = event.content.parts.find((p: Part) => p.functionResponse);
      if (responsePart && responsePart.functionResponse) {
        console.log(responsePart.functionResponse.response);
      }
    }
  }
}

main();
```

```go
import (
    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/agenttool"
    "google.golang.org/genai"
)

// createSummarizerAgent creates an agent whose sole purpose is to summarize text.
func createSummarizerAgent(ctx context.Context) (agent.Agent, error) {
    model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{})
    if err != nil {
        return nil, err
    }
    return llmagent.New(llmagent.Config{
        Name:        "SummarizerAgent",
        Model:       model,
        Instruction: "You are an expert at summarizing text. Take the user's input and provide a concise summary.",
        Description: "An agent that summarizes text.",
    })
}

// createMainAgent creates the primary agent that will use the summarizer agent as a tool.
func createMainAgent(ctx context.Context, tools ...tool.Tool) (agent.Agent, error) {
    model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{})
    if err != nil {
        return nil, err
    }
    return llmagent.New(llmagent.Config{
```

--------------------------------

### Trace Agent Interactions with Tools

Source: https://google.github.io/adk-docs/observability/phoenix

Demonstrates how to set up an agent with a tool and run it asynchronously. All interactions, including tool calls and responses, will be automatically traced and sent to Phoenix due to the prior setup.

```python
import nest_asyncio
nest_asyncio.apply()

from google.adk.agents import Agent
from google.adk.runners import InMemoryRunner
from google.genai import types

# Define a tool function
def get_weather(city: str) -> dict:
    """Retrieves the current weather report for a specified city.

    Args:
        city (str): The name of the city for which to retrieve the weather report.

    Returns:
        dict: status and result or error msg.
    """
    if city.lower() == "new york":
        return {
            "status": "success",
            "report": (
                "The weather in New York is sunny with a temperature of 25 degrees"
                " Celsius (77 degrees Fahrenheit)."
            ),
        }
    else:
        return {
            "status": "error",
            "error_message": f"Weather information for '{city}' is not available.",
        }

# Create an agent with tools
agent = Agent(
    name="weather_agent",
    model="gemini-2.0-flash-exp",
    description="Agent to answer questions using weather tools.",
    instruction="You must use the available tools to find an answer.",
    tools=[get_weather]
)

app_name = "weather_app"
user_id = "test_user"
session_id = "test_session"
runner = InMemoryRunner(agent=agent, app_name=app_name)
session_service = runner.session_service

await session_service.create_session(
    app_name=app_name,
    user_id=user_id,
    session_id=session_id
)

# Run the agent (all interactions will be traced)
async for event in runner.run_async(
    user_id=user_id,
    session_id=session_id,
    new_message=types.Content(role="user", parts=[
        types.Part(text="What is the weather in New York?")]
    )
):
    if event.is_final_response():
        print(event.content.parts[0].text.strip())

```

--------------------------------

### Create OpenAPI Tool with OAuth2 Authentication

Source: https://google.github.io/adk-docs/tools/authentication

Shows how to configure an OpenAPI toolset with OAuth2 authentication scheme and credentials. Includes setup of OAuth2 flows with Google authorization and token endpoints, suitable for APIs requiring user consent-based access.

```python
from google.adk.tools.openapi_tool.openapi_spec_parser.openapi_toolset import OpenAPIToolset
from fastapi.openapi.models import OAuth2
from fastapi.openapi.models import OAuthFlowAuthorizationCode
from fastapi.openapi.models import OAuthFlows
from google.adk.auth import AuthCredential
from google.adk.auth import AuthCredentialTypes
from google.adk.auth import OAuth2Auth

auth_scheme = OAuth2(
    flows=OAuthFlows(
        authorizationCode=OAuthFlowAuthorizationCode(
            authorizationUrl="https://accounts.google.com/o/oauth2/auth",
            tokenUrl="https://oauth2.googleapis.com/token",
            scopes={
                "https://www.googleapis.com/auth/calendar": "calendar scope"
            },
        )
    )
)
auth_credential = AuthCredential(
    auth_type=AuthCredentialTypes.OAUTH2,
    oauth2=OAuth2Auth(
        client_id=YOUR_OAUTH_CLIENT_ID,
        client_secret=YOUR_OAUTH_CLIENT_SECRET
    ),
)

calendar_api_toolset = OpenAPIToolset(
    spec_str=google_calendar_openapi_spec_str,
    spec_str_type='yaml',
    auth_scheme=auth_scheme,
    auth_credential=auth_credential,
)
```

--------------------------------

### Example ADK Project Directory Structure

Source: https://google.github.io/adk-docs/grounding/google_search_grounding

Illustrates the expected directory structure for both Python and TypeScript ADK projects after setting up the agent and environment. This helps visualize the placement of agent modules, configuration files, and package management files.

```plaintext
my_project/
    google_search_agent/
        __init__.py
        agent.py
    .env
```

```plaintext
my_project/
    google_search_agent/
        agent.ts
    package.json
    tsconfig.json
    .env
```

--------------------------------

### Handle Streaming Text, Interruption, and Turn Completion

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

Comprehensive implementation showing how to handle streaming text updates, interruption events, and turn completion in a single async loop. Manages partial text display, audio playback control, and input readiness state based on multiple event flags.

```python
async for event in runner.run_live(...):
    # Handle streaming text
    if event.content and event.content.parts and event.content.parts[0].text:
        if event.partial:
            # Your logic to show typing indicator and update partial text
            update_streaming_text(event.content.parts[0].text)
        else:
            # Your logic to display complete text chunk
            display_text(event.content.parts[0].text)

    # Handle interruption
    if event.interrupted:
        # Your logic to stop audio playback and clear indicators
        stop_audio_playback()
        clear_streaming_indicators()

    # Handle turn completion
    if event.turn_complete:
        # Your logic to enable user input
        show_input_ready_state()
        enable_microphone()
```

--------------------------------

### Generate Get Operation Request (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Generates the request structure for retrieving an entity. This static utility method returns an ImmutableMap<String, Object> representing the request.

```java
public static com.google.common.collect.ImmutableMap<String,Object> getOperationRequest()
```

--------------------------------

### Setup LLM Agent with After-Callback and InMemoryRunner

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

Creates an LlmAgent configured with the after_agent_callback using builder pattern, then initializes an InMemoryRunner with the agent to manage session execution. The runner provides both the agent and session service for running multiple scenarios.

```java
public void defineAgentAndRunScenarios() {
  LlmAgent llmAgentWithAfterCb =
      LlmAgent.builder()
          .name(APP_NAME)
          .model(MODEL_NAME)
          .description("An LLM agent demonstrating after_agent_callback for output modification")
          .instruction("You are a simple agent. Just say 'Processing complete!'")
          .afterAgentCallback(this::modifyOutputAfterAgent)
          .build();

  InMemoryRunner runner = new InMemoryRunner(llmAgentWithAfterCb, APP_NAME);
```

--------------------------------

### Launch Local Server - Java with Tomcat

Source: https://google.github.io/adk-docs/runtime/api-server

Starts the Java ADK Web Server using embedded Tomcat on port 8080. Displays startup logs confirming successful server initialization and application readiness for local testing.

```bash
2025-05-13T23:32:08.972-06:00  INFO 37864 --- [ebServer.main()] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path '/'
2025-05-13T23:32:08.980-06:00  INFO 37864 --- [ebServer.main()] com.google.adk.web.AdkWebServer          : Started AdkWebServer in 1.15 seconds (process running for 2.877)
2025-05-13T23:32:08.981-06:00  INFO 37864 --- [ebServer.main()] com.google.adk.web.AdkWebServer          : AdkWebServer application started successfully.
```

--------------------------------

### Get Response Body from HttpApiResponse in Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/HttpApiResponse

Retrieves the HttpResponseBody from the HttpApiResponse. This method is specified in the parent ApiResponse class.

```java
public okhttp3.ResponseBody getResponseBody()
```

--------------------------------

### Google ADK Reimbursement Agent Simulation in Python

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This comprehensive Python example illustrates building an intelligent agent using Google's Agent Development Kit (ADK) to simulate an employee reimbursement process. It defines functions for asking approval and reimbursing, wraps them as `LongRunningFunctionTool`s, and configures an `Agent` with specific instructions and tools. The agent uses `InMemorySessionService` and `Runner` to manage the conversation flow, demonstrating conditional logic for approval based on reimbursement amount.

```python
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
from typing import Any
from google.adk.agents import Agent
from google.adk.events import Event
from google.adk.runners import Runner
from google.adk.tools import LongRunningFunctionTool
from google.adk.sessions import InMemorySessionService
from google.genai import types


# 1. Define the long running function
def ask_for_approval(
    purpose: str, amount: float
) -> dict[str, Any]:
    """Ask for approval for the reimbursement."""
    # create a ticket for the approval
    # Send a notification to the approver with the link of the ticket
    return {'status': 'pending', 'approver': 'Sean Zhou', 'purpose' : purpose, 'amount': amount, 'ticket-id': 'approval-ticket-1'}

def reimburse(purpose: str, amount: float) -> str:
    """Reimburse the amount of money to the employee."""
    # send the reimbrusement request to payment vendor
    return {'status': 'ok'}

# 2. Wrap the function with LongRunningFunctionTool
long_running_tool = LongRunningFunctionTool(func=ask_for_approval)


# 3. Use the tool in an Agent
file_processor_agent = Agent(
    # Use a model compatible with function calling
    model="gemini-2.0-flash",
    name='reimbursement_agent',
    instruction="""
      You are an agent whose job is to handle the reimbursement process for
      the employees. If the amount is less than $100, you will automatically
      approve the reimbursement.

      If the amount is greater than $100, you will
      ask for approval from the manager. If the manager approves, you will
      call reimburse() to reimburse the amount to the employee. If the manager
      rejects, you will inform the employee of the rejection.
    """,
    tools=[reimburse, long_running_tool]
)


APP_NAME = "human_in_the_loop"
USER_ID = "1234"
SESSION_ID = "session1234"

# Session and Runner
async def setup_session_and_runner():
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    runner = Runner(agent=file_processor_agent, app_name=APP_NAME, session_service=session_service)
    return session, runner
```

--------------------------------

### Initialize Gemini Model with Google ADK - Go

Source: https://google.github.io/adk-docs/agents/custom-agents

Code snippet showing initialization of a Gemini model client using Google ADK with application context, model name, and client configuration. This sets up the foundation for creating LLM agents that power the workflow.

```go
const (
    modelName = "gemini-2.0-flash"
    appName   = "story_app"
    userID    = "user_12345"
)

func main() {
    ctx := context.Background()
    model, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
```

--------------------------------

### Context Window Compression Trade-offs Analysis

Source: https://google.github.io/adk-docs/streaming/dev-guide/part4

Comparison of session characteristics with and without context window compression, including session duration, context quality, latency, memory usage, and implementation complexity.

```APIDOC
## Context Window Compression Trade-offs

### Comparison Matrix

| Aspect | With Compression | Without Compression | Best For |
|--------|-----------------|---------------------|----------|
| **Session Duration** | Unlimited | 15 min (audio), 2 min (video) Gemini, 10 min Vertex | Compression: Long sessions; No compression: Short sessions |
| **Context Quality** | Older context summarized | Full verbatim history | Compression: General conversation; No compression: Precision-critical |
| **Latency** | Compression overhead | No overhead | Compression: Async scenarios; No compression: Real-time |
| **Memory Usage** | Bounded | Grows with session | Compression: Long sessions; No compression: Short sessions |
| **Implementation** | Configure thresholds | No configuration | Compression: Production; No compression: Prototypes |

### When to Enable Compression
✅ **Enable compression when:**
- Sessions need to exceed platform duration limits (15/2/10 minutes)
- Extended conversations may hit token limits (128k for 2.5-flash)
- Customer support sessions that can last hours
- Educational tutoring with long interactions

### When to Disable Compression
❌ **Disable compression when:**
- All sessions complete within duration limits
- Precision recall of early conversation is critical
- Development/testing phase (full history aids debugging)
- Quality degradation from summarization is unacceptable

### Best Practice
Enable compression only when you need sessions longer than platform duration limits OR when conversations may exceed context window token limits.
```

--------------------------------

### Configure Java ADK with Gradle build.gradle

Source: https://google.github.io/adk-docs/get-started/installation

Add Google ADK dependencies to Gradle build configuration. Includes core ADK library and optional dev tools. Requires javac -parameters flag configuration.

```gradle
dependencies {
    implementation 'com.google.adk:google-adk:0.5.0'
    implementation 'com.google.adk:google-adk-dev:0.5.0'
}
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Lists all available version numbers for a specific artifact within a user session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions

### Description
Lists the available versions for a specific artifact.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.
- **userId** (String) - Required - The user ID.
- **sessionId** (String) - Required - The session ID.
- **artifactName** (String) - Required - The name of the artifact.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **versionNumbers** (List<Integer>) - A list of version numbers (integers).

#### Response Example
[
  1,
  2,
  5,
  10
]
```

--------------------------------

### GET apiVariant Accessor

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/BaseTool

Retrieves the Google API LLM variant to be used by this tool. This accessor provides access to the configured LLM variant for the tool.

```APIDOC
## Accessor: apiVariant

### Description
Gets the Google API LLM variant to use for this tool.

### Method
GET

### Signature
```typescript
get apiVariant(): GoogleLLMVariant
```

### Returns
- **GoogleLLMVariant** - The configured Google LLM variant for this tool

### Usage Example
```typescript
const variant = tool.apiVariant;
```
```

--------------------------------

### Run ADK Web Server with Gradle

Source: https://google.github.io/adk-docs/runtime/web-interface

Execute the registered ADK web server task using Gradle command-line interface.

```bash
gradle runADKWebServer
```

--------------------------------

### Implement Asynchronous Function Tool in Go

Source: https://google.github.io/adk-docs/tools-custom/function-tools

This Go example demonstrates how to define a long-running asynchronous function `createTicketAsync` and wrap it with the `functiontool.New` for use within an ADK agent. It includes defining input/output structs and integrating the tool into an `llmagent`.

```go
import (
    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/functiontool"
    "google.golang.org/genai"
)

// CreateTicketArgs defines the arguments for our long-running tool.
type CreateTicketArgs struct {
    Urgency string `json:"urgency" jsonschema:"The urgency level of the ticket."`
}

// CreateTicketResults defines the *initial* output of our long-running tool.
type CreateTicketResults struct {
    Status   string `json:"status"`
    TicketId string `json:"ticket_id"`
}

// createTicketAsync simulates the *initiation* of a long-running ticket creation task.
func createTicketAsync(ctx tool.Context, args CreateTicketArgs) (CreateTicketResults, error) {
    log.Printf("TOOL_EXEC: 'create_ticket_long_running' called with urgency: %s (Call ID: %s)\n", args.Urgency, ctx.FunctionCallID())

    // "Generate" a ticket ID and return it in the initial response.
    ticketID := "TICKET-ABC-123"
    log.Printf("ACTION: Generated Ticket ID: %s for Call ID: %s\n", ticketID, ctx.FunctionCallID())

    // In a real application, you would save the association between the
    // FunctionCallID and the ticketID to handle the async response later.
    return CreateTicketResults{
        Status:   "started",
        TicketId: ticketID,
    }, nil
}

func createTicketAgent(ctx context.Context) (agent.Agent, error) {
    ticketTool, err := functiontool.New(
        functiontool.Config{
            Name:        "create_ticket_long_running",
            Description: "Creates a new support ticket with a specified urgency level.",
        },
        createTicketAsync,
    )
    if err != nil {
        return nil, fmt.Errorf("failed to create long running tool: %w", err)
    }

    model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{})
    if err != nil {
        return nil, fmt.Errorf("failed to create model: %v", err)
    }

    return llmagent.New(llmagent.Config{
        Name:        "ticket_agent",
        Model:       model,
        Instruction: "You are a helpful assistant for creating support tickets. Provide the status of the ticket at each interaction.",
        Tools:       []tool.Tool{ticketTool},
    })
}
```

--------------------------------

### Create Session and Runner for ADK Agent - Python

Source: https://google.github.io/adk-docs/tools/google-cloud/pubsub

Initializes an in-memory session service and creates a Runner to execute the agent. This setup enables the agent to maintain session state and process user queries through the Pub/Sub toolset.

```python
# Session and Runner
session_service = InMemorySessionService()
session = asyncio.run(
    session_service.create_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID
    )
)
runner = Runner(
    agent=pubsub_agent, app_name=APP_NAME, session_service=session_service
)
```

--------------------------------

### GET /artifacts/versions - List All Versions

Source: https://google.github.io/adk-docs/artifacts

Retrieve a list of all available version numbers for a specific artifact filename. Useful for version history tracking and management.

```APIDOC
## GET /artifacts/versions - List All Versions

### Description
Lists all available version numbers for a specific artifact. This method is called on the artifact service to discover the complete version history.

### Method
GET

### Endpoint
/artifacts/versions

### Parameters
#### Query Parameters
- **filename** (string) - Required - The filename identifier to list versions for
- **scope** (string) - Optional - Either "session" or "user" to specify the namespace

### Request Example
```
GET /artifacts/versions?filename=monthly_report.pdf
GET /artifacts/versions?filename=user:settings.json&scope=user
```

### Response
#### Success Response (200)
- **filename** (string) - The filename of the artifact
- **versions** (array of integers) - List of all available version numbers

#### Response Example
```json
{
  "filename": "monthly_report.pdf",
  "versions": [0, 1, 2, 3]
}
```
```

--------------------------------

### ADK CLI Start API Server for Agents

Source: https://google.github.io/adk-docs/api-reference/cli/cli

Initiates a FastAPI server to host agents, allowing external interaction. The command requires specifying a directory containing agent definitions (`AGENTS_DIR`) and provides extensive options for server configuration, logging, and integration with various services like session management and artifact storage.

```bash
adk api_server [OPTIONS] [AGENTS_DIR]
```

```bash
adk api_server –session_service_uri=[uri] –port=[port] path/to/agents_dir
```

--------------------------------

### Get FunctionDeclaration - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/IntegrationConnectorTool

Retrieves the FunctionDeclaration representation of the IntegrationConnectorTool. This method is inherited from the BaseTool class and overrides the superclass implementation.

```java
public Optional<com.google.genai.types.FunctionDeclaration> declaration()
Gets the FunctionDeclaration representation of this tool.
```

--------------------------------

### Initialize Go ADK LLM Agents for Code Generation Pipeline

Source: https://google.github.io/adk-docs/agents/workflow-agents/sequential-agents

This Go snippet initializes `LlmAgent` instances, including `CodeWriterAgent` and `CodeReviewerAgent`, to form part of a code generation pipeline. It demonstrates setting up each agent with a specified model, name, detailed instructions for generating or reviewing Go code, a description, and an `OutputKey` for state management. The snippet also includes error handling for the creation of both the language model and the agents themselves.

```go
    model, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        return fmt.Errorf("failed to create model: %v", err)
    }

    codeWriterAgent, err := llmagent.New(llmagent.Config{
        Name:        "CodeWriterAgent",
        Model:       model,
        Description: "Writes initial Go code based on a specification.",
        Instruction: `You are a Go Code Generator.\nBased *only* on the user's request, write Go code that fulfills the requirement.\nOutput *only* the complete Go code block, enclosed in triple backticks ('''go ... ''').\nDo not add any other text before or after the code block.`,
        OutputKey: "generated_code",
    })
    if err != nil {
        return fmt.Errorf("failed to create code writer agent: %v", err)
    }

    codeReviewerAgent, err := llmagent.New(llmagent.Config{
        Name:        "CodeReviewerAgent",
        Model:       model,
        Description: "Reviews code and provides feedback.",
        Instruction: `You are an expert Go Code Reviewer.\nYour task is to provide constructive feedback on the provided code.\n\n**Code to Review:**\n'''go\n{generated_code}\n'''\n\n**Review Criteria:**\n1.  **Correctness:** Does the code work as intended? Are there logic errors?`
    })
```

--------------------------------

### Create Remote Prime Agent in Go using A2A

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming-go

This Go function `newPrimeAgent` creates an instance of a remote agent designed to check if numbers are prime. It uses `remoteagent.NewA2A` and requires configuration details such as `Name`, `Description`, and the `AgentCardSource` URL, which specifies the endpoint for the remote agent.

```go
func newPrimeAgent() (agent.Agent, error) {
    remoteAgent, err := remoteagent.NewA2A(remoteagent.A2AConfig{
        Name:            "prime_agent",
        Description:     "Agent that handles checking if numbers are prime.",
        AgentCardSource: "http://localhost:8001",
    })
    if err != nil {
        return nil, fmt.Errorf("failed to create remote prime agent: %w", err)
    }
    return remoteAgent, nil
}
```

--------------------------------

### Get User ID (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Retrieves the identifier of the user associated with this session. The user ID is returned as a string.

```java
public String userId()
```

--------------------------------

### Stock Price Agent Class Setup in Java

Source: https://google.github.io/adk-docs/tools-custom/function-tools

Defines the basic structure of a stock price agent application using the Google ADK framework. It includes necessary imports for LLM agents, event handling, session management, and tool definitions. The class initializes application and user identifiers for agent session tracking.

```Java
import com.google.adk.agents.LlmAgent;
import com.google.adk.events.Event;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.adk.tools.Annotations.Schema;
import com.google.adk.tools.FunctionTool;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;
import java.util.HashMap;
import java.util.Map;

public class StockPriceAgent {
    private static final String APP_NAME = "stock_agent";
    private static final String USER_ID = "user1234";
}
```

--------------------------------

### Listing Artifacts (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/ToolContext

Provides an example of how to list all attached artifact filenames within the current session using the ToolContext. Returns an RxJava3 Single emitting a list of strings.

```java
io.reactivex.rxjava3.core.Single<List<String>> artifacts = toolContext.listArtifacts();

artifacts.subscribe(filenames -> {
    // Process the list of filenames
});
```

--------------------------------

### Get LLM Instance

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/models/LlmRegistry

Retrieves an LLM instance for a given model name, using a cached or newly created instance.

```APIDOC
## GET /getLlm

### Description
Returns an LLM instance for the given model name. It uses a cached instance if available, otherwise creates a new one using the registered factory.

### Method
GET

### Endpoint
/getLlm

### Parameters
#### Query Parameters
- **modelName** (String) - Required - The name of the LLM model to retrieve.

### Request Example
```
GET /getLlm?modelName=some_model_name
```

### Response
#### Success Response (200)
- **llmInstance** (BaseLlm) - The requested LLM instance.

#### Response Example
```json
{
  "llmInstance": {
    "modelName": "some_model_name",
    "version": "1.0"
    // ... other LLM properties
  }
}
```

#### Error Response (400)
- **error** (String) - "IllegalArgumentException: No factory matches the model name."
```

--------------------------------

### Configure and Create ADK LLM Agent with Tools (Python)

Source: https://google.github.io/adk-docs/tools/authentication

This Python snippet configures and instantiates an LlmAgent for the ADK. It sets the agent's model, name, and instructions, and integrates a collection of tools (like those from an OpenAPI Toolset). This agent is now equipped to interact with systems, leveraging the configured authentication for protected tools.

```python
root_agent = LlmAgent(
    model='gemini-2.0-flash',
    name='enterprise_assistant',
    instruction='Help user integrate with multiple enterprise systems, including retrieving user information which may require authentication.',
    tools=userinfo_toolset.get_tools(),
)
```

--------------------------------

### Create and Activate Python Virtual Environment

Source: https://google.github.io/adk-docs/get-started/quickstart

Sets up an isolated Python virtual environment for the ADK project. Provides platform-specific activation commands for macOS/Linux and Windows (CMD and PowerShell). Required before installing dependencies to avoid conflicts with system packages.

```bash
# Create
python -m venv .venv
# Activate (each new terminal)
# macOS/Linux: source .venv/bin/activate
# Windows CMD: .venv\Scripts\activate.bat
# Windows PowerShell: .venv\Scripts\Activate.ps1
```

--------------------------------

### Create ADK Session and Run Agent - Python

Source: https://google.github.io/adk-docs/plugins

Demonstrates creating a session with the ADK runner and executing an async agent loop to process events. This code creates a user session, sends a message with user content, and iterates through response events from the agent.

```python
session = await runner.session_service.create_session(
    user_id='user',
    app_name='test_app_with_plugin',
)

async for event in runner.run_async(
    user_id='user',
    session_id=session.id,
    new_message=types.Content(
        role='user', parts=[types.Part.from_text(text=prompt)]
    )
):
    print(f'** Got event from {event.author}')

if __name__ == "__main__":
    asyncio.run(main())
```

--------------------------------

### LiveRequest: Get Blob of the Request

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/LiveRequest

Retrieves the blob associated with the LiveRequest. If a blob is set, it will be sent to the model in real-time mode.

```java
public abstract Optional<com.google.genai.types.Blob> blob()

```

--------------------------------

### Initialize ADK Services and Create Session

Source: https://google.github.io/adk-docs/tools-custom/authentication

Sets up in-memory session and artifact services for conversation state management and temporary artifact storage. Creates a new user session with application and user identifiers. These services are suitable for demos and testing but should be replaced with persistent storage in production environments.

```python
session_service = InMemorySessionService()
artifacts_service = InMemoryArtifactService()

session = session_service.create_session(
    state={},
    app_name='my_app',
    user_id='user'
)
```

--------------------------------

### beforeRunCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/BasePlugin

Callback executed before the ADK runner runs. This is the first callback to be called in the lifecycle, ideal for global setup or initialization tasks.

```APIDOC
## FUNCTION beforeRunCallback

### Description
Callback executed before the ADK runner runs.
This is the first callback to be called in the lifecycle, ideal for global setup or initialization tasks.

### Method
FUNCTION

### Endpoint
beforeRunCallback

### Parameters
#### Request Body
- **invocationContext** ({ invocationContext: InvocationContext }) - Required - The context for the entire invocation, containing session information, the root agent, etc.

### Request Example
{
  "invocationContext": {
    "invocationContext": "InvocationContextInstance"
  }
}

### Response
#### Success Response (200)
- **Promise<Content | undefined>** - An optional `Event` to be returned to the ADK. Returning a value to halt execution of the runner and ends the runner with that event. Return `undefined` to proceed normally.

#### Response Example
"EventObject"

```

--------------------------------

### LiveRequest: Get Content of the Request

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/LiveRequest

Retrieves the content associated with the LiveRequest. If content is set, it will be sent to the model in a turn-by-turn mode.

```java
public abstract Optional<com.google.genai.types.Content> content()

```

--------------------------------

### Create Empty .env Configuration File

Source: https://google.github.io/adk-docs/get-started/quickstart

Creates an empty .env file for storing environment variables and API credentials. Platform-specific commands for creating the file in multi_tool_agent directory. Will be populated with model configuration in subsequent setup steps.

```bash
touch multi_tool_agent/.env
```

```bash
type nul > multi_tool_agent\.env
```

--------------------------------

### Get State from CallbackContext

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/CallbackContext

Returns the delta-aware state of the current callback. This method overrides the state retrieval from the ReadonlyContext superclass.

```java
public State state()
```

--------------------------------

### Go: Configure LLM Agent with Before-Model Guardrail Callback

Source: https://google.github.io/adk-docs/callbacks

Demonstrates how to instantiate a Gemini model, create an LLM agent with the guardrail callback registered in BeforeModelCallbacks, and set up a runner with an in-memory session service. This setup enables request inspection before LLM processing.

```Go
func runGuardrailExample() {
    const (
        appName = "GuardrailApp"
        userID  = "test_user_456"
    )
    ctx := context.Background()
    geminiModel, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("Failed to create model: %v", err)
    }

    agentCfg := llmagent.Config{
        Name:                 "ChatAgent",
        Model:                geminiModel,
        BeforeModelCallbacks: []llmagent.BeforeModelCallback{onBeforeModelGuardrail},
    }
    chatAgent, err := llmagent.New(agentCfg)
    if err != nil {
        log.Fatalf("Failed to create agent: %v", err)
    }

    sessionService := session.InMemoryService()
    r, err := runner.New(runner.Config{
        AppName:        appName,
        Agent:          chatAgent,
        SessionService: sessionService,
    })
    if err != nil {
        log.Fatalf("Failed to create runner: %v", err)
    }
}
```

--------------------------------

### GET /list-apps

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Lists all available applications configured in the system. Currently returns only the configured root agent's name. This endpoint provides a simple way to discover what applications are available through the API.

```APIDOC
## GET /list-apps

### Description
Lists available applications. Currently returns only the configured root agent's name.

### Method
GET

### Endpoint
/list-apps

### Parameters
None

### Response
#### Success Response (200)
- **response** (List<String>) - A list containing the root agent's name.

#### Response Example
[
  "root-agent-name"
]
```

--------------------------------

### Inject ADK Session State into LlmAgent Instructions using Templating (Python)

Source: https://google.github.io/adk-docs/sessions/state

This Python example shows how to create an LlmAgent and dynamically inject values from the session.state into its instruction string. By enclosing a state key in curly braces ({key}), the framework automatically replaces it with the corresponding value from session.state before passing the instruction to the LLM, enabling context-aware instructions.

```Python
from google.adk.agents import LlmAgent

story_generator = LlmAgent(
    name="StoryGenerator",
    model="gemini-2.0-flash",
    instruction="""Write a short story about a cat, focusing on the theme: {topic}."""
)

# Assuming session.state['topic'] is set to "friendship", the LLM
# will receive the following instruction:
```

--------------------------------

### GET _getDeclaration

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LongRunningFunctionTool

Retrieves the function declaration schema for this tool. This method provides the schema definition that describes the tool's interface and parameters for LLM integration.

```APIDOC
## Method: _getDeclaration

### Description
Provides a schema for the function in the form of a FunctionDeclaration object.

### Signature
```typescript
_getDeclaration(): FunctionDeclaration
```

### Parameters
None

### Returns
- **FunctionDeclaration** - The function declaration schema containing metadata and parameter definitions

### Response Example
```typescript
{
  name: "toolName",
  description: "Tool description",
  parameters: {
    type: "object",
    properties: {
      param1: { type: "string" },
      param2: { type: "number" }
    }
  }
}
```

### Use Cases
- Generating OpenAPI/schema documentation
- Providing LLM with tool interface information
- Validating tool parameters
```

--------------------------------

### Initialize In-Memory Runner and Create Session in TypeScript

Source: https://google.github.io/adk-docs/tools-custom/function-tools

Creates an InMemoryRunner instance with the main agent and initializes a session with user and session identifiers. This setup is required before executing agent operations.

```typescript
const appName = 'agent-as-a-tool-app';
const runner = new InMemoryRunner({agent: mainAgent, appName});

await runner.sessionService.createSession({
  appName,
  userId: 'user1',
  sessionId: 'session1',
});
```

--------------------------------

### Navigate to Agent Parent Directory

Source: https://google.github.io/adk-docs/get-started/quickstart

Change directory to the parent folder containing your agent project. This is required before launching dev UI or running ADK commands. The example shows the project structure with agent files.

```bash
cd ..
```

--------------------------------

### Create RemoteA2aAgent Instance in Python

Source: https://google.github.io/adk-docs/a2a/quickstart-consuming

Demonstrates how to instantiate a RemoteA2aAgent by providing the agent name, description, and the URL path to the remote agent's card. The AGENT_CARD_WELL_KNOWN_PATH constant appends the standard path for accessing agent cards. This instance can then be used as a sub-agent in a parent agent.

```python
from google.adk.agents.remote_a2a_agent import AGENT_CARD_WELL_KNOWN_PATH
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent

prime_agent = RemoteA2aAgent(
    name="prime_agent",
    description="Agent that handles checking if numbers are prime.",
    agent_card=(
        f"http://localhost:8001/a2a/check_prime_agent{AGENT_CARD_WELL_KNOWN_PATH}"
    ),
)
```

--------------------------------

### GET /adk/agent/apps/{appName}/users/{userId}/sessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/class-use/Session

Lists all non-evaluation sessions for a given application and user.

```APIDOC
## GET /adk/agent/apps/{appName}/users/{userId}/sessions

### Description
Lists all non-evaluation sessions for a given application and user.

### Method
GET

### Endpoint
/adk/agent/apps/{appName}/users/{userId}/sessions

### Parameters
#### Path Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The ID of the user.

### Request Example
(No request body for GET)

### Response
#### Success Response (200)
- **sessions** (List<Session>) - A list of session objects.
  - **id** (String) - The unique ID of the session.
  - **appName** (String) - The name of the application associated with the session.
  - **userId** (String) - The ID of the user associated with the session.
  - **state** (Map<String,Object>) - The current state of the session.

#### Response Example
[
  {
    "id": "session1",
    "appName": "myApp",
    "userId": "user123",
    "state": {}
  },
  {
    "id": "session2",
    "appName": "myApp",
    "userId": "user123",
    "state": {
      "lastActivity": "2023-10-27T10:00:00Z"
    }
  }
]
```

--------------------------------

### Run Agent via Terminal - Python

Source: https://google.github.io/adk-docs/get-started/quickstart

Execute the agent from the terminal using adk run command. This starts an interactive chat session with the agent. Use Cmd/Ctrl+C to exit.

```bash
adk run multi_tool_agent
```

--------------------------------

### Get Action Schema (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Retrieves the input and output JSON schema for a given action. The action name is required, and the method can throw IOException or InterruptedException.

```java
public ConnectionsClient.ActionSchema getActionSchema(String action) throws IOException, InterruptedException
```

--------------------------------

### GET /sessions - List Sessions

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/BaseSessionService

Lists all sessions associated with a specific application and user. Returns session metadata including ID and creation time, but not the full event list or state to optimize performance.

```APIDOC
## GET /sessions

### Description
Lists sessions associated with a specific application and user. Returns session metadata including ID and creation time, but not the full event list or state to optimize performance.

### Method
GET

### Endpoint
/sessions

### Parameters
#### Query Parameters
- **appName** (String) - Required - The name of the application
- **userId** (String) - Required - The identifier of the user whose sessions are to be listed

### Response
#### Success Response (200)
- **ListSessionsResponse** (ListSessionsResponse) - A response containing a list of matching sessions with metadata only

#### Response Example
{
  "sessions": [
    {
      "sessionId": "session-abc-123",
      "appName": "my-app",
      "userId": "user123",
      "createdTime": "2024-01-15T10:30:00Z"
    },
    {
      "sessionId": "session-def-456",
      "appName": "my-app",
      "userId": "user123",
      "createdTime": "2024-01-14T09:15:00Z"
    }
  ]
}

### Error Handling
- **SessionException** - if listing fails
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions/{versionId}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Retrieves a specific version of an artifact from a user session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions/{versionId}

### Description
Loads a specific version of an artifact.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}/versions/{versionId}

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.
- **userId** (String) - Required - The user ID.
- **sessionId** (String) - Required - The session ID.
- **artifactName** (String) - Required - The name of the artifact.
- **versionId** (int) - Required - The specific version number.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **artifactContent** (com.google.genai.types.Part) - The artifact content as a Part object.

#### Response Example
{
  "content": "binary_or_text_data_here",
  "mimeType": "application/json"
}

### Error Handling
- **404 Not Found**: If the artifact version is not found.
```

--------------------------------

### Initialize LlmAgent with Gemini Flash Model

Source: https://google.github.io/adk-docs/agents/models/google-gemini

Create a basic LlmAgent instance using the Gemini 2.5 Flash model across multiple programming languages. This demonstrates the fundamental setup for instantiating an agent with model identifier, name, and instruction parameters.

```python
from google.adk.agents import LlmAgent

# --- Example using a stable Gemini Flash model ---
agent_gemini_flash = LlmAgent(
    # Use the latest stable Flash model identifier
    model="gemini-2.5-flash",
    name="gemini_flash_agent",
    instruction="You are a fast and helpful Gemini assistant.",
    # ... other agent parameters
)
```

```typescript
import {LlmAgent} from '@google/adk';

// --- Example #2: using a powerful Gemini Pro model with API Key in model ---
export const rootAgent = new LlmAgent({
  name: 'hello_time_agent',
  model: 'gemini-2.5-flash',
  description: 'Gemini flash agent',
  instruction: `You are a fast and helpful Gemini assistant.`,
});
```

```go
import (
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/genai"
)

// --- Example using a stable Gemini Flash model ---
modelFlash, err := gemini.NewModel(ctx, "gemini-2.0-flash", &genai.ClientConfig{})
if err != nil {
    log.Fatalf("failed to create model: %v", err)
}
agentGeminiFlash, err := llmagent.New(llmagent.Config{
    // Use the latest stable Flash model identifier
    Model:       modelFlash,
    Name:        "gemini_flash_agent",
    Instruction: "You are a fast and helpful Gemini assistant.",
    // ... other agent parameters
})
if err != nil {
    log.Fatalf("failed to create agent: %v", err)
}
```

```java
// --- Example #1: using a stable Gemini Flash model with ENV variables---
LlmAgent agentGeminiFlash =
    LlmAgent.builder()
        // Use the latest stable Flash model identifier
        .model("gemini-2.5-flash") // Set ENV variables to use this model
        .name("gemini_flash_agent")
        .instruction("You are a fast and helpful Gemini assistant.")
        // ... other agent parameters
        .build();
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Loads the latest or a specific version of an artifact associated with a user session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}

### Description
Loads the latest or a specific version of an artifact associated with a session.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{artifactName}

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.
- **userId** (String) - Required - The user ID.
- **sessionId** (String) - Required - The session ID.
- **artifactName** (String) - Required - The name of the artifact.

#### Query Parameters
- **version** (Integer) - Optional - Specific version number. If null, loads the latest.

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **artifactContent** (com.google.genai.types.Part) - The artifact content as a Part object.

#### Response Example
{
  "content": "binary_or_text_data_here",
  "mimeType": "application/json"
}

### Error Handling
- **404 Not Found**: If the artifact is not found.
```

--------------------------------

### Get Last Update Time (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Retrieves the last modification time of the session. The time is returned as an Instant object.

```java
public Instant lastUpdateTime()
```

--------------------------------

### Deploy ADK Agent with Custom Cloud Run Service Options

Source: https://google.github.io/adk-docs/api-reference/cli/cli

This example illustrates deploying an ADK agent to Google Cloud Run while passing additional `gcloud run deploy` arguments, such as `--no-allow-unauthenticated` for public access and `--min-instances=2` for scaling. The double dash `--` acts as a separator, distinguishing `gcloud` specific flags from `adk` command arguments.

```bash
adk deploy cloud_run --project=[project] --region=[region] path/to/my_agent -- --no-allow-unauthenticated --min-instances=2
```

--------------------------------

### Get Session Events (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Retrieves a list of all events associated with the session. Each event in the list is an instance of the Event class.

```java
public List<Event> events()
```

--------------------------------

### Initialize and link main and support ADK agents

Source: https://google.github.io/adk-docs/tools-custom

This code initializes two ADK `Agent` objects: `main_agent` and `support_agent`. The `main_agent` is configured as the first point of contact, capable of answering general queries and using the `check_and_transfer` tool for urgent requests. The `support_agent` is a specialized agent for urgent issues. Crucially, the `support_agent` is added as a sub-agent to the `main_agent` to enable seamless transfers between them.

```python
main_agent = Agent(
    model='gemini-2.0-flash',
    name='main_agent',
    instruction="""You are the first point of contact for customer support of an analytics tool. Answer general queries. If the user indicates urgency, use the 'check_and_transfer' tool.""",
    tools=[check_and_transfer]
)

support_agent = Agent(
    model='gemini-2.0-flash',
    name='support_agent',
    instruction="""You are the dedicated support agent. Mentioned you are a support handler and please help the user with their urgent issue."""
)

main_agent.sub_agents = [support_agent]
```

--------------------------------

### GET /apps/{appName}/eval_results

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

This endpoint lists all evaluation results for a given application. It is currently a stub and returns an empty list.

```APIDOC
## GET /apps/{appName}/eval_results

### Description
Lists all evaluation results for an app. (STUB - Not Implemented)

### Method
GET

### Endpoint
/apps/{appName}/eval_results

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
{}

### Response
#### Success Response (200)
- **List<String>** (Array of String) - An empty list, as this endpoint is not implemented.

#### Response Example
[]
```

--------------------------------

### Get Tools from Toolset

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ApplicationIntegrationToolset

This method retrieves all available tools within the ApplicationIntegrationToolset, optionally filtered by a provided ReadonlyContext. It returns a Flowable emitting a list of BaseTool instances.

```java
public io.reactivex.rxjava3.core.Flowable<BaseTool> getTools(@Nullable ReadonlyContext readonlyContext)
```

--------------------------------

### Illustrate Typical Java Project Structure

Source: https://google.github.io/adk-docs/get-started/quickstart

This snippet illustrates a typical project folder structure for a Java application. It includes common elements like `pom.xml` (or `build.gradle`) for dependency management, source code directories under `src/main/java`, and a `test` directory, showing a common place for agents within the project.

```text
project_folder/
├── pom.xml (or build.gradle)
├── src/
├── └── main/
│       └── java/
│           └── agents/
│               └── multitool/
└── test/

```

--------------------------------

### Import Google ADK Libraries and Dependencies in Python

Source: https://google.github.io/adk-docs/tutorials/agent-team

Imports essential libraries for Google ADK agent framework including Agent, LiteLlm for multi-model support, session management, and utilities for handling warnings and logging. This setup prepares the environment for building AI agents.

```python
import os
import asyncio
from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types

import warnings
warnings.filterwarnings("ignore")

import logging
logging.basicConfig(level=logging.ERROR)

print("Libraries imported.")
```

--------------------------------

### Initialize Spanner Toolset with Credentials and Settings

Source: https://google.github.io/adk-docs/tools/google-cloud/spanner

Sets up SpannerToolset with application default credentials and read-only capability settings. Includes configuration for the Gemini model and agent constants. This is the foundational setup required before creating agents that interact with Spanner databases.

```Python
import asyncio
from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.google_tool import GoogleTool
from google.adk.tools.spanner import query_tool
from google.adk.tools.spanner.settings import SpannerToolSettings
from google.adk.tools.spanner.settings import Capabilities
from google.adk.tools.spanner.spanner_credentials import SpannerCredentialsConfig
from google.adk.tools.spanner.spanner_toolset import SpannerToolset
from google.genai import types
from google.adk.tools.tool_context import ToolContext
import google.auth
from google.auth.credentials import Credentials

AGENT_NAME = "spanner_agent"
APP_NAME = "spanner_app"
USER_ID = "user1234"
SESSION_ID = "1234"
GEMINI_MODEL = "gemini-2.5-flash"

tool_settings = SpannerToolSettings(capabilities=[Capabilities.DATA_READ])

application_default_credentials, _ = google.auth.default()
credentials_config = SpannerCredentialsConfig(
    credentials=application_default_credentials
)

spanner_toolset = SpannerToolset(
    credentials_config=credentials_config, spanner_tool_settings=tool_settings
)
```

--------------------------------

### Initialize Agent with Code Executor in Python

Source: https://google.github.io/adk-docs/agents/llm-agents

Set up an LlmAgent with built-in code execution capabilities, allowing the agent to write and execute Python code blocks. This example creates a calculator agent with specific instructions and uses asyncio for session creation.

```python
import asyncio
from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.code_executors import BuiltInCodeExecutor
from google.genai import types

AGENT_NAME = "calculator_agent"
APP_NAME = "calculator"
USER_ID = "user1234"
SESSION_ID = "session_code_exec_async"
GEMINI_MODEL = "gemini-2.0-flash"

# Agent Definition
code_agent = LlmAgent(
    name=AGENT_NAME,
    model=GEMINI_MODEL,
    code_executor=BuiltInCodeExecutor(),
    instruction="""You are a calculator agent.
    When given a mathematical expression, write and execute Python code to calculate the result.
    Return only the final numerical result as plain text, without markdown or code blocks.
    """,
    description="Executes Python code to perform calculations.",
)

# Session and Runner
session_service = InMemorySessionService()
session = asyncio.run(session_service.create_session(
    app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID
))
runner = Runner(agent=code_agent, app_name=APP_NAME,
                session_service=session_service)
```

--------------------------------

### GET /LoggingPlugin/name

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LoggingPlugin

Retrieves the readonly name of the LoggingPlugin instance. This name is assigned during construction and identifies the plugin instance.

```APIDOC
## GET /LoggingPlugin/name

### Description
Retrieves the readonly `name` property of the `LoggingPlugin` instance. This property is set during initialization and identifies the plugin instance within the system.

### Method
GET

### Endpoint
/LoggingPlugin/name

### Parameters
#### Path Parameters
(None)

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **name** (string) - The name of the plugin instance.

#### Response Example
{
  "name": "logging_plugin"
}
```

--------------------------------

### Initialize LLM Agent with Gemini Model and Stock Price Tool in Go

Source: https://google.github.io/adk-docs/tools/function-tools

Creates and configures an LlmAgent with the Gemini 2.5 Flash model and getStockPrice tool. Sets up the agent's name, instruction prompt, and description for handling stock price queries. Returns a configured agent.Agent ready for execution.

```go
func createStockAgent(ctx context.Context) (agent.Agent, error) {
    stockPriceTool, err := functiontool.New(
        functiontool.Config{
            Name:        "get_stock_price",
            Description: "Retrieves the current stock price for a given symbol.",
        },
        getStockPrice)
    if err != nil {
        return nil, err
    }

    model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("Failed to create model: %v", err)
    }

    return llmagent.New(llmagent.Config{
        Name:        "stock_agent",
        Model:       model,
        Instruction: "You are an agent who retrieves stock prices. If a ticker symbol is provided, fetch the current price. If only a company name is given, first perform a Google search to find the correct ticker symbol before retrieving the stock price. If the provided ticker symbol is invalid or data cannot be retrieved, inform the user that the stock price could not be found.",
        Description: "This agent specializes in retrieving real-time stock prices. Given a stock ticker symbol (e.g., AAPL, GOOG, MSFT) or the stock name, use the tools and reliable data sources to provide the most up-to-date price.",
        Tools: []tool.Tool{
            stockPriceTool,
        },
    })
}
```

--------------------------------

### Enable Speech Support with Audio and Text Modalities

Source: https://google.github.io/adk-docs/runtime/runconfig

Configures a comprehensive RunConfig with speech capabilities using the "Kore" voice in US English, dual response modalities (audio and text), artifact saving for debugging, SSE streaming, and a maximum of 1000 LLM calls. This setup enables agents to process and respond with both voice and text output simultaneously.

```python
from google.genai.adk import RunConfig, StreamingMode
from google.genai import types

config = RunConfig(
    speech_config=types.SpeechConfig(
        language_code="en-US",
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(
                voice_name="Kore"
            )
        ),
    ),
    response_modalities=["AUDIO", "TEXT"],
    save_input_blobs_as_artifacts=True,
    support_cfc=True,
    streaming_mode=StreamingMode.SSE,
    max_llm_calls=1000,
)
```

```typescript
import { RunConfig, StreamingMode } from '@google/adk';

const config: RunConfig = {
    speechConfig: {
        languageCode: "en-US",
        voiceConfig: {
            prebuiltVoiceConfig: {
                voiceName: "Kore"
            }
        },
    },
    responseModalities: [
      { modality: "AUDIO" },
      { modality: "TEXT" }
    ],
    saveInputBlobsAsArtifacts: true,
    supportCfc: true,
    streamingMode: StreamingMode.SSE,
    maxLlmCalls: 1000,
};
```

```java
import com.google.adk.agents.RunConfig;
import com.google.adk.agents.RunConfig.StreamingMode;
import com.google.common.collect.ImmutableList;
import com.google.genai.types.Content;
import com.google.genai.types.Modality;
import com.google.genai.types.Part;
import com.google.genai.types.PrebuiltVoiceConfig;
import com.google.genai.types.SpeechConfig;
import com.google.genai.types.VoiceConfig;

RunConfig runConfig =
    RunConfig.builder()
        .setStreamingMode(StreamingMode.SSE)
        .setMaxLlmCalls(1000)
        .setSaveInputBlobsAsArtifacts(true)
        .setResponseModalities(ImmutableList.of(new Modality("AUDIO"), new Modality("TEXT")))
        .setSpeechConfig(
            SpeechConfig.builder()
                .voiceConfig(
                    VoiceConfig.builder()
                        .prebuiltVoiceConfig(
                            PrebuiltVoiceConfig.builder().voiceName("Kore").build())
                        .build())
                .languageCode("en-US")
                .build())
        .build();
```

--------------------------------

### GET /apps/{appName}/eval_sets

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

This endpoint provides a way to retrieve a list of all evaluation sets associated with a specific application. It is currently a placeholder.

```APIDOC
## GET /apps/{appName}/eval_sets

### Description
Placeholder for listing evaluation sets.

### Method
GET

### Endpoint
/apps/{appName}/eval_sets

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
{}

### Response
#### Success Response (200)
- **List<String>** (Array of String) - A list of evaluation set IDs.

#### Response Example
[
  "evalSet1",
  "evalSet2"
]
```

--------------------------------

### GET /schema/{entity}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/class-use/ConnectionsClient.EntitySchemaAndOperations

This endpoint retrieves the JSON schema and available operations for a specified entity. It is typically used to understand the structure and capabilities of an entity within the system.

```APIDOC
## GET /schema/{entity}

### Description
This endpoint retrieves the JSON schema and available operations for a specified entity. It is typically used to understand the structure and capabilities of an entity within the system.

### Method
GET

### Endpoint
/schema/{entity}

### Parameters
#### Path Parameters
- **entity** (string) - Required - The name of the entity for which to retrieve schema and operations.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
N/A

### Response
#### Success Response (200)
- **schema** (object) - The JSON schema definition for the entity.
- **operations** (array of string) - A list of available operations (e.g., "CREATE", "READ", "UPDATE", "DELETE") for the entity.

#### Response Example
{
  "schema": {
    "type": "object",
    "properties": {
      "id": {
        "type": "string",
        "description": "Unique identifier for the entity"
      },
      "name": {
        "type": "string",
        "description": "Name of the entity"
      }
    },
    "required": ["id", "name"]
  },
  "operations": ["READ", "UPDATE"]
}
```

--------------------------------

### Convert Agent to A2A Compatible with to_a2a() Function

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Wraps an existing ADK agent using the to_a2a() function to make it A2A-compatible. This function automatically generates an agent card from the agent's skills and metadata, exposing the agent on a specified port via uvicorn.

```python
from google.adk.a2a.utils.agent_to_a2a import to_a2a

# Make your agent A2A-compatible
a2a_app = to_a2a(root_agent, port=8001)
```

--------------------------------

### Instantiate a Custom Toolset in Python

Source: https://google.github.io/adk-docs/tools-custom

This Python code demonstrates how to create an instance of the `SimpleMathToolset` class. It passes a custom prefix, 'calculator_', to the constructor, which will be used to name the tools within this specific toolset instance.

```python
math_toolset_instance = SimpleMathToolset(prefix="calculator_")
```

--------------------------------

### Check Remote Agent Status - Agent Card JSON Response

Source: https://google.github.io/adk-docs/a2a/quickstart-exposing

Verify that the remote agent is running by retrieving the auto-generated agent card from the specified endpoint. The agent card contains metadata including capabilities, skills, protocol version, and tool descriptions for the hello_world agent with dice rolling and prime number checking capabilities.

```json
{"capabilities":{},"defaultInputModes":["text/plain"],"defaultOutputModes":["text/plain"],"description":"hello world agent that can roll a dice of 8 sides and check prime numbers.","name":"hello_world_agent","protocolVersion":"0.2.6","skills":[{"description":"hello world agent that can roll a dice of 8 sides and check prime numbers. \n      I roll dice and answer questions about the outcome of the dice rolls.\n      I can roll dice of different sizes.\n      I can use multiple tools in parallel by calling functions in parallel(in one request and in one round).\n      It is ok to discuss previous dice roles, and comment on the dice rolls.\n      When I are asked to roll a die, I must call the roll_die tool with the number of sides. Be sure to pass in an integer. Do not pass in a string.\n      I should never roll a die on my own.\n      When checking prime numbers, call the check_prime tool with a list of integers. Be sure to pass in a list of integers. I should never pass in a string.\n      I should not check prime numbers before calling the tool.\n      When I are asked to roll a die and check prime numbers, I should always make the following two function calls:\n      1. I should first call the roll_die tool to get a roll. Wait for the function response before calling the check_prime tool.\n      2. After I get the function response from roll_die tool, I should call the check_prime tool with the roll_die result.\n        2.1 If user asks I to check primes based on previous rolls, make sure I include the previous rolls in the list.\n      3. When I respond, I must include the roll_die result from step 1.\n      I should always perform the previous 3 steps when asking for a roll and checking prime numbers.\n      I should not rely on the previous history on prime results.\n    ","id":"hello_world_agent","name":"model","tags":["llm"]},{"description":"Roll a die and return the rolled result.\n\nArgs:\n  sides: The integer number of sides the die has.\n  tool_context: the tool context\nReturns:\n  An integer of the result of rolling the die.","id":"hello_world_agent-roll_die","name":"roll_die","tags":["llm","tools"]},{"description":"Check if a given list of numbers are prime.\n\nArgs:\n  nums: The list of numbers to check.\n\nReturns:\n  A str indicating which number is prime.","id":"hello_world_agent-check_prime","name":"check_prime","tags":["llm","tools"]}],"supportsAuthenticatedExtendedCard":false,"url":"http://localhost:8001","version":"0.0.1"}
```

--------------------------------

### Client-side Real-time Audio Playback (JavaScript)

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

This comprehensive JavaScript implementation handles the reception, decoding, and playback of real-time PCM audio data streamed over a WebSocket. It integrates a WebSocket message handler for processing incoming audio, an AudioContext and AudioWorklet setup for low-latency playback, and a custom AudioWorklet processor utilizing a ring buffer to manage audio samples and ensure smooth output.

```javascript
// 1. WebSocket Message Handler
// Handle content events (text or audio)
if (adkEvent.content && adkEvent.content.parts) {
    const parts = adkEvent.content.parts;

    for (const part of parts) {
        // Handle inline data (audio)
        if (part.inlineData) {
            const mimeType = part.inlineData.mimeType;
            const data = part.inlineData.data;

            // Check if this is audio PCM data and the audio player is ready
            if (mimeType && mimeType.startsWith("audio/pcm") && audioPlayerNode) {
                // Decode base64 to ArrayBuffer and send to AudioWorklet for playback
                audioPlayerNode.port.postMessage(base64ToArray(data));
            }
        }
    }
}

// Decode base64 audio data to ArrayBuffer
function base64ToArray(base64) {
    // Convert base64url to standard base64 (RFC 4648 compliance)
    // base64url uses '-' and '_' instead of '+' and '/', which are URL-safe
    let standardBase64 = base64.replace(/-/g, '+').replace(/_/g, '/');

    // Add padding '=' characters if needed
    // Base64 strings must be multiples of 4 characters
    while (standardBase64.length % 4) {
        standardBase64 += '=';
    }

    // Decode base64 string to binary string using browser API
    const binaryString = window.atob(standardBase64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    // Convert each character code (0-255) to a byte
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    // Return the underlying ArrayBuffer (binary data)
    return bytes.buffer;
}
```

```javascript
// 2. Audio Player Setup
// Start audio player worklet
export async function startAudioPlayerWorklet() {
    // Create an AudioContext with 24kHz sample rate
    // This matches the Live API's output audio format (16-bit PCM @ 24kHz)
    // Note: Different from input rate (16kHz) - Live API outputs at higher quality
    const audioContext = new AudioContext({
        sampleRate: 24000
    });

    // Load the AudioWorklet module that will handle audio playback
    // AudioWorklet runs on audio rendering thread for smooth, low-latency playback
    const workletURL = new URL('./pcm-player-processor.js', import.meta.url);
    await audioContext.audioWorklet.addModule(workletURL);

    // Create an AudioWorkletNode using our custom PCM player processor
    // This node will receive audio data via postMessage and play it through speakers
    const audioPlayerNode = new AudioWorkletNode(audioContext, 'pcm-player-processor');

    // Connect the player node to the audio destination (speakers/headphones)
    // This establishes the audio graph: AudioWorklet → AudioContext.destination
    audioPlayerNode.connect(audioContext.destination);

    return [audioPlayerNode, audioContext];
}
```

```javascript
// 3. AudioWorklet Processor (Ring Buffer)
// AudioWorklet processor that buffers and plays PCM audio
class PCMPlayerProcessor extends AudioWorkletProcessor {
    constructor() {
        super();

        // Initialize ring buffer (24kHz x 180 seconds = ~4.3 million samples)
        // Ring buffer absorbs network jitter and ensures smooth playback
        this.bufferSize = 24000 * 180;
        this.buffer = new Float32Array(this.bufferSize);
        this.writeIndex = 0;  // Where we write new audio data
        this.readIndex = 0;   // Where we read for playback

        // Handle incoming messages from main thread
        this.port.onmessage = (event) => {
            // Reset buffer on interruption (e.g., user interrupts model response)
            if (event.data.command === 'endOfAudio') {
                this.readIndex = this.writeIndex; // Clear the buffer by jumping read to write position
                return;
            }

            // Decode Int16 array from incoming ArrayBuffer
            // The Live API sends 16-bit PCM audio data
            const int16Samples = new Int16Array(event.data);

            // Add audio data to ring buffer for playback
            this._enqueue(int16Samples);
        };
    }

    // Push incoming Int16 data into ring buffer
    _enqueue(int16Samples) {
        for (let i = 0; i < int16Samples.length; i++) {
            // Convert 16-bit integer to float in [-1.0, 1.0] required by Web Audio API

```

--------------------------------

### Get Entity Schema and Operations (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Retrieves the JSON schema and available operations for a specified entity. This method requires the entity name and can throw IOException or InterruptedException.

```java
public ConnectionsClient.EntitySchemaAndOperations getEntitySchemaAndOperations(String entity) throws IOException, InterruptedException
```

--------------------------------

### Runner Constructor and Methods

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/runner/Runner

Details on how to instantiate the Runner class and use its methods for agent execution.

```APIDOC
## Runner API

### Description
The `Runner` class is the main class for the GenAI Agents runner. It provides methods to execute agents in various modes.

### Constructor

#### `Runner(BaseAgent agent, String appName, BaseArtifactService artifactService, BaseSessionService sessionService)`

*   **Description**: Creates a new `Runner` instance.
*   **Parameters**:
    *   `agent` (BaseAgent) - Required - The base agent to run.
    *   `appName` (String) - Required - The name of the application.
    *   `artifactService` (BaseArtifactService) - Required - The artifact service.
    *   `sessionService` (BaseSessionService) - Required - The session service.

### Methods

#### `agent()`

*   **Description**: Returns the `BaseAgent` associated with this runner.
*   **Method**: GET
*   **Endpoint**: N/A (Instance method)

#### `appName()`

*   **Description**: Returns the application name.
*   **Method**: GET
*   **Endpoint**: N/A (Instance method)

#### `artifactService()`

*   **Description**: Returns the `BaseArtifactService`.
*   **Method**: GET
*   **Endpoint**: N/A (Instance method)

#### `runAsync(Session session, com.google.genai.types.Content newMessage, RunConfig runConfig)`

*   **Description**: Runs the agent in the standard mode using a provided Session object.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `session` (Session) - Required - The session to use for running the agent.
    *   `newMessage` (com.google.genai.types.Content) - Required - The new message to process.
    *   `runConfig` (RunConfig) - Required - The configuration for the run.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `runAsync(String userId, String sessionId, com.google.genai.types.Content newMessage)`

*   **Description**: Asynchronously runs the agent for a given user and session, processing a new message and using a default `RunConfig`.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `userId` (String) - Required - The ID of the user.
    *   `sessionId` (String) - Required - The ID of the session.
    *   `newMessage` (com.google.genai.types.Content) - Required - The new message to process.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `runAsync(String userId, String sessionId, com.google.genai.types.Content newMessage, RunConfig runConfig)`

*   **Description**: Runs the agent in the standard mode.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `userId` (String) - Required - The ID of the user.
    *   `sessionId` (String) - Required - The ID of the session.
    *   `newMessage` (com.google.genai.types.Content) - Required - The new message to process.
    *   `runConfig` (RunConfig) - Required - The configuration for the run.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `runLive(Session session, LiveRequestQueue liveRequestQueue, RunConfig runConfig)`

*   **Description**: Runs the agent in live mode, appending generated events to the session.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `session` (Session) - Required - The session to use for live mode.
    *   `liveRequestQueue` (LiveRequestQueue) - Required - The queue for live requests.
    *   `runConfig` (RunConfig) - Required - The configuration for the run.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `runLive(String userId, String sessionId, LiveRequestQueue liveRequestQueue, RunConfig runConfig)`

*   **Description**: Retrieves the session and runs the agent in live mode.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `userId` (String) - Required - The ID of the user.
    *   `sessionId` (String) - Required - The ID of the session.
    *   `liveRequestQueue` (LiveRequestQueue) - Required - The queue for live requests.
    *   `runConfig` (RunConfig) - Required - The configuration for the run.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `runWithSessionId(String sessionId, com.google.genai.types.Content newMessage, RunConfig runConfig)`

*   **Description**: Runs the agent asynchronously with a default user ID.
*   **Method**: POST
*   **Endpoint**: N/A (Instance method)
*   **Parameters**:
    *   `sessionId` (String) - Required - The ID of the session.
    *   `newMessage` (com.google.genai.types.Content) - Required - The new message to process.
    *   `runConfig` (RunConfig) - Required - The configuration for the run.
*   **Response**:
    *   Success Response (200): `io.reactivex.rxjava3.core.Flowable<Event>` - A stream of events generated by the agent.

#### `sessionService()`

*   **Description**: Returns the `BaseSessionService`.
*   **Method**: GET
*   **Endpoint**: N/A (Instance method)

```

--------------------------------

### Get Connection Details (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Retrieves service details for a given connection using the ConnectionsClient. This method returns a ConnectionDetails object and may throw IOException or InterruptedException.

```java
public ConnectionsClient.ConnectionDetails getConnectionDetails() throws IOException, InterruptedException
```

--------------------------------

### Get FunctionDeclaration - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/LoadArtifactsTool

Retrieves the FunctionDeclaration representation of the LoadArtifactsTool. This method is overridden from the BaseTool class and provides metadata about the tool's capabilities to the LLM.

```java
public Optional<com.google.genai.types.FunctionDeclaration> declaration()
```

--------------------------------

### CALL runLive

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/BaseAgent

This method serves as the primary entry point for executing an agent through a live video or audio-based conversation. It facilitates the interaction and event generation during the agent's runtime.

```APIDOC
## CALL /runLive

### Description
Entry method to run an agent via video/audio-based conversation.

### Method
CALL

### Endpoint
runLive

### Parameters
#### Request Body
- **parentContext** (InvocationContext) - Required - The invocation context of the parent agent.

### Request Example
{
  "parentContext": {
    "sessionId": "string",
    "metadata": {}
  }
}

### Response
#### Success Response (Success)
- **yields** (Event) - An AsyncGenerator that yields event objects generated by the agent during the live conversation.

#### Response Example
{
  "event": {
    "type": "AGENT_EVENT_TYPE",
    "data": {}
  }
}
```

--------------------------------

### Configure environment for Google AI Studio

Source: https://google.github.io/adk-docs/get-started/streaming/quickstart-streaming

Sets up environment variables in .env file for using Google AI Studio with the Gemini Live API. Requires a valid API key from Google AI Studio. The GOOGLE_GENAI_USE_VERTEXAI flag is set to FALSE to use Google AI Studio instead of Vertex AI.

```bash
GOOGLE_GENAI_USE_VERTEXAI=FALSE
GOOGLE_API_KEY=PASTE_YOUR_ACTUAL_API_KEY_HERE
```

--------------------------------

### Get Session ID (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Retrieves the unique identifier for the session. This method returns a string representing the session's ID.

```java
public String id()
```

--------------------------------

### List Available Applications in Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Provides an API endpoint to list available applications. This method currently returns a list containing only the name of the configured root agent. It is exposed as a GET request at the `/list-apps` path.

```java
@GetMapping("/list-apps") public List<String> listApps()
```

--------------------------------

### Set Up Session Service and Runner for Agent Execution

Source: https://google.github.io/adk-docs/tools/gemini-api/google-search

Initializes an in-memory session service and creates a Runner instance to manage agent execution. The Runner coordinates session management and asynchronous task execution with the configured agent. This setup allows for stateful agent interactions within a session context.

```java
InMemorySessionService sessionService = new InMemorySessionService();
Runner runner = new Runner(rootAgent, APP_NAME, null, sessionService);

callAgent(runner, "what's the latest ai news?");
```

--------------------------------

### GET /sessions/{appName}/{userId}/{sessionId}/events

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/BaseSessionService

Retrieves a list of events associated with a specific session. This endpoint supports pagination to handle large event lists.

```APIDOC
## GET /sessions/{appName}/{userId}/{sessionId}/events

### Description
Lists the events within a specific session. Supports pagination via the response object.

### Method
GET

### Endpoint
/sessions/{appName}/{userId}/{sessionId}/events

### Parameters
#### Path Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The identifier of the user.
- **sessionId** (String) - Required - The unique identifier of the session whose events are to be listed.

#### Query Parameters
None

#### Request Body
None

### Request Example
None

### Response
#### Success Response (200 OK)
- **events** (Array<Object>) - A list of event objects.
- **nextPageToken** (String) - An optional token to retrieve the next page of events. Present if more events are available.

#### Error Responses
- **404 Not Found** (SessionNotFoundException) - If the session doesn't exist.
- **500 Internal Server Error** (SessionException) - For other listing errors.

#### Response Example
```json
{
  "events": [
    {
      "eventId": "event-123",
      "timestamp": "2023-10-27T10:00:00Z",
      "type": "user_login",
      "data": {
        "username": "testuser"
      }
    },
    {
      "eventId": "event-124",
      "timestamp": "2023-10-27T10:05:00Z",
      "type": "page_view",
      "data": {
        "path": "/dashboard"
      }
    }
  ],
  "nextPageToken": "eyJzaWQiOiJmZGVyIn0="
}
```
```

--------------------------------

### Python: Setting Policy Data for In-Tool Guardrails

Source: https://google.github.io/adk-docs/safety

This conceptual Python example illustrates how to define and store policy data that can be accessed by a tool through its `Tool Context`. This policy, which might include restrictions like `select_only` or allowed `tables`, helps implement in-tool guardrails to limit an agent's actions within the ADK framework. In practice, this data could be stored in `InvocationContext.session.state` or passed during tool initialization.

```python
# Conceptual example: Setting policy data intended for tool context
# In a real ADK app, this might be set in InvocationContext.session.state
# or passed during tool initialization, then retrieved via ToolContext.

policy = {} # Assuming policy is a dictionary
policy['select_only'] = True
policy['tables'] = ['mytable1', 'mytable2']

# Conceptual: Storing policy where the tool can access it via ToolContext later.
# This specific line might look different in practice.
# For example, storing in session state:
invocation_context.session.state["query_tool_policy"] = policy

# Or maybe passing during tool init:
query_tool = QueryTool(policy=policy)
```

--------------------------------

### Main Agent Interaction Setup and Execution in TypeScript

Source: https://google.github.io/adk-docs/agents/llm-agents

Initializes multiple agent runners with in-memory sessions, creates sessions for different agents (tool-based and schema-based), and executes agent interactions with sample country queries.

```typescript
async function main() {
    const capitalRunner = new InMemoryRunner({ appName: APP_NAME, agent: capitalAgentWithTool });
    const structuredRunner = new InMemoryRunner({ appName: APP_NAME, agent: structuredInfoAgentSchema });

    console.log("--- Creating Sessions ---");
    await capitalRunner.sessionService.createSession({ appName: APP_NAME, userId: USER_ID, sessionId: SESSION_ID_TOOL_AGENT });
    await structuredRunner.sessionService.createSession({ appName: APP_NAME, userId: USER_ID, sessionId: SESSION_ID_SCHEMA_AGENT });

    console.log("\n--- Testing Agent with Tool ---");
    await callAgentAndPrint(capitalRunner, capitalAgentWithTool, SESSION_ID_TOOL_AGENT, '{"country": "France"}');
    await callAgentAndPrint(capitalRunner, capitalAgentWithTool, SESSION_ID_TOOL_AGENT, '{"country": "Canada"}');

    console.log("\n\n--- Testing Agent with Output Schema (No Tool Use) ---");
    await callAgentAndPrint(structuredRunner, structuredInfoAgentSchema, SESSION_ID_SCHEMA_AGENT, '{"country": "France"}');
    await callAgentAndPrint(structuredRunner, structuredInfoAgentSchema, SESSION_ID_SCHEMA_AGENT, '{"country": "Japan"}');
}

main();
```

--------------------------------

### Configure and Receive Audio Output with RunConfig

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Demonstrates how to configure the ADK runner for audio output using RunConfig with response_modalities set to AUDIO and bidirectional streaming mode. The code processes incoming audio events from the model, extracts PCM audio data from inline_data parts, and provides options for streaming to client or saving to file. Audio data is automatically base64-decoded to raw bytes by the Pydantic types system.

```python
from google.adk.agents.run_config import RunConfig, StreamingMode

# Configure for audio output
run_config = RunConfig(
    response_modalities=["AUDIO"],  # Required for audio responses
    streaming_mode=StreamingMode.BIDI
)

# Process audio output from the model
async for event in runner.run_live(
    user_id="user_123",
    session_id="session_456",
    live_request_queue=live_request_queue,
    run_config=run_config
):
    # Events may contain multiple parts (text, audio, etc.)
    if event.content and event.content.parts:
        for part in event.content.parts:
            # Audio data arrives as inline_data with audio/pcm MIME type
            if part.inline_data and part.inline_data.mime_type.startswith("audio/pcm"):
                # The data is already decoded to raw bytes (24kHz, 16-bit PCM, mono)
                audio_bytes = part.inline_data.data

                # Your logic to stream audio to client
                await stream_audio_to_client(audio_bytes)

                # Or save to file
                # with open("output.pcm", "ab") as f:
                #     f.write(audio_bytes)
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph

Source: https://google.github.io/adk-docs/api-reference/java/allclasses-index

Retrieves the graph representation for a specific event within a user's session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph\n\n### Description\nRetrieves the graph representation for a specific event within a user's session.\n\n### Method\nGET\n\n### Endpoint\n/apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph\n\n### Parameters\n#### Path Parameters\n- **appName** (string) - Required - The name of the application.\n- **userId** (string) - Required - The ID of the user.\n- **sessionId** (string) - Required - The ID of the session.\n- **eventId** (string) - Required - The ID of the event.\n\n### Request Example\n(No request body for GET)\n\n### Response\n#### Success Response (200)\n- (object) - Description - The DTO containing the graph data. Specific fields are not detailed in the provided text.\n\n#### Response Example\n{\n  "graphData": {\n    "nodes": [\n      {\"id\": \"node1\", \"label\": \"Start\"},\n      {\"id\": \"node2\", \"label\": \"Process\"}\n    ],\n    "edges": [\n      {\"source\": \"node1\", \"target\": \"node2\"}\n    ]\n  }\n}
```

--------------------------------

### Configure Go LLM Agents for Parallel Research

Source: https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents

Illustrates the creation of multiple specialized `llmagent.New` instances in Go, each designed to research a specific topic (e.g., Renewable Energy, EV Technology, Carbon Capture). Each agent uses a Google Search tool, summarizes findings concisely, and outputs the summary to a specific `OutputKey` for subsequent processing. It also includes the necessary model initialization.

```go
model, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
if err != nil {
    return fmt.Errorf("failed to create model: %v", err)
}

// --- 1. Define Researcher Sub-Agents (to run in parallel) ---
researcher1, err := llmagent.New(llmagent.Config{
    Name:  "RenewableEnergyResearcher",
    Model: model,
    Instruction: "You are an AI Research Assistant specializing in energy.\n Research the latest advancements in 'renewable energy sources'.\n Use the Google Search tool provided.\n Summarize your key findings concisely (1-2 sentences).\n Output *only* the summary.",
    Description: "Researches renewable energy sources.",
    OutputKey:   "renewable_energy_result"
})
if err != nil {
    return err
}
researcher2, err := llmagent.New(llmagent.Config{
    Name:  "EVResearcher",
    Model: model,
    Instruction: "You are an AI Research Assistant specializing in transportation.\n Research the latest developments in 'electric vehicle technology'.\n Use the Google Search tool provided.\n Summarize your key findings concisely (1-2 sentences).\n Output *only* the summary.",
    Description: "Researches electric vehicle technology.",
    OutputKey:   "ev_technology_result"
})
if err != nil {
    return err
}
researcher3, err := llmagent.New(llmagent.Config{
    Name:  "CarbonCaptureResearcher",
    Model: model,
    Instruction: "You are an AI Research Assistant specializing in climate solutions.\n Research the current state of 'carbon capture methods'.\n Use the Google Search tool provided.\n Summarize your key findings concisely (1-2 sentences).\n Output *only* the summary.",
    Description: "Researches carbon capture methods.",
    OutputKey:   "carbon_capture_result"
})
if err != nil {
    return err
}
```

--------------------------------

### Run Agent as Tool Simulation in Go

Source: https://google.github.io/adk-docs/tools/function-tools

Demonstrates a complete workflow for executing a hierarchical agent system where a tool agent (summarizer) is wrapped and provided to a main agent. The main agent processes a user prompt about quantum computing and delegates summarization to the tool agent. Includes error handling and context management.

```go
func RunAgentAsToolSimulation() {
    ctx := context.Background()

    // 1. Create the Tool Agent (Summarizer)
    summarizerAgent, err := createSummarizerAgent(ctx)
    if err != nil {
        log.Fatalf("Failed to create summarizer agent: %v", err)
    }

    // 2. Wrap the Tool Agent in an AgentTool
    summarizeTool := agenttool.New(summarizerAgent, &agenttool.Config{
        SkipSummarization: true,
    })

    // 3. Create the Main Agent and provide it with the AgentTool
    mainAgent, err := createMainAgent(ctx, summarizeTool)
    if err != nil {
        log.Fatalf("Failed to create main agent: %v", err)
    }

    // 4. Run the main agent
    prompt := `
        Please summarize this text for me:
        Quantum computing represents a fundamentally different approach to computation,
        leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers
        that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively
        being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled,
        meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and
        interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such
        as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far
        faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages.
    `
    fmt.Printf("\nPrompt: %s\nResponse: ", prompt)
    callAgent(context.Background(), mainAgent, prompt)
    fmt.Println("\n---")
}
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/artifacts/BaseArtifactService

Retrieves a specific artifact by its filename within a given application, user, and session context. An optional version can be specified to load a historical version.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}

### Description
Retrieves a specific artifact by its filename within a given application, user, and session context. An optional version can be specified to load a historical version.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/artifacts/{filename}

### Parameters
#### Path Parameters
- **appName** (string) - Required - The name of the application.
- **userId** (string) - Required - The ID of the user.
- **sessionId** (string) - Required - The ID of the session.
- **filename** (string) - Required - The name of the artifact file.

#### Query Parameters
- **version** (integer) - Optional - The specific version number of the artifact to load. If omitted, the latest version is returned.

### Request Example
(No request body for GET)

### Response
#### Success Response (200)
- **artifact** (com.google.genai.types.Part) - The retrieved artifact content.

#### Response Example
{
  "content": "base64encodedartifactdata",
  "mimeType": "text/plain"
}
```

--------------------------------

### Append Instructions and Tools to LlmRequest.Builder

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/models/class-use/LlmRequest.Builder

Adds instructions and tools to the LLM request builder. Instructions guide the LLM behavior, while tools extend functionality with custom implementations like code execution or web search.

```java
LlmRequest.Builder builder = LlmRequest.builder()
  .appendInstructions(instructionsList)
  .appendTools(toolsList);
```

--------------------------------

### POST /plugin-manager

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/PluginManager

Initializes a new PluginManager instance, optionally registering a predefined list of plugins upon creation.

```APIDOC
## POST /plugin-manager

### Description
Initializes the PluginManager service, optionally registering an initial list of plugins upon construction.

### Method
POST

### Endpoint
/plugin-manager

### Parameters
#### Request Body
- **plugins** (BasePlugin[]) - Optional - An optional list of plugins to register upon initialization.

### Request Example
```json
{
  "plugins": [
    {
      "name": "MyPlugin",
      "version": "1.0.0"
    }
  ]
}
```

### Response
#### Success Response (200)
- **PluginManager** (object) - The newly initialized PluginManager instance.

#### Response Example
```json
{}
```
```

--------------------------------

### GET /apps/{appName}/eval_sets/{evalSetId}/evals

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

This endpoint retrieves a list of all evaluations contained within a specific evaluation set. It serves as a placeholder.

```APIDOC
## GET /apps/{appName}/eval_sets/{evalSetId}/evals

### Description
Placeholder for listing evaluations within an evaluation set.

### Method
GET

### Endpoint
/apps/{appName}/eval_sets/{evalSetId}/evals

### Parameters
#### Path Parameters
- **appName** (String) - Required - The application name.
- **evalSetId** (String) - Required - The evaluation set ID.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
{}

### Response
#### Success Response (200)
- **List<String>** (Array of String) - A list of evaluation IDs within the specified evaluation set.

#### Response Example
[
  "eval1",
  "eval2"
]
```

--------------------------------

### GET /adk/agent/apps/{appName}/users/{userId}/sessions/{sessionId}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/class-use/Session

Retrieves a specific session by its ID for a given application and user.

```APIDOC
## GET /adk/agent/apps/{appName}/users/{userId}/sessions/{sessionId}

### Description
Retrieves a specific session by its ID for a given application and user.

### Method
GET

### Endpoint
/adk/agent/apps/{appName}/users/{userId}/sessions/{sessionId}

### Parameters
#### Path Parameters
- **appName** (String) - Required - The name of the application.
- **userId** (String) - Required - The ID of the user.
- **sessionId** (String) - Required - The ID of the session to retrieve.

### Request Example
(No request body for GET)

### Response
#### Success Response (200)
- **id** (String) - The unique ID of the retrieved session.
- **appName** (String) - The name of the application associated with the session.
- **userId** (String) - The ID of the user associated with the session.
- **state** (Map<String,Object>) - The current state of the session.

#### Response Example
{
  "id": "clientSession456",
  "appName": "myApp",
  "userId": "user123",
  "state": {
    "theme": "dark",
    "language": "en"
  }
}
```

--------------------------------

### Get Session - Response

Source: https://google.github.io/adk-docs/runtime/api-server

Returns the session object with all details including session ID, app name, user ID, current state, events array, and last update timestamp.

```json
{"id":"s_abc","appName":"my_sample_agent","userId":"u_123","state":{"visit_count":5},"events":[...],"lastUpdateTime":1743711430.022186}
```

--------------------------------

### beforeAgentCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/BasePlugin

Callback executed before an agent's primary logic is invoked. This callback can be used for logging, setup, or to short-circuit the agent's execution by returning a value.

```APIDOC
## FUNCTION beforeAgentCallback

### Description
Callback executed before an agent's primary logic is invoked.
This callback can be used for logging, setup, or to short-circuit the agent's execution by returning a value.

### Method
FUNCTION

### Endpoint
beforeAgentCallback

### Parameters
#### Request Body
- **agent** ({ agent: BaseAgent; callbackContext: CallbackContext }) - Required - The agent that is about to run.

### Request Example
{
  "agent": {
    "agent": "BaseAgentInstance",
    "callbackContext": "CallbackContextInstance"
  }
}

### Response
#### Success Response (200)
- **Promise<Content | undefined>** - An optional `Content` object. If a value is returned, it will bypass the agent's callbacks and its execution, and return this value directly. Returning `undefined` allows the agent to proceed normally.

#### Response Example
"SomeContentObject"

```

--------------------------------

### McpInitializationException Class Definition

Source: https://google.github.io/adk-docs/api-reference/java/serialized-form

Exception thrown when MCP toolset initialization fails. Extends McpToolset.McpToolsetException and implements Serializable. Indicates errors during the setup or configuration phase of the MCP toolset.

```java
class McpInitializationException extends McpToolset.McpToolsetException implements Serializable
```

--------------------------------

### POST /LoggingPlugin/beforeAgentCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LoggingPlugin

Executed before an agent's primary logic is invoked. This callback can be used for logging, setup, or to short-circuit the agent's execution by returning a value.

```APIDOC
## POST /LoggingPlugin/beforeAgentCallback

### Description
This callback is executed before an agent's primary logic is invoked. It can be utilized for initial logging, setting up resources, or to bypass the agent's normal execution entirely by returning a `Content` object.

### Method
POST

### Endpoint
/LoggingPlugin/beforeAgentCallback

### Parameters
#### Path Parameters
(None)

#### Query Parameters
(None)

#### Request Body
- **agent** (object) - Required - An object containing the agent instance and its callback context.
  - **agent** (BaseAgent) - The `BaseAgent` instance that is about to run.
  - **callbackContext** (CallbackContext) - The context associated with the agent's callback.

### Request Example
{
  "agent": {
    "agent": { "id": "anotherAgentId", "type": "BaseAgent" },
    "callbackContext": { "invocationId": "inv_def", "step": 2 }
  }
}

### Response
#### Success Response (200)
- **content** (Content | undefined) - An optional `Content` object. If a value is returned, it will bypass the agent's callbacks and execution, returning this value directly. Returning `null` or `undefined` allows the agent to proceed normally.

#### Response Example
{
  "content": {
    "type": "error",
    "value": "Agent execution preempted by plugin due to an issue."
  }
}
```

--------------------------------

### GET /runner/{appName}

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/runner/class-use/Runner

Retrieves the Runner instance for a specified application name. This method is part of the AdkWebServer.RunnerService and returns a Runner object that manages the execution context for the given application.

```APIDOC
## GET /runner/{appName}

### Description
Gets the Runner instance for a given application name from the ADK Web Server.

### Method
GET

### Endpoint
/runner/{appName}

### Parameters
#### Path Parameters
- **appName** (String) - Required - The name of the application for which to retrieve the Runner instance

### Response
#### Success Response (200)
- **Runner** (Runner) - The Runner instance associated with the specified application name

### Related Classes
- **Runner** - Base interface for runner implementations
- **InMemoryRunner** - Implementation of Runner using in-memory artifact and session services
- **AdkWebServer.RunnerService** - Service class containing this method
```

--------------------------------

### Attach Pre-Hook to ToolboxToolset (Python)

Source: https://google.github.io/adk-docs/tools/google-cloud/mcp-toolbox-for-databases

This Python example demonstrates how to attach a `pre_hook` function to a `ToolboxToolset`. The `pre_hook` executes custom logic before a tool invocation, allowing for actions like logging or validation based on the context and arguments.

```python
async def log_start(context, args):
    print(f"Starting tool with args: {args}")

toolset = ToolboxToolset(
    server_url="...",
    pre_hook=log_start
)
```

--------------------------------

### Process Audio Transcriptions from Event Stream

Source: https://google.github.io/adk-docs/streaming/dev-guide/part5

Demonstrates how to access and process `types.Transcription` objects from the `Event` stream, including best practices for null checking.

```APIDOC
## Process Audio Transcriptions from Event Stream

### Description
Accesses and processes `types.Transcription` objects from the `Event` stream, providing transcribed text and completion status for both user input and model output.

### Method
`runner.run_live()` (Client Library Stream Processing)

### Endpoint
N/A (Client Library Stream Processing)

### Parameters
#### Path Parameters
N/A

#### Query Parameters
N/A

#### Request Body
N/A (This is processing an incoming stream, not making a request body)

### Request Example
N/A (This is processing an incoming stream, not making a request)

### Response
#### Success Response (200)
- **Event object structure**:
  - **content** (Optional[Content]) - Audio/text content.
  - **input_transcription** (Optional[types.Transcription]) - User speech → text transcription.
  - **output_transcription** (Optional[types.Transcription]) - Model speech → text transcription.
- **types.Transcription object attributes**:
  - **.text** (string) - The transcribed text.
  - **.finished** (boolean) - Indicates if transcription is complete (`True`) or partial (`False`).

#### Response Example
```python
from google.adk.runners import Runner
from google.genai import types
from dataclasses import dataclass
from typing import Optional

# Assume runner setup code here, e.g., runner = Runner(...)

@dataclass
class Content:
    # Placeholder for actual Content definition
    pass

@dataclass
class Event:
    content: Optional[Content]
    input_transcription: Optional[types.Transcription]
    output_transcription: Optional[types.Transcription]
    # ... other fields

async def process_events(runner: Runner):
    async for event in runner.run_live(...):
        # User's speech transcription (from input audio)
        if event.input_transcription:  # First check: transcription object exists
            # Access the transcription text and status
            user_text = event.input_transcription.text
            is_finished = event.input_transcription.finished

            # Second check: text is not None or empty
            # This handles cases where transcription is in progress or empty
            if user_text and user_text.strip():
                print(f"User said: {user_text} (finished: {is_finished})")

                # Your caption update logic
                # update_caption(user_text, is_user=True, is_final=is_finished)

        # Model's speech transcription (from output audio)
        if event.output_transcription:  # First check: transcription object exists
            model_text = event.output_transcription.text
            is_finished = event.output_transcription.finished

            # Second check: text is not None or empty
            # This handles cases where transcription is in progress or empty
            if model_text and model_text.strip():
                print(f"Model said: {model_text} (finished: {is_finished})")

                # Your caption update logic
                # update_caption(model_text, is_user=False, is_final=is_finished)
```
```

--------------------------------

### GET /sessions/{sessionId}/events - List Events

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/BaseSessionService

Lists all events within a specific session. Returns a paginated or complete list of events associated with the given session ID.

```APIDOC
## GET /sessions/{sessionId}/events

### Description
Lists the events within a specific session. Returns a response containing all events associated with the given session.

### Method
GET

### Endpoint
/sessions/{sessionId}/events

### Parameters
#### Path Parameters
- **sessionId** (String) - Required - The unique identifier of the session

#### Query Parameters
- **appName** (String) - Required - The name of the application
- **userId** (String) - Required - The identifier of the user

### Response
#### Success Response (200)
- **ListEventsResponse** (ListEventsResponse) - A response containing a list of events within the session

#### Response Example
{
  "events": [
    {
      "eventId": "event-1",
      "timestamp": "2024-01-15T10:30:00Z",
      "stateDelta": {
        "key1": "value1"
      }
    },
    {
      "eventId": "event-2",
      "timestamp": "2024-01-15T10:31:00Z",
      "stateDelta": {
        "key2": "value2"
      }
    }
  ]
}

### Error Handling
- **SessionException** - if listing fails
```

--------------------------------

### Invoke Agent with Reimbursement Requests (Python)

Source: https://google.github.io/adk-docs/tools/function-tools

These lines demonstrate how to invoke the `call_agent_async` function with different reimbursement queries. They show examples for both direct `await` calls (suitable for notebooks) and `asyncio.run()` (for standalone scripts), illustrating how to trigger agent interactions for various scenarios, such as requests requiring or not requiring approval.

```python
# reimbursement that doesn't require approval
# asyncio.run(call_agent_async("Please reimburse 50$ for meals"))
await call_agent_async("Please reimburse 50$ for meals") # For Notebooks, uncomment this line and comment the above line
# reimbursement that requires approval
# asyncio.run(call_agent_async("Please reimburse 200$ for meals"))
await call_agent_async("Please reimburse 200$ for meals") # For Notebooks, uncomment this line and comment the above line
```

--------------------------------

### Populate Instruction Template with Session State and Artifacts (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/utils/InstructionUtils

This method populates placeholders in a given template string using values from the session state or saved artifacts. It supports specific placeholder syntaxes for session variables (e.g., '{user:name}') and artifacts (e.g., '{artifact.file_name}'), including optional placeholders marked with '?'. Invalid or missing optional placeholders are replaced with empty strings, while missing non-optional ones throw exceptions. It returns an RxJava Single emitting the processed string.

```java
import io.reactivex.rxjava3.core.Single;
import com.google.adk.utils.InvocationContext;
import com.google.adk.utils.Session;
import jakarta.ws.rs.core.Part;

public final class InstructionUtils {

    public static Single<String> injectSessionState(InvocationContext context, String template) {
        // Implementation details for populating placeholders
        // This is a placeholder for the actual logic described in the documentation.
        // The actual implementation would involve parsing the template, resolving keys
        // from context.session().state() or context.artifactService(), and handling optionality.
        
        // Example of how a result might be constructed (highly simplified):
        String resolvedTemplate = template;
        // ... logic to replace {user:name}, {artifact.knowledge.txt}, etc. ...
        
        return Single.just(resolvedTemplate);
    }

    // Assume InvocationContext, Session, and related classes/interfaces are defined elsewhere.
    // For demonstration purposes, defining minimal stubs:
    public static class InvocationContext {
        public Session session() { return new Session(); }
        public ArtifactService artifactService() { return new ArtifactService(); }
    }
    public static class Session {
        public State state() { return new State(); }
        public String appName() { return "defaultApp"; }
        public String userId() { return "defaultUser"; }
        public String id() { return "defaultSessionId"; }
    }
    public static class State {
        public void put(String key, String value) { /* stub */ }
        public String get(String key) { /* stub */ return null; }
    }
    public static class ArtifactService {
        public void saveArtifact(String appName, String userId, String sessionId, String fileName, Part part) { /* stub */ }
        public Part getArtifact(String appName, String userId, String sessionId, String fileName) { /* stub */ return null; }
    }

    // Example Usage from documentation:
    public static void main(String[] args) {
        InvocationContext context = new InvocationContext();
        Session session = context.session();

        session.state().put("user:name", "Alice");

        context.artifactService().saveArtifact(
            session.appName(), session.userId(), session.id(), "knowledge.txt", Part.fromText("Origins of the universe: At first, there was-"));

        String template = "You are {user:name}'s assistant. Answer questions based on your knowledge. Your knowledge: {artifact.knowledge.txt}." +
                          " Your extra knowledge: {artifact.missing_artifact.txt?}";

        Single<String> populatedStringSingle = InstructionUtils.injectSessionState(context, template);
        populatedStringSingle.subscribe(
            result -> System.out.println(result),
            error -> System.err.println("Error populating template: " + error.getMessage())
        );
    }
}
```

--------------------------------

### Configure ADK Docs MCP Server in Antigravity IDE

Source: https://google.github.io/adk-docs/tutorials/coding-with-ai

This JSON configuration block sets up a custom MCP server named 'adk-docs-mcp' within Antigravity IDE's `mcp_config.json`. It uses `uvx` to run a documentation server that points to the ADK `llms.txt` file, enabling the IDE's agent to access ADK documentation for development tasks. Ensure the `uv` tool is installed as a prerequisite.

```json
{
  "mcpServers": {
    "adk-docs-mcp": {
      "command": "uvx",
      "args": [
        "--from",
        "mcpdoc",
        "mcpdoc",
        "--urls",
        "AgentDevelopmentKit:https://google.github.io/adk-docs/llms.txt",
        "--transport",
        "stdio"
      ]
    }
  }
}
```

--------------------------------

### Export Cloud Run Service URL for API Testing

Source: https://google.github.io/adk-docs/deploy/cloud-run

Sets an environment variable with the deployed Cloud Run service URL for use in subsequent curl commands. Replace the example URL with your actual deployed service URL.

```bash
export APP_URL="YOUR_CLOUD_RUN_SERVICE_URL"
# Example: export APP_URL="https://adk-default-service-name-abc123xyz.a.run.app"
```

--------------------------------

### Configure Runner with Artifact Service - Go

Source: https://google.github.io/adk-docs/artifacts

Demonstrates Go implementation for creating a runner with artifact service support. Initializes Gemini model, creates LLM agent with instructions, sets up in-memory artifact and session services, and builds a runner with error handling.

```go
import (
  "context"
  "log"

  "google.golang.org/adk/agent/llmagent"
  "google.golang.org/adk/artifactservice"
  "google.golang.org/adk/llm/gemini"
  "google.golang.org/adk/runner"
  "google.golang.org/adk/sessionservice"
  "google.golang.org/genai"
)

// Create a new context.
ctx := context.Background()
// Set the app name.
const appName = "my_artifact_app"
// Create a new Gemini model.
model, err := gemini.NewModel(ctx, "gemini-2.5-flash", &genai.ClientConfig{})
if err != nil {
    log.Fatalf("Failed to create model: %v", err)
}

// Create a new LLM agent.
myAgent, err := llmagent.New(llmagent.Config{
    Model:       model,
    Name:        "artifact_user_agent",
    Instruction: "You are an agent that describes images.",
    BeforeModelCallbacks: []llmagent.BeforeModelCallback{
        BeforeModelCallback,
    },
})
if err != nil {
    log.Fatalf("Failed to create agent: %v", err)
}

// Create a new in-memory artifact service.
artifactService := artifact.InMemoryService()
// Create a new in-memory session service.
sessionService := session.InMemoryService()

// Create a new runner.
r, err := runner.New(runner.Config{
    Agent:           myAgent,
    AppName:         appName,
    SessionService:  sessionService,
    ArtifactService: artifactService, // Provide the service instance here
})
if err != nil {
    log.Fatalf("Failed to create runner: %v", err)
}
log.Printf("Runner created successfully: %v", r)
```

--------------------------------

### Main Async Entry Point for ADK Authentication Workflow

Source: https://google.github.io/adk-docs/tools-custom/authentication

Defines the main asynchronous function entry point that orchestrates the complete authentication workflow. Uses asyncio.run() to execute the async_main() coroutine, enabling proper event loop management for the entire authentication request-response cycle and agent execution.

```python
if __name__ == '__main__':
    asyncio.run(async_main())
```

--------------------------------

### GET /artifacts/load - Retrieve Artifact

Source: https://google.github.io/adk-docs/artifacts

Load a saved artifact by filename with optional version specification. Retrieves the latest version by default or a specific version if provided.

```APIDOC
## GET /artifacts/load - Retrieve Artifact

### Description
Retrieve a previously saved artifact by filename. Supports retrieving the latest version or a specific version number.

### Method
GET

### Endpoint
/artifacts/load

### Parameters
#### Query Parameters
- **filename** (string) - Required - The filename identifier of the artifact to retrieve
- **version** (integer) - Optional - Specific version number to retrieve (if not provided, retrieves latest)

### Request Example
```
GET /artifacts/load?filename=monthly_report.pdf
GET /artifacts/load?filename=monthly_report.pdf&version=0
```

### Response
#### Success Response (200)
- **filename** (string) - The filename of the artifact
- **version** (integer) - The version number retrieved
- **mime_type** (string) - The MIME type of the artifact
- **data** (bytes) - The raw byte data of the artifact

#### Response Example
```json
{
  "filename": "monthly_report.pdf",
  "version": 0,
  "mime_type": "application/pdf",
  "data": "JVBERi0xLjQ..."
}
```
```

--------------------------------

### Initialize InMemoryMemoryService in Python

Source: https://google.github.io/adk-docs/sessions/memory

Creates an in-memory memory service instance for basic keyword matching. Requires no setup and is ideal for prototyping and local development. Data is stored in application memory and will be lost on restart.

```python
from google.adk.memory import InMemoryMemoryService
memory_service = InMemoryMemoryService()
```

--------------------------------

### GET /apps/{app_name}/users/{user_id}/sessions/{session_id}

Source: https://google.github.io/adk-docs/runtime/api-server

Retrieves the details of a specific session, including its current state and all associated events. This allows inspecting a user's interaction history.

```APIDOC
## GET /apps/{app_name}/users/{user_id}/sessions/{session_id}

### Description
Retrieves the details of a specific session, including its current state and all associated events.

### Method
GET

### Endpoint
/apps/{app_name}/users/{user_id}/sessions/{session_id}

### Parameters
#### Path Parameters
- **app_name** (string) - Required - The name of the agent application.
- **user_id** (string) - Required - The ID of the user.
- **session_id** (string) - Required - The ID of the session to retrieve.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **id** (string) - The ID of the session.
- **appName** (string) - The name of the agent application.
- **userId** (string) - The ID of the user.
- **state** (object) - The current state of the session.
- **events** (array) - A list of events associated with the session.
- **lastUpdateTime** (number) - The timestamp of the last update.

#### Response Example
```json
{"id":"s_abc","appName":"my_sample_agent","userId":"u_123","state":{"visit_count":5},"events":[...],"lastUpdateTime":1743711430.022186}
```
```

--------------------------------

### Managing Function Call ID (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/ToolContext

Illustrates how to get and set the unique identifier for a function call within the ToolContext. This is useful for tracking and correlation.

```java
Optional<String> funcId = toolContext.functionCallId();

toolContext.functionCallId("my-unique-call-id");
```

--------------------------------

### Initialize AgentOps with Environment Variable

Source: https://google.github.io/adk-docs/observability/agentops

Initializes the AgentOps SDK in your Python application. It automatically tracks ADK agents and starts a session. It's recommended to set your API key as an environment variable.

```python
import agentops
agentops.init()

```

--------------------------------

### Configure Java ADK with Maven pom.xml

Source: https://google.github.io/adk-docs/get-started/installation

Add Google ADK core library and optional dev tools to Maven project configuration. Includes Java compiler version settings (17) and UTF-8 encoding configuration.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.agent</groupId>
    <artifactId>adk-agents</artifactId>
    <version>1.0-SNAPSHOT</version>

    <!-- Specify the version of Java you'll be using -->
    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- The ADK core dependency -->
        <dependency>
            <groupId>com.google.adk</groupId>
            <artifactId>google-adk</artifactId>
            <version>0.5.0</version>
        </dependency>
        <!-- The ADK dev web UI to debug your agent -->
        <dependency>
            <groupId>com.google.adk</groupId>
            <artifactId>google-adk-dev</artifactId>
            <version>0.5.0</version>
        </dependency>
    </dependencies>

</project>
```

--------------------------------

### Get and Set Event Timestamp - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/events/Event

Getter and setter methods for the event timestamp. The timestamp records when the event occurred as a long integer value.

```java
public long timestamp()
public void setTimestamp(long timestamp)
```

--------------------------------

### GoogleSearchTool Constructor

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/GoogleSearchTool

Initializes a new instance of the GoogleSearchTool.

```APIDOC
## GoogleSearchTool()

### Description
Initializes a new instance of the GoogleSearchTool.

### Method
`GoogleSearchTool()`

### Endpoint
N/A (Constructor)

### Parameters
None

### Request Example
```json
{
  "constructor": "GoogleSearchTool()"
}
```

### Response
N/A (Constructor)
```

--------------------------------

### Implement and Register Before Agent Callback (Go, Java)

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

This set of examples demonstrates how to define and register a 'before agent' callback in ADK. The callback allows for pre-execution logic, such as inspecting the session state to decide whether to skip an agent's processing, as shown in both Go and Java implementations.

```go
package main

import (
    "context"
    "fmt"
    "log"
    "regexp"
    "strings"

    "google.golang.org/adk/agent"
    "google.golang.org/adk/agent/llmagent"
    "google.golang.org/adk/model"
    "google.golang.org/adk/model/gemini"
    "google.golang.org/adk/runner"
    "google.golang.org/adk/session"
    "google.golang.org/adk/tool"
    "google.golang.org/adk/tool/functiontool"
    "google.golang.org/genai"
)



// 1. Define the Callback Function
func onBeforeAgent(ctx agent.CallbackContext) (*genai.Content, error) {
    agentName := ctx.AgentName()
    log.Printf("[Callback] Entering agent: %s", agentName)
    if skip, _ := ctx.State().Get("skip_llm_agent"); skip == true {
        log.Printf("[Callback] State condition met: Skipping agent %s", agentName)
        return genai.NewContentFromText(
                fmt.Sprintf("Agent %s skipped by before_agent_callback.", agentName),
                genai.RoleModel,
            ),
            nil
    }
    log.Printf("[Callback] State condition not met: Running agent %s", agentName)
    return nil, nil
}

// 2. Define a function to set up and run the agent with the callback.
func runBeforeAgentExample() {
    ctx := context.Background()
    geminiModel, err := gemini.NewModel(ctx, modelName, &genai.ClientConfig{})
    if err != nil {
        log.Fatalf("FATAL: Failed to create model: %v", err)
    }

    // 3. Register the callback in the agent configuration.
    llmCfg := llmagent.Config{
        Name:                 "AgentWithBeforeAgentCallback",
        BeforeAgentCallbacks: []agent.BeforeAgentCallback{onBeforeAgent},
        Model:                geminiModel,
        Instruction:          "You are a concise assistant.",
    }
    testAgent, err := llmagent.New(llmCfg)
    if err != nil {
        log.Fatalf("FATAL: Failed to create agent: %v", err)
    }

    sessionService := session.InMemoryService()
    r, err := runner.New(runner.Config{AppName: appName, Agent: testAgent, SessionService: sessionService})
    if err != nil {
        log.Fatalf("FATAL: Failed to create runner: %v", err)
    }

    // 4. Run scenarios to demonstrate the callback's behavior.
    log.Println("--- SCENARIO 1: Agent should run normally ---")
    runScenario(ctx, r, sessionService, appName, "session_normal", nil, "Hello, world!")

    log.Println("\n--- SCENARIO 2: Agent should be skipped ---")
    runScenario(ctx, r, sessionService, appName, "session_skip", map[string]any{"skip_llm_agent": true}, "This should be skipped.")
}
```

```java
import com.google.adk.agents.LlmAgent;
import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.CallbackContext;
import com.google.adk.events.Event;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.adk.sessions.State;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.core.Maybe;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BeforeAgentCallbackExample {

  private static final String APP_NAME = "AgentWithBeforeAgentCallback";
  private static final String USER_ID = "test_user_456";
  private static final String SESSION_ID = "session_id_123";
  private static final String MODEL_NAME = "gemini-2.0-flash";

  public static void main(String[] args) {
    BeforeAgentCallbackExample callbackAgent = new BeforeAgentCallbackExample();
    callbackAgent.defineAgent("Write a document about a cat");
  }

  // --- 1. Define the Callback Function ---
  /**
   * Logs entry and checks 'skip_llm_agent' in session state. If True, returns Content to skip the
   * agent's execution. If False or not present, returns None to allow execution.
   */
  public Maybe<Content> checkIfAgentShouldRun(CallbackContext callbackContext) {
    String agentName = callbackContext.agentName();
    String invocationId = callbackContext.invocationId();
    State currentState = callbackContext.state();

    System.out.printf("%n[Callback] Entering agent: %s (Inv: %s)%n", agentName, invocationId);
    System.out.printf("[Callback] Current State: %s%n", currentState.entrySet());

    // Check the condition in session state dictionary
    if (Boolean.TRUE.equals(currentState.get("skip_llm_agent"))) {
      System.out.printf(
          "[Callback] State condition 'skip_llm_agent=True' met: Skipping agent %s", agentName);
      // Return Content to skip the agent's run
      return Maybe.just(
          Content.fromParts(
              Part.fromText(
                  String.format(
                      "Agent %s skipped by before_agent_callback due to state.", agentName))));
    }

    System.out.printf(
```

--------------------------------

### Setup InMemoryRunner and Create Sessions - TypeScript/JavaScript

Source: https://google.github.io/adk-docs/callbacks/types-of-callbacks

Configures InMemoryRunner with an LLM agent and creates two sessions with different state configurations. Session 1 has default empty state allowing agent execution, while Session 2 sets 'skip_llm_agent' flag to true for conditional skipping.

```typescript
async function main() {
  // Use InMemoryRunner - it includes InMemorySessionService
  const runner = new InMemoryRunner({
    agent: llmAgentWithBeforeCb,
    appName: APP_NAME,
  });

  // Create session 1: Agent will run (default empty state)
  await runner.sessionService.createSession({
    appName: APP_NAME,
    userId: USER_ID,
    sessionId: SESSION_ID_RUN,
    // No initial state means 'skip_llm_agent' will be False in the callback check
  });

  // Create session 2: Agent will be skipped (state has skip_llm_agent=True)
  await runner.sessionService.createSession({
    appName: APP_NAME,
    userId: USER_ID,
    sessionId: SESSION_ID_SKIP,
    state: { skip_llm_agent: true }, // Set the state flag here
  });
}
```

--------------------------------

### Get and Set Interrupted Flag - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/events/Event

Getter and setter methods for the interrupted flag. This optional boolean indicates whether the event processing was interrupted.

```java
public Optional<Boolean> interrupted()
public void setInterrupted(Optional<Boolean> interrupted)
```

--------------------------------

### Define ADK Agent with Declarative Google Search Tool (Python)

Source: https://google.github.io/adk-docs/streaming/dev-guide/part3

This Python snippet demonstrates how to define an ADK `Agent` and declaratively attach a `google_search` tool. By specifying tools during agent initialization, ADK automatically handles their execution when `run_live()` is called, simplifying complex interactions with the Gemini Live API. It requires the `google.adk` library and an environment variable for the model.

```python
import os
from google.adk.agents import Agent
from google.adk.tools import google_search

agent = Agent(
    name="google_search_agent",
    model=os.getenv("DEMO_AGENT_MODEL", "gemini-2.5-flash-native-audio-preview-12-2025"),
    tools=[google_search],
    instruction="You are a helpful assistant that can search the web."
)
```

--------------------------------

### Run Agent via Terminal - TypeScript

Source: https://google.github.io/adk-docs/get-started/quickstart

Execute the agent from the terminal using npx adk run with the agent filename. This starts an interactive chat session with the agent. Use Cmd/Ctrl+C to exit.

```bash
npx adk run agent.ts
```

--------------------------------

### Get and Set Event Content - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/events/Event

Getter and setter methods for the event content, wrapped in an Optional. The content represents the main payload of the event.

```java
public Optional<com.google.genai.types.Content> content()
public void setContent(Optional<com.google.genai.types.Content> content)
```

--------------------------------

### List Available Agents - GET Request

Source: https://google.github.io/adk-docs/runtime/api-server

Retrieves a list of all agent applications discovered by the API server. This utility endpoint returns a simple JSON array of agent names. No request body is required.

```bash
curl -X GET http://localhost:8000/list-apps
```

--------------------------------

### Create Main Agent with Tool Delegation in Go

Source: https://google.github.io/adk-docs/tools/function-tools

Initializes a main agent with instruction set and tool configuration. The agent is configured with a name, model, specific instructions for tool usage, and a list of available tools for task delegation. This pattern enables the agent to intelligently decide when to use provided tools.

```go
Name:  "MainAgent",
Model: model,
Instruction: "You are a helpful assistant. If you are asked to summarize a long text, use the 'summarize' tool. " +
    "After getting the summary, present it to the user by saying 'Here is a summary of the text:'.",
Description: "The main agent that can delegate tasks.",
Tools:       tools,
```

--------------------------------

### Update tsconfig.json for ADK TypeScript Modules

Source: https://google.github.io/adk-docs/get-started/typescript

This snippet shows how to modify the 'tsconfig.json' file. Setting 'verbatimModuleSyntax' to 'false' simplifies module import syntax, which is often preferred for development with CommonJS-style modules.

```json
    // set to false to allow CommonJS module syntax:
    "verbatimModuleSyntax": false,
```

--------------------------------

### Project Directory Structure for Cloud Run Deployment

Source: https://google.github.io/adk-docs/deploy/cloud-run

Recommended project structure for deploying an agent to Google Cloud Run using gcloud CLI with Docker. Includes the agent directory with __init__.py and agent.py, FastAPI entry point (main.py), Python dependencies (requirements.txt), and Docker build instructions (Dockerfile).

```text
your-project-directory/
├── capital_agent/
│   ├── __init__.py
│   └── agent.py       # Your agent code (see "Agent sample" tab)
├── main.py            # FastAPI application entry point
├── requirements.txt   # Python dependencies
└── Dockerfile         # Container build instructions
```

--------------------------------

### Generate Get Operation (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/tools/applicationintegrationtoolset/ConnectionsClient

Generates an operation specification for retrieving a single entity. This static method requires entity name, schema as a string, tool name, and tool instructions, returning an ImmutableMap<String, Object>.

```java
public static com.google.common.collect.ImmutableMap<String,Object> getOperation(String entity, String schemaAsString, String toolName, String toolInstructions)
```

--------------------------------

### Run Agent via Terminal with Piped Input - Python

Source: https://google.github.io/adk-docs/get-started/quickstart

Execute an agent with initial prompts by piping text to the adk run command. This automatically injects the piped text as the starting message to the agent.

```bash
echo "Please start by listing files" | adk run file_listing_agent
```

--------------------------------

### Run ADK Agent with Web UI Interface

Source: https://google.github.io/adk-docs/agents/config

Terminal command to launch the ADK agent with a web-based user interface. Execute this command from the project directory containing root_agent.yaml to start an interactive web interface for testing and interacting with the agent.

```bash
adk web
```

--------------------------------

### CALLBACK /onUserMessageCallback

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/LoggingPlugin

Executed when a user message is received before an invocation starts. Helps in logging and modifying the user message before the runner begins the invocation.

```APIDOC
## CALLBACK /onUserMessageCallback

### Description
Callback executed when a user message is received before an invocation starts. This callback helps logging and modifying the user message before the runner starts the invocation.

### Method
CALLBACK

### Endpoint
/onUserMessageCallback

### Parameters
#### Request Body
- **invocationContext** (object) - Required - The context for the entire invocation.
  - **invocationContext** (InvocationContext) - The invocation context object.
  - **userMessage** (Content) - The user's message content.

### Request Example
```json
{
  "invocationContext": {
    "invocationContext": {},
    "userMessage": {
      "text": "Hello, how are you?"
    }
  }
}
```

### Response
#### Success Response (200)
- **Content** (Content | undefined) - An optional value representing the user message. A non-`undefined` return may be used by the framework to modify or replace the user message. Returning `undefined` allows the original user message to be used.

#### Response Example
```json
{
  "text": "Hello, how are you today?"
}
```
```

--------------------------------

### Build ADK Go CLI Tool

Source: https://google.github.io/adk-docs/deploy/cloud-run

Compiles the adkgo command-line tool from the google/adk-go repository. This tool provides automated deployment capabilities for Cloud Run without requiring a custom Dockerfile. Execute this command from the root directory of the adk-go repository.

```bash
go build ./cmd/adkgo
```

--------------------------------

### Define a Basic ADK TypeScript Agent

Source: https://google.github.io/adk-docs/get-started/typescript

This TypeScript code defines a basic ADK agent ('LlmAgent') that includes a 'FunctionTool' named 'getCurrentTime'. It uses '@google/adk' and 'zod' for schema validation, allowing the agent to return the current time for a specified city.

```typescript
import {FunctionTool, LlmAgent} from '@google/adk';
import {z} from 'zod';

/* Mock tool implementation */
const getCurrentTime = new FunctionTool({
  name: 'get_current_time',
  description: 'Returns the current time in a specified city.',
  parameters: z.object({
    city: z.string().describe("The name of the city for which to retrieve the current time."),
  }),
  execute: ({city}) => {
    return {status: 'success', report: `The current time in ${city} is 10:30 AM`};
  },
});

export const rootAgent = new LlmAgent({
  name: 'hello_time_agent',
  model: 'gemini-2.5-flash',
  description: 'Tells the current time in a specified city.',
  instruction: `You are a helpful assistant that tells the current time in a city.
                Use the 'getCurrentTime' tool for this purpose.`,
  tools: [getCurrentTime],
});
```

--------------------------------

### Implement Asynchronous Database Call in Python ADK

Source: https://google.github.io/adk-docs/tools-custom/performance

This example illustrates how to write a database calling function, `query_database()`, to operate asynchronously using `asyncpg.connect`, enabling non-blocking database interactions within the ADK.

```python
async def query_database(query: str) -> list:
      async with asyncpg.connect("postgresql://...") as conn:
          return await conn.fetch(query)
```

--------------------------------

### GET /apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/web/AdkWebServer.AgentController

Retrieves a graph representation of a specific event within a user session.

```APIDOC
## GET /apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph

### Description
Endpoint to get a graph representation of an event (currently returns a placeholder). Requires Graphviz or similar tooling for full implementation.

### Method
GET

### Endpoint
/apps/{appName}/users/{userId}/sessions/{sessionId}/events/{eventId}/graph

### Parameters
#### Path Parameters
- **appName** (String) - Required - Application name.
- **userId** (String) - Required - User ID.
- **sessionId** (String) - Required - Session ID.
- **eventId** (String) - Required - Event ID.

#### Query Parameters
(None)

#### Request Body
(None)

### Request Example
(None)

### Response
#### Success Response (200)
- **graphResponse** (org.springframework.http.ResponseEntity<AdkWebServer.GraphResponse>) - ResponseEntity containing a GraphResponse with placeholder DOT source.

#### Response Example
{
  "dotSource": "digraph G { A -> B; B -> C; }"
}

### Error Handling
- **404 Not Found**: If the session or event is not found.
```

--------------------------------

### Create LLM Agents with Memory Support in Python

Source: https://google.github.io/adk-docs/sessions/memory

Demonstrates agent setup with memory capabilities. Creates two agents: one for capturing information and another for memory recall using the load_memory tool. The memory recall agent uses the tool to query past conversations when answering questions.

```python
import asyncio
from google.adk.agents import LlmAgent
from google.adk.sessions import InMemorySessionService, Session
from google.adk.memory import InMemoryMemoryService # Import MemoryService
from google.adk.runners import Runner
from google.adk.tools import load_memory # Tool to query memory
from google.genai.types import Content, Part

# --- Constants ---
APP_NAME = "memory_example_app"
USER_ID = "mem_user"
MODEL = "gemini-2.0-flash" # Use a valid model

# --- Agent Definitions ---
# Agent 1: Simple agent to capture information
info_capture_agent = LlmAgent(
    model=MODEL,
    name="InfoCaptureAgent",
    instruction="Acknowledge the user's statement.",
)

# Agent 2: Agent that can use memory
memory_recall_agent = LlmAgent(
    model=MODEL,
    name="MemoryRecallAgent",
    instruction="Answer the user's question. Use the 'load_memory' tool "
                "if the answer might be in past conversations.",
    tools=[load_memory] # Give the agent the tool
)
```

--------------------------------

### runLive with Session and RunConfig

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/runner/Runner

Runs the agent in live mode, appending generated events to the session.

```APIDOC
## runLive with Session and RunConfig

### Description
Runs the agent in live mode, appending generated events to the session.

### Method
`public io.reactivex.rxjava3.core.Flowable<Event> runLive(Session session, LiveRequestQueue liveRequestQueue, RunConfig runConfig)`

### Parameters
#### Path Parameters
None

#### Query Parameters
None

#### Request Body
- **session** (Session) - Required - The session to run the agent in.
- **liveRequestQueue** (LiveRequestQueue) - Required - The queue for live requests.
- **runConfig** (RunConfig) - Required - Configuration for the agent run.

### Request Example
```json
{
  "session": {
    "sessionId": "sessionXYZ"
  },
  "liveRequestQueue": {},
  "runConfig": {
    "maxTokens": 100
  }
}
```

### Response
#### Success Response (200)
- **Flowable<Event>** - A stream of events from the agent.

#### Response Example
None
```

--------------------------------

### Get Last Update Time as Double (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Retrieves the last modification time of the session as a double-precision floating-point number. This is likely a Unix timestamp representation.

```java
public double getLastUpdateTimeAsDouble()
```

--------------------------------

### Launch Dev UI with ADK - TypeScript

Source: https://google.github.io/adk-docs/get-started/quickstart

Start the development UI for TypeScript agents using npx adk web command. The UI runs on localhost:8000 and requires the command to be run in the directory containing agent.ts file.

```bash
npx adk web
```

--------------------------------

### Get Session State (Java)

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/sessions/Session

Returns the current state of the session as a concurrent map. This map can store arbitrary key-value pairs representing session-specific data.

```java
public ConcurrentMap<String,Object> state()
```

--------------------------------

### Run Weather Agent Asynchronously with Session Management

Source: https://google.github.io/adk-docs/tools-custom

Implements an async main function that sets up an InMemorySessionService, creates a session with specified app_name, user_id, and session_id, then runs the agent with a weather query. The function iterates through events and retrieves the final response from the agent. Requires async/await syntax and proper event handling from the runner.

```python
async def main():
    """Main function to run the agent asynchronously."""
    # Session and Runner Setup
    session_service = InMemorySessionService()
    # Use 'await' to correctly create the session
    await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)

    runner = Runner(agent=weather_sentiment_agent, app_name=APP_NAME, session_service=session_service)

    # Agent Interaction
    query = "weather in london?"
    print(f"User Query: {query}")
    content = types.Content(role='user', parts=[types.Part(text=query)])

    # The runner's run method handles the async loop internally
    events = runner.run(user_id=USER_ID, session_id=SESSION_ID, new_message=content)

    for event in events:
        if event.is_final_response():
            final_response = event.content.parts[0].text
            print("Agent Response:", final_response)
```

--------------------------------

### Initialize LlmRequest.Builder in Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/models/LlmRequest.Builder

Creates a new instance of the LlmRequest.Builder class. This is the starting point for constructing an LlmRequest object using the builder pattern. The constructor initializes an empty builder that can be configured with various LLM parameters.

```java
LlmRequest.Builder builder = new LlmRequest.Builder();
```

--------------------------------

### Sample LLM Request Log Output

Source: https://google.github.io/adk-docs/observability/logging

Example of a DEBUG level log entry showing an LLM request with system instructions, conversation history, and available functions. This format demonstrates the complete prompt structure sent to the Gemini model, including system instructions, user/model message exchanges, and function definitions.

```text
2025-07-10 15:26:13,778 - DEBUG - google_adk.google.adk.models.google_llm - Sending out request, model: gemini-2.0-flash, backend: GoogleLLMVariant.GEMINI_API, stream: False
2025-07-10 15:26:13,778 - DEBUG - google_adk.google.adk.models.google_llm -
LLM Request:
-----------------------------------------------------------
System Instruction:

      You roll dice and answer questions about the outcome of the dice rolls.
      You can roll dice of different sizes.
      You can use multiple tools in parallel by calling functions in parallel(in one request and in one round).
      It is ok to discuss previous dice roles, and comment on the dice rolls.
      When you are asked to roll a die, you must call the roll_die tool with the number of sides. Be sure to pass in an integer. Do not pass in a string.
      You should never roll a die on your own.
      When checking prime numbers, call the check_prime tool with a list of integers. Be sure to pass in a list of integers. You should never pass in a string.
      You should not check prime numbers before calling the tool.
      When you are asked to roll a die and check prime numbers, you should always make the following two function calls:
      1. You should first call the roll_die tool to get a roll. Wait for the function response before calling the check_prime tool.
      2. After you get the function response from roll_die tool, you should call the check_prime tool with the roll_die result.
        2.1 If user asks you to check primes based on previous rolls, make sure you include the previous rolls in the list.
      3. When you respond, you must include the roll_die result from step 1.
      You should always perform the previous 3 steps when asking for a roll and checking prime numbers.
      You should not rely on the previous history on prime results.


You are an agent. Your internal name is "hello_world_agent".

The description about you is "hello world agent that can roll a dice of 8 sides and check prime numbers."
-----------------------------------------------------------
Contents:
{"parts":[{"text":"Roll a 6 sided dice"}],"role":"user"}
{"parts":[{"function_call":{"args":{"sides":6},"name":"roll_die"}}],"role":"model"}
{"parts":[{"function_response":{"name":"roll_die","response":{"result":2}}}],"role":"user"}
-----------------------------------------------------------
Functions:
roll_die: {'sides': {'type': <Type.INTEGER: 'INTEGER'>}}
check_prime: {'nums': {'items': {'type': <Type.INTEGER: 'INTEGER'>}, 'type': <Type.ARRAY: 'ARRAY'>}}
-----------------------------------------------------------
```

--------------------------------

### GET /get - List all pets

Source: https://google.github.io/adk-docs/tools-custom/openapi-tools

Retrieves a simulated list of all pets from the store. This endpoint uses httpbin's /get endpoint which echoes back query parameters. Supports optional filtering by limit and status.

```APIDOC
## GET /get

### Description
Simulates returning a list of pets from the store. Uses httpbin's /get endpoint which echoes query parameters to demonstrate API integration.

### Method
GET

### Endpoint
/get

### Parameters
#### Query Parameters
- **limit** (integer, int32) - Optional - Maximum number of pets to return
- **status** (string, enum) - Optional - Filter pets by status. Allowed values: "available", "pending", "sold"

### Request Example
```
GET /get?limit=10&status=available
```

### Response
#### Success Response (200)
- **type** (object) - A list of pets echoed as query parameters

#### Response Example
```json
{
  "args": {
    "limit": "10",
    "status": "available"
  },
  "headers": {},
  "origin": "0.0.0.0",
  "url": "https://httpbin.org/get?limit=10&status=available"
}
```
```

--------------------------------

### Initialize Agent with Tool and Run in Java

Source: https://google.github.io/adk-docs/tools/function-tools

Creates a summary agent and root agent with tool integration using Google ADK Java library. The root agent is configured to delegate summarization tasks to the summary agent tool. Demonstrates session creation, message handling, and event streaming for asynchronous agent execution.

```java
public static void initAgentAndRun(String prompt) {

    LlmAgent summaryAgent =
        LlmAgent.builder()
            .model("gemini-2.0-flash")
            .name("summaryAgent")
            .instruction(
                "You are an expert summarizer. Please read the following text and provide a concise summary.")
            .description("Agent to summarize text")
            .build();

    // Define root_agent
    LlmAgent rootAgent =
        LlmAgent.builder()
            .model("gemini-2.0-flash")
            .name("rootAgent")
            .instruction(
                "You are a helpful assistant. When the user provides a text, always use the 'summaryAgent' tool to generate a summary. Always forward the user's message exactly as received to the 'summaryAgent' tool, without modifying or summarizing it yourself. Present the response from the tool to the user.")
            .description("Assistant agent")
            .tools(AgentTool.create(summaryAgent, true)) // Set skipSummarization to true
            .build();

    // Create an InMemoryRunner
    InMemoryRunner runner = new InMemoryRunner(rootAgent, APP_NAME);
    // InMemoryRunner automatically creates a session service. Create a session using the service
    Session session = runner.sessionService().createSession(APP_NAME, USER_ID).blockingGet();
    Content userMessage = Content.fromParts(Part.fromText(prompt));

    // Run the agent
    Flowable<Event> eventStream = runner.runAsync(USER_ID, session.id(), userMessage);

    // Stream event response
    eventStream.blockingForEach(
        event -> {
          if (event.finalResponse()) {
            System.out.println(event.stringifyContent());
          }
        });
}
```

--------------------------------

### Get Events from Session

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/events/class-use/Event

Retrieves the list of events from a Session object or ListEventsResponse. Session.events() returns a mutable List while ListEventsResponse.events() returns an immutable ImmutableList.

```java
List<Event> Session.events()
abstract com.google.common.collect.ImmutableList<Event> ListEventsResponse.events()
```

--------------------------------

### Get Java Instruction.Provider Instruction Component

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/Instruction.Provider

This method returns the value of the `getInstruction` record component. This component is a `Function` that, when applied, provides a `Single<String>` based on a `ReadonlyContext`. It allows for dynamic instruction generation.

```java
public Function<ReadonlyContext, io.reactivex.rxjava3.core.Single<String>> getInstruction()
```

--------------------------------

### Run ADK Agent as API Server

Source: https://google.github.io/adk-docs/agents/config

Terminal command to start the ADK agent as a service that can be accessed by other applications through API calls. This mode enables integration of the agent into larger systems and applications.

```bash
adk api_server
```

--------------------------------

### Get and Set Event Actions - Java

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/events/Event

Getter and setter methods for managing EventActions associated with this event. Actions define what operations or behaviors are triggered by the event.

```java
public EventActions actions()
public void setActions(EventActions actions)
```

--------------------------------

### Initialize Atlassian MCP Server Agent

Source: https://google.github.io/adk-docs/tools/third-party/atlassian

Set up an ADK agent with the Atlassian MCP Server to enable integration with Jira and Confluence. This example demonstrates local MCP server configuration using OAuth authentication.

```APIDOC
## Agent Initialization

### Description
Initialize an ADK agent with Atlassian MCP Server connection for accessing Jira issues, managing documentation, and searching across Atlassian products.

### Setup

#### Python Implementation
```python
from google.adk.agents import Agent
from google.adk.tools.mcp_tool import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters

root_agent = Agent(
    model="gemini-2.5-pro",
    name="atlassian_agent",
    instruction="Help users work with data in Atlassian products",
    tools=[
        McpToolset(
            connection_params=StdioConnectionParams(
                server_params=StdioServerParameters(
                    command="npx",
                    args=[
                        "-y",
                        "mcp-remote",
                        "https://mcp.atlassian.com/v1/sse",
                    ]
                ),
                timeout=30,
            ),
        )
    ],
)
```

### Authentication
- On first run, a browser window opens automatically to request OAuth access
- Alternatively, use the authorization URL printed in the console
- User approval is required to grant agent access to Atlassian data

### Configuration Parameters
- **model** (string) - AI model identifier (e.g., "gemini-2.5-pro")
- **name** (string) - Agent identifier name
- **instruction** (string) - System instruction for agent behavior
- **timeout** (integer) - Connection timeout in seconds (default: 30)
```

--------------------------------

### Get EventActions from CallbackContext

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/CallbackContext

Retrieves the EventActions object associated with the current CallbackContext. This object provides methods to trigger various event-related actions during an agent's execution.

```java
public EventActions eventActions()
```

--------------------------------

### Initialize LlmAgent with MCPToolset for Google Maps - TypeScript

Source: https://google.github.io/adk-docs/tools-custom/mcp-tools

Creates a TypeScript LlmAgent configured with MCPToolset to access Google Maps tools. The agent requires a GOOGLE_MAPS_API_KEY environment variable and initializes a stdio connection to the @modelcontextprotocol/server-google-maps MCP server. This enables the agent to handle mapping, directions, and place-finding queries.

```typescript
import 'dotenv/config';
import {LlmAgent, MCPToolset} from "@google/adk";

// Retrieve the API key from an environment variable.
// Ensure this environment variable is set in the terminal where you run 'adk web'.
// Example: export GOOGLE_MAPS_API_KEY="YOUR_ACTUAL_KEY"
const googleMapsApiKey = process.env.GOOGLE_MAPS_API_KEY;
if (!googleMapsApiKey) {
    throw new Error('GOOGLE_MAPS_API_KEY is not provided, please run "export GOOGLE_MAPS_API_KEY=YOUR_ACTUAL_KEY" to add that.');
}

export const rootAgent = new LlmAgent({
    model: "gemini-2.5-flash",
    name: "maps_assistant_agent",
    instruction: "Help the user with mapping, directions, and finding places using Google Maps tools.",
    tools: [
        new MCPToolset(
            {
                type: "StdioConnectionParams",
                serverParams: {
                    command: "npx",
                    args: [
                        "-y",
                        "@modelcontextprotocol/server-google-maps",
                    ],
                    // Pass the API key as an environment variable to the npx process
                    // This is how the MCP server for Google Maps expects the key.
                    env: {
                        "GOOGLE_MAPS_API_KEY": googleMapsApiKey
                    }
                },
            },
            // You can filter for specific Maps tools if needed:
            // ['get_directions', 'find_place_by_id']
        )
    ],
});
```

--------------------------------

### Run Agent-as-Tool Simulation

Source: https://google.github.io/adk-docs/tools/function-tools

Demonstrates the pattern of wrapping an agent as a tool for use by another agent. Creates a summarizer agent, wraps it in an AgentTool, provides it to a main agent, and executes a prompt requesting text summarization.

```Go
func RunAgentAsToolSimulation() {
    ctx := context.Background()

    summarizerAgent, err := createSummarizerAgent(ctx)
    if err != nil {
        log.Fatalf("Failed to create summarizer agent: %v", err)
    }

    summarizeTool := agenttool.New(summarizerAgent, &agenttool.Config{
        SkipSummarization: true,
    })

    mainAgent, err := createMainAgent(ctx, summarizeTool)
    if err != nil {
        log.Fatalf("Failed to create main agent: %v", err)
    }

    prompt := `
        Please summarize this text for me:
        Quantum computing represents a fundamentally different approach to computation,
        leveraging the bizarre principles of quantum mechanics to process information. Unlike classical computers
        that rely on bits representing either 0 or 1, quantum computers use qubits which can exist in a state of superposition - effectively
        being 0, 1, or a combination of both simultaneously. Furthermore, qubits can become entangled,
        meaning their fates are intertwined regardless of distance, allowing for complex correlations. This parallelism and
        interconnectedness grant quantum computers the potential to solve specific types of incredibly complex problems - such
        as drug discovery, materials science, complex system optimization, and breaking certain types of cryptography - far
        faster than even the most powerful classical supercomputers could ever achieve, although the technology is still largely in its developmental stages.
    `
    fmt.Printf("\nPrompt: %s\nResponse: ", prompt)
    callAgent(context.Background(), mainAgent, prompt)
    fmt.Println("\n---")
}
```

--------------------------------

### beforeRunnerCallback - Execute code before runner invocation

Source: https://google.github.io/adk-docs/api-reference/typescript/classes/SecurityPlugin

Callback executed before the runner starts processing. Useful for initialization, logging, or halting execution early. Receives the full invocation context containing session information and root agent details.

```typescript
beforeRunnerCallback(
  invocationContext: { invocationContext: InvocationContext }
): Promise<Content | undefined>
```

--------------------------------

### Get and Set Agent Description in BaseAgentConfig

Source: https://google.github.io/adk-docs/api-reference/java/com/google/adk/agents/BaseAgentConfig

Provides getter and setter methods for managing the agent's description property. The description() method retrieves the current description as a String, while setDescription() updates it with a new String value.

```java
public String description()

public void setDescription(String description)
```

--------------------------------

### Manage Agent Session: Get or Create (Python)

Source: https://google.github.io/adk-docs/streaming/dev-guide/part1

This Python code snippet demonstrates how to robustly obtain an agent session, handling both new conversations and reconnections. It first attempts to retrieve an existing session and, if none is found, proceeds to create a new one. This pattern ensures idempotency and is crucial before calling `runner.run_live()` to avoid `ValueError`.

```python
session = await session_service.get_session(
    app_name=APP_NAME,
    user_id=user_id,
    session_id=session_id
)
if not session:
    await session_service.create_session(
        app_name=APP_NAME,
        user_id=user_id,
        session_id=session_id
    )
```

--------------------------------

### Retrieve Credentials After Authentication in Python and TypeScript

Source: https://google.github.io/adk-docs/tools-custom

Get the credentials provided by the user after successful authentication flow. Call this method in subsequent tool invocations after request_credential was successfully handled to access the authenticated credentials.

```Python
# Retrieve credentials after successful authentication
auth_response = tool_context.get_auth_response()
# Use auth_response for API calls
```

```TypeScript
// Retrieve credentials after successful authentication
const authResponse = toolContext.getAuthResponse(authConfig);
// Use authResponse for API calls
```

--------------------------------

### Import Modules for ADK Context Window Compression (Python)

Source: https://google.github.io/adk-docs/streaming/dev-guide/part4

This Python snippet shows the essential import statements required to configure context window compression using the ADK framework. It brings in `types` from `google.genai` and `RunConfig` from `google.adk.agents.run_config`, which are foundational for setting compression parameters like `trigger_tokens` and `target_tokens` for Live API interactions.

```python
from google.genai import types
from google.adk.agents.run_config import RunConfig
```