### start()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-core/com.google.adk.kt.runners/-repl-runner/index.html

Starts the REPL runner.

```APIDOC
### start

```kotlin
fun start()
```

Starts the REPL runner execution loop.
```

--------------------------------

### Start Google ADK Web UI with Maven in Java

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/application-integration.md

Installs dependencies and executes AdkWebServer via Maven. Access the interface at http://localhost:8000 after running.

```bash
          mvn install

          mvn exec:java \
              -Dexec.mainClass="com.google.adk.web.AdkWebServer" \
              -Dexec.args="--adk.agents.source-dir=src/main/java" \
              -Dexec.classpathScope="compile"
```

--------------------------------

### Example build()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/Example.Builder.html

Constructs and returns the configured Example instance based on the provided input and output settings.

```APIDOC
## Example build()

### Description
Builds and returns the final `Example` instance.

### Method Signature
`public abstract Example build()`

### Returns
- `Example` - The constructed `Example` instance.
```

--------------------------------

### fun start()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-core/com.google.adk.kt.runners/-repl-runner/start.html

Starts the ReplRunner. This function takes no parameters and executes the REPL runner for commonJvmAndroid targets.

```APIDOC
## ReplRunner.start

### Description
Starts the REPL runner execution.

### Signature
```kotlin
fun start()
```

### Platform Target
- `commonJvmAndroid`

### Parameters
None.

### Return Value
- `Unit`
```

--------------------------------

### addExample(Example)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Adds an example to the ExampleTool configuration.

```APIDOC
## addExample(Example)

### Description
Appends an example to the tool.

### Method
- `addExample(com.google.adk.examples.Example example)`

### Parameters
- **example** (Example) - The example instance to add.
```

--------------------------------

### Install Agents CLI with pipx

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/agents-cli.md

Alternative installation method using pipx to install google-agents-cli and run the initial setup.

```shell
pipx install google-agents-cli && agents-cli setup
```

--------------------------------

### Install ADK module using go get

Source: https://github.com/google/adk-docs/blob/main/docs/_includes/homepage/_hero.md

Download and install the Google ADK module for Go projects.

```shell
go get google.golang.org/adk/v2
```

--------------------------------

### Install Agents CLI with pip

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/agents-cli.md

Alternative installation method using pip to install google-agents-cli and run the initial setup.

```shell
pip install google-agents-cli && agents-cli setup
```

--------------------------------

### Install frontend dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/copilotkit.md

Installs CopilotKit, AG-UI client, Hono, and Zod packages into the web application.

```bash
npm install @copilotkit/react-core @copilotkit/runtime @ag-ui/client hono zod
```

--------------------------------

### fun start(wait: Boolean = false)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-webserver/com.google.adk.kt.webserver/-adk-api-server/start.html

Starts the AdkApiServer. Configures whether the call blocks until server shutdown.

```APIDOC
## fun start(wait: Boolean = false)

### Description
Starts the ADK API server instance.

### Signature
```kotlin
fun start(wait: Boolean = false)
```

### Parameters
- **wait** (`Boolean`) - Optional (default: `false`) - Whether to wait for the server to stop before returning.
```

--------------------------------

### Run the A2A Consuming Agent Example

Source: https://github.com/google/adk-docs/blob/main/examples/go/a2a_basic/README.md

Execute the consuming agent with `go run main.go` after starting the A2A serving agent on port 8001. The output shows delegation logs from the mock LLM for rolling dice and prime checking.

```bash
go run main.go
```

```text
--- Example Interaction ---
User: Roll a 6-sided die and check if it's prime
Bot calls tool: roll_dice with args: map[sides:6]
Bot calls tool: prime_checking with args: map[nums:[<roll_result>]]
Bot: I can roll dice or check prime numbers. What would you like?
```

--------------------------------

### fun start(wait: Boolean = false)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-webserver/com.google.adk.kt.webserver.dev/-adk-dev-server/index.html

Starts the development server instance. Optionally blocks the current thread until the server stops.

```APIDOC
## fun start

### Description
Starts the AdkDevServer instance.

### Signature
```kotlin
fun start(wait: Boolean = false)
```

### Parameters
- **wait** (`Boolean`, optional, default: `false`) - If true, blocks the calling thread until the server terminates.
```

--------------------------------

### Embed full.NewLauncher in Go and start the web interface

Source: https://github.com/google/adk-docs/blob/main/docs/runtime/web-interface/index.md

Embed the launcher in main.go to bundle the web server, REST API, and Web UI into a single binary. Pass the web, api, and webui subcommands on the command line to start the server.

```go
import (
    "google.golang.org/adk/v2/cmd/launcher"
    "google.golang.org/adk/v2/cmd/launcher/full"
)

func main() {
    // ... build your agent and config ...
    l := full.NewLauncher()
    if err := l.Execute(ctx, config, os.Args[1:]); err != nil {
        log.Fatalf("Run failed: %v\n\n%s", err, l.CommandLineSyntax())
    }
}
```

```shell
go run agent.go web api webui
```

--------------------------------

### BaseExampleProvider.getExamples(String query)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/BaseExampleProvider.html

Retrieves a list of Example objects for a specified query string.

```APIDOC
## BaseExampleProvider.getExamples

### Description
Provides examples for a given query.

### Syntax
```java
List<Example> getExamples(String query)
```

### Parameters
- **query** (`String`) - The input query string to find examples for.

### Returns
- `List<Example>` - A list of examples corresponding to the provided query.
```

--------------------------------

### Install Restate SDK for Python

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/restate.md

Install the Restate SDK with serialization and deserialization support using pip.

```bash
pip install "restate-sdk[serde]"
```

--------------------------------

### ExampleTool.Builder addExample(Example ex)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Adds an example to the ExampleTool configuration. Returns the builder instance to support method chaining.

```APIDOC
### Method
`public ExampleTool.Builder addExample(Example ex)`

### Description
Adds an individual `Example` instance to the tool definition.

### Parameters
- **ex** (`com.google.adk.examples.Example`) - The example instance to add.

### Returns
- **ExampleTool.Builder** - The current builder instance for method chaining.
```

--------------------------------

### Clone Restate ADK example repository

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/restate.md

Clone the example repository and change directory to the hello-world agent project.

```bash
git clone https://github.com/restatedev/restate-google-adk-example.git
cd restate-google-adk-example/examples/hello-world
```

--------------------------------

### Install Synap ADK integration packages

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/synap.md

Install the maximem-synap-google-adk plugin and maximem-synap SDK using pip.

```bash
pip install maximem-synap-google-adk maximem-synap
```

--------------------------------

### Install dbos-google-adk

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/dbos.md

Install the DBOS integration package for Google ADK using pip.

```bash
pip install dbos-google-adk
```

--------------------------------

### static void start(BaseAgent... agents)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/web/AdkWebServer.html

Starts the ADK Web Server hosting the provided agent instances. This serves as the primary method to launch the web interface with configured agents.

```APIDOC
## static void start(BaseAgent... agents)

### Description
Starts the ADK web server hosting the specified agent instances.

### Signature
`public static void start(BaseAgent... agents)`

### Parameters
- **agents** (`BaseAgent...`) - Variable argument list of `BaseAgent` instances to run on the server.
```

--------------------------------

### Navigate to the a2a_basic sample directory

Source: https://github.com/google/adk-docs/blob/main/docs/a2a/quickstart-exposing-go.md

Navigate into the sample directory before running the A2A basic example.

```bash
cd examples/go/a2a_basic
```

--------------------------------

### ExampleUtils.buildExampleSi(BaseExampleProvider, String)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/ExampleUtils.html

Builds a formatted few-shot example string for the given query. This output is designed to be used in system instructions for few-shot prompting.

```APIDOC
## ExampleUtils.buildExampleSi

### Description
Builds a formatted few-shot example string for the given query. The string can be used for system instructions (i.e., the method name means "Build Example System Instructions").

### Method Signature
`public static String buildExampleSi(BaseExampleProvider exampleProvider, String query)`

### Parameters
- **exampleProvider** (`BaseExampleProvider`) - Source of examples.
- **query** (`String`) - User query.

### Returns
- **String** - Formatted string containing few-shot examples.
```

--------------------------------

### Navigate to tutorial directory and launch interactive UI with adk web

Source: https://github.com/google/adk-docs/blob/main/examples/python/tutorial/agent_team/adk_tutorial/README.md

Navigate to the parent tutorial directory containing step folders and start a local interactive web server interface.

```bash
# Make sure you are in the main 'adk_tutorial' folder
cd /path/to/your/adk_tutorial
```

```bash
adk web
```

--------------------------------

### Install cisco-aidefense-google-adk package

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/cisco-ai-defense.md

Install the Cisco AI Defense ADK integration package via pip.

```bash
pip install cisco-aidefense-google-adk
```

--------------------------------

### Navigate to the A2A server sample directory

Source: https://github.com/google/adk-docs/blob/main/docs/a2a/quickstart-exposing-java.md

Switch to the sample project folder located within the adk-java repository before starting the server.

```bash
cd contrib/samples/a2a_server
```

--------------------------------

### beforeRun

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-core/com.google.adk.kt.plugins/-plugin/index.html

Callback executed before the ADK runner starts the main execution loop. Enables initial validation and setup.

```APIDOC
### beforeRun

```kotlin
open suspend fun beforeRun(invocationContext: InvocationContext): CallbackChoice<Unit, Content>
```

#### Description
Callback executed before the ADK runner starts the main execution loop.

#### Parameters
- **invocationContext** (`InvocationContext`) - The invocation context for the upcoming run.

#### Return Value
- `CallbackChoice<Unit, Content>` - The callback choice determining whether to continue execution.
```

--------------------------------

### Install ADK and LiteLLM dependencies

Source: https://github.com/google/adk-docs/blob/main/examples/python/tutorial/agent_team/adk_tutorial/README.md

Installs the required `google-adk` package and `litellm` for multi-model support.

```bash
pip install google-adk
pip install litellm
```

--------------------------------

### Install traceai-google-adk via pip

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/future-agi.md

Install the traceai-google-adk instrumentation package. Runtime dependencies google-adk and google-genai are installed transitively.

```bash
pip install traceai-google-adk
```

--------------------------------

### Install Respan SDK and ADK instrumentation packages

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/respan.md

Install the Respan SDK, ADK instrumentation wrapper, and Google ADK with extensions using pip.

```bash
pip install respan-ai respan-instrumentation-google-adk "google-adk[extensions]"
```

--------------------------------

### public static Example.Builder builder()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/Example.html

Creates and returns a new Builder instance to construct an Example object.

```APIDOC
### Method Signature
```java
public static Example.Builder builder()
```

### Description
Creates a new builder instance for constructing an `Example`.

### Returns
- **Example.Builder** - A new builder instance.
```

--------------------------------

### main(String[] args)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tutorials/LiveAudioSingleAgent.html

Main entry point for running the LiveAudioSingleAgent tutorial application.

```APIDOC
### Method Signature
`public static void main(String[] args)`

### Description
Executes the LiveAudioSingleAgent application.

### Parameters
- **args** (`String[]`) - Command-line arguments passed to the program.
```

--------------------------------

### Install Google ADK package

Source: https://github.com/google/adk-docs/blob/main/examples/python/notebooks/shop_agent.ipynb

Upgrades and installs the Google ADK library in a notebook environment.

```python
%pip install --upgrade google-adk==1.4.2 -q
```

--------------------------------

### Install the A2UI Agent SDK

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/a2ui.md

Install the official A2UI Agent SDK package using pip.

```bash
pip install a2ui-agent-sdk

```

--------------------------------

### Install LangWatch and ADK packages

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/langwatch.md

Installs the LangWatch SDK, OpenInference instrumentation for Google ADK, and the core ADK library via pip.

```bash
pip install langwatch openinference-instrumentation-google-adk google-adk
```

--------------------------------

### Install ADK and OpenTelemetry dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/weave.md

Install google-adk and the required OpenTelemetry SDK and OTLP HTTP exporter packages.

```bash
pip install google-adk opentelemetry-sdk opentelemetry-exporter-otlp-proto-http
```

--------------------------------

### new ExampleTool(examples)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/typescript/classes/ExampleTool.html

Constructs a new instance of ExampleTool. This tool mutates outgoing LLM requests by appending few-shot instructions built from the user query.

```APIDOC
## new ExampleTool(examples)

### Description
Creates an instance of `ExampleTool` to add few-shot examples to the LLM request. Executed for each LLM request and mutates the outgoing request by appending few-shot instructions.

### Syntax
```typescript
new ExampleTool(examples: BaseExampleProvider | Example[]): ExampleTool
```

### Parameters
- **examples** (`BaseExampleProvider | Example[]`) - Required. An example provider or array of examples to include in the LLM request.

### Returns
- `ExampleTool` - A new ExampleTool instance.
```

--------------------------------

### build()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Constructs and returns the configured ExampleTool instance.

```APIDOC
## build()

### Description
Builds and returns the ExampleTool instance based on the builder's configuration.

### Method
- `build()`

### Returns
- Returns an instantiated `ExampleTool` object.
```

--------------------------------

### beforeRunCallback(InvocationContext invocationContext)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/plugins/ContextFilterPlugin.html

Callback executed before the ADK runner starts executing. Allows setup or prepending content to the invocation context.

```APIDOC
### Method Signature
`default io.reactivex.rxjava3.core.Maybe<com.google.genai.types.Content> beforeRunCallback(InvocationContext invocationContext)`

### Description
Callback executed before the ADK runner runs.

### Parameters
- **invocationContext** (`InvocationContext`) - The context for the runner invocation.

### Returns
- `io.reactivex.rxjava3.core.Maybe<com.google.genai.types.Content>` - An optional content object to be processed before the run starts.
```

--------------------------------

### Install freeplay-python-adk Library

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/freeplay.md

Install the Freeplay ADK integration package via pip.

```shell
pip install freeplay-python-adk
```

--------------------------------

### Install Google ADK

Source: https://github.com/google/adk-docs/blob/main/examples/python/notebooks/express-mode-weather-agent.ipynb

Installs the `google-adk` package using pip in quiet mode.

```python
# Setup and Installation
# Install ADK

!pip install google-adk -q

print("Installation complete.")
```

--------------------------------

### Install Zespan SDK and ADK with pip

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/zespan.md

Install the Zespan SDK and Google ADK packages for Python environments.

```bash
pip install zespan google-adk
```

--------------------------------

### StdioServerParameters.command()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/mcp/StdioServerParameters.html

Returns the command to execute for starting the stdio server process.

```APIDOC
### Method Signature
```java
public abstract String command()
```

### Description
The command to execute for the stdio server.

### Return Value
- **Type**: `String`
- **Description**: The executable command string.
```

--------------------------------

### ExampleTool.Builder()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Initializes a new instance of ExampleTool.Builder.

```APIDOC
## Constructor: ExampleTool.Builder()

### Description
Constructs a new Builder instance for ExampleTool.
```

--------------------------------

### Define ADK Agent with Tool in my_agent/agent.py

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/galileo.md

Defines an Agent instance with a tool to get the current time. Place this definition in my_agent/agent.py following the OpenTelemetry exporter and tracer provider setup.

```python
# my_agent/agent.py

from google.adk.agents import Agent

def get_current_time(city: str) -> dict:
    """Returns the current time in a specified city."""
    return {"status": "success", "city": city, "time": "10:30 AM"}


root_agent = Agent(
    model="gemini-flash-latest",
    name="root_agent",
    description="Tells the current time in a specified city.",
    instruction=(
        "You are a helpful assistant that tells the current time in cities. "
        "Use the 'get_current_time' tool for this purpose."
    ),
    tools=[get_current_time],
)

```

--------------------------------

### fun start(wait: Boolean = false)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-webserver/com.google.adk.kt.webserver/-adk-api-server/index.html

Starts the ADK API server runtime. Safe to invoke from different threads.

```APIDOC
### Signature
```kotlin
fun start(wait: Boolean = false)
```

### Description
Starts the server. Safe to call from different threads. A `stop()` arriving while `start()` is still binding aborts it, and a failed `start()` leaves the engine recorded, requiring `stop()` before retrying.

### Parameters
- **wait** (`Boolean`, optional) - Default is `false`. Whether to block until the server shuts down.
```

--------------------------------

### suspend override fun beforeAgent(context: CallbackContext): CallbackChoice<EventActions, Content>

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-core/com.google.adk.kt.interop/-base-future-plugin/before-agent.html

Callback executed before a specific agent starts processing. It can be used for logging, setup, or short-circuiting the agent's execution.

```APIDOC
## beforeAgent

### Description
Callback executed before a specific agent starts processing. This callback can be used for logging, setup, or short-circuiting the agent's execution.

### Signature
```kotlin
suspend override fun beforeAgent(context: CallbackContext): CallbackChoice<EventActions, Content>
```

### Parameters
- **context** (`CallbackContext`) - The context of the current agent call.

### Return Value
- **`CallbackChoice<EventActions, Content>`** - A `CallbackChoice` where returning `CallbackChoice.Break` with custom `Content` bypasses the agent's regular execution entirely and directly yields the provided content. Returning `CallbackChoice.Continue` with `EventActions` allows normal execution to proceed, merging any actions into the running context.
```

--------------------------------

### Install goodmem-adk package

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/goodmem.md

Install the GoodMem ADK integration package via pip.

```bash
pip install goodmem-adk

```

--------------------------------

### Configure project and install ADK dependencies with npm

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/typescript.md

Initializes an ES module package.json and installs @google/adk along with dev dependencies.

```console
cd my-agent/
# initialize a project as an ES module
npm init --yes
npm pkg set type="module"
npm pkg set main="agent.ts"
# install ADK libraries
npm install @google/adk
# install dev tools as a dev dependency
npm install -D @google/adk-devtools

```

--------------------------------

### Define ConversationScenario with starting prompt and plan

Source: https://github.com/google/adk-docs/blob/main/docs/evaluate/user-sim.md

Defines a basic ConversationScenario for dynamic user simulation with an agent. The LLM uses starting_prompt to begin and conversation_plan to guide dynamic prompt generation across conversation turns.

```json
{
  "starting_prompt": "What can you do for me?",
  "conversation_plan": "Ask the agent to roll a 20-sided die. After you get the result, ask the agent to check if it is prime."
}
```

--------------------------------

### public abstract Example.Builder toBuilder()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/Example.html

Creates a Builder initialized with the current properties of the Example instance.

```APIDOC
### Method Signature
```java
public abstract Example.Builder toBuilder()
```

### Description
Creates a builder pre-populated with the fields of this `Example` instance for modification.

### Returns
- **Example.Builder** - A builder instance initialized with the current object's values.
```

--------------------------------

### Install latitude-telemetry and google-adk

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/latitude.md

Install the Latitude OpenTelemetry instrumentation SDK and the Google ADK package via pip.

```bash
pip install latitude-telemetry google-adk
```

--------------------------------

### Install stackone-adk using pip

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/stackone.md

Installs the StackOne ADK integration package via pip.

```bash
pip install stackone-adk

```

--------------------------------

### Install Daytona ADK Plugin

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/daytona.md

Install the Daytona ADK integration package using pip.

```bash
pip install daytona-adk
```

--------------------------------

### Install ADK Toolbox client SDK module for Go

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/mcp-toolbox-for-databases.md

Installs the Go client module `github.com/googleapis/mcp-toolbox-sdk-go` for MCP Toolbox.

```shell
go get github.com/googleapis/mcp-toolbox-sdk-go
```

--------------------------------

### open suspend override fun beforeRun(invocationContext: InvocationContext): CallbackChoice<Unit, Content>

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/kotlin/google-adk-kotlin-core/com.google.adk.kt.plugins/-debug-logging-plugin/before-run.html

Callback executed before the ADK runner starts the main execution loop. It is the first callback invoked in the lifecycle, useful for inspecting, logging, setup tasks, or short-circuiting runner execution.

```APIDOC
### Signature
```kotlin
open suspend override fun beforeRun(
    invocationContext: InvocationContext
): CallbackChoice<Unit, Content>
```

### Description
Callback executed before the ADK runner starts the main execution loop. This is the first callback called in the lifecycle, ideal for global setup or initialization tasks. It provides an opportunity to inspect or log the invocation setup, or to short-circuit the run before it begins.

### Parameters
- **invocationContext** (`InvocationContext`) - The context for the entire invocation, containing session information, the root agent, etc.

### Return Value
- **CallbackChoice<Unit, Content>** - A `CallbackChoice` where returning `CallbackChoice.Break` with custom `Content` halts execution of the runner and resolves the invocation with that content directly. Returning `CallbackChoice.Continue` with `Unit` allows execution to proceed normally.
```

--------------------------------

### Install Zespan SDK and ADK with npm

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/zespan.md

Install the Zespan SDK and Google ADK packages for TypeScript or Node.js environments.

```bash
npm install @zespan/sdk @google/adk
```

--------------------------------

### Verify Python ADK installation

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/installation.md

Displays package details for google-adk to verify a successful installation.

```bash
pip show google-adk
```

--------------------------------

### ExampleTool.fromConfig

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/agents/class-use/ConfigAgentUtils.ConfigurationException.html

Creates an ExampleTool instance from provided tool argument configuration.

```APIDOC
## ExampleTool.fromConfig

### Description
Creates an ExampleTool instance from a tool arguments configuration.

### Signature
`static ExampleTool fromConfig(BaseTool.ToolArgsConfig args)`

### Parameters
- **args** (`BaseTool.ToolArgsConfig`) - Tool arguments configuration

### Returns
- `ExampleTool` - Configured ExampleTool instance

### Throws
- `ConfigAgentUtils.ConfigurationException` - If configuration resolution fails
```

--------------------------------

### Example.Builder output(List<Content> output)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/Example.Builder.html

Sets the list of output Content for the Example instance being constructed. Returns the builder instance for method chaining.

```APIDOC
## Example.Builder output(List<Content> output)

### Description
Sets the list of output content for the `Example` instance.

### Method Signature
`public abstract Example.Builder output(java.util.List<com.google.genai.types.Content> output)`

### Parameters
- **output** (`java.util.List<com.google.genai.types.Content>`) - The list of output content for the example.

### Returns
- `Example.Builder` - This builder instance.
```

--------------------------------

### ExampleTool.Builder exampleProvider(BaseExampleProvider provider)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Configures the example provider for the ExampleTool. Returns the builder instance for method chaining.

```APIDOC
### Method
`public ExampleTool.Builder exampleProvider(BaseExampleProvider provider)`

### Description
Sets the base example provider for the `ExampleTool`.

### Parameters
- **provider** (`com.google.adk.examples.BaseExampleProvider`) - The example provider instance.

### Returns
- **ExampleTool.Builder** - The current builder instance for method chaining.
```

--------------------------------

### Set up project directory structure

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/kotlin.md

Displays the required file and folder layout for an ADK Kotlin agent project.

```none
my_agent/
    src/main/kotlin/com/example/agent/
                        HelloTimeAgent.kt   # agent definition + tool
                        Main.kt             # entry point
    build.gradle.kts                        # project configuration
    .env                                    # API keys or project IDs
```

--------------------------------

### Start the backend server with uvicorn

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/copilotkit.md

Starts the FastAPI backend application on port 8000 with auto-reload enabled.

```bash
uvicorn agent:app --reload --port 8000
```

--------------------------------

### Install diagrid package

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/dapr.md

Install the Diagrid Agent package which provides the ADK extension for Dapr.

```bash
pip install diagrid
```

--------------------------------

### Start ADK Web UI

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/apigee-api-hub.md

Starts the ADK development web interface to test the agent locally at http://localhost:8000. Run this command from the project_root_folder.

```shell
# make sure to run `adk web` from your project_root_folder
adk web
```

--------------------------------

### static ExampleTool fromConfig(BaseTool.ToolArgsConfig args, String configAbsPath)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.html

Factory method to instantiate an ExampleTool from YAML tool configuration args and absolute config path.

```APIDOC
### Description
Factory method to instantiate an `ExampleTool` from YAML tool args.

### Signature
`public static ExampleTool fromConfig(BaseTool.ToolArgsConfig args, String configAbsPath)`

### Parameters
- **args** (`BaseTool.ToolArgsConfig`) - Tool argument configuration.
- **configAbsPath** (`String`) - The absolute path of the configuration file.

### Returns
- `ExampleTool` - The instantiated `ExampleTool`.
```

--------------------------------

### Aerospike connection URI examples

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/aerospike.md

Illustrates example connection strings for local single-node development and multi-node clusters with TLS and custom set prefix settings.

```text
aerospike://localhost:3000/adk
aerospike://user:pass@node1:3000,node2:3000/prod?set_prefix=prod_&tls=true
```

--------------------------------

### setExampleProvider(BaseExampleProvider) / exampleProvider(BaseExampleProvider)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/ExampleTool.Builder.html

Configures the BaseExampleProvider for the ExampleTool.

```APIDOC
## setExampleProvider(BaseExampleProvider) / exampleProvider(BaseExampleProvider)

### Description
Sets the example provider used by the tool.

### Methods
- `setExampleProvider(com.google.adk.examples.BaseExampleProvider exampleProvider)`
- `exampleProvider(com.google.adk.examples.BaseExampleProvider exampleProvider)`

### Parameters
- **exampleProvider** (BaseExampleProvider) - The example provider instance.
```

--------------------------------

### Install sprites-adk via pip

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/sprites.md

Install the Sprites ADK plugin package from PyPI.

```bash
pip install sprites-adk
```

--------------------------------

### Install ADK with Slack dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/slack.md

Installs the google-adk package along with necessary Slack Socket Mode dependencies.

```bash
pip install "google-adk[slack]"
```

--------------------------------

### Install Datadog Tracing Library

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/datadog.md

Install the required ddtrace package to enable Datadog tracing capabilities for ADK.

```bash
pip install ddtrace
```

--------------------------------

### Install backend dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/copilotkit.md

Installs the required Python packages for Google ADK, AG-UI integration, and FastAPI backend server.

```bash
pip install google-adk ag-ui-adk fastapi "uvicorn[standard]"
```

--------------------------------

### Install @google/adk using npm

Source: https://github.com/google/adk-docs/blob/main/docs/_includes/homepage/_hero.md

Install the Google ADK TypeScript and JavaScript package using npm.

```shell
npm install @google/adk
```

--------------------------------

### main(String[] args)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tutorials/CityTimeWeather.html

Main entry point for running the CityTimeWeather application. Executes the tutorial workflow.

```APIDOC
## main(String[] args)

### Description
Main method to run the tutorial application.

### Signature
`public static void main(String[] args)`

### Parameters
- **args** (`String[]`) - Command-line arguments passed to the application.
```

--------------------------------

### Install ADK extensions package

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/parameter-manager.md

Install the ADK extensions package to enable the Parameter Manager integration.

```bash
pip install "google-adk[extensions]"
```

--------------------------------

### new BaseExampleProvider()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/typescript/classes/BaseExampleProvider.html

Constructs an instance of BaseExampleProvider.

```APIDOC
## constructor

### Description
Creates an instance of BaseExampleProvider.

### Signature
`new BaseExampleProvider(): BaseExampleProvider`

### Returns
- **BaseExampleProvider** - An instance of the BaseExampleProvider class.
```

--------------------------------

### View ADK web server startup output in Go

Source: https://github.com/google/adk-docs/blob/main/docs/runtime/web-interface/index.md

Displays the console logs with URLs for the Web UI and API routes when starting the Go web server.

```shell
2025/01/01 00:00:00 Starting the web server: &{port:8080 ...}
2025/01/01 00:00:00 Web servers starts on http://localhost:8080
2025/01/01 00:00:00        webui:  you can access API using http://localhost:8080/ui/
2025/01/01 00:00:00        api:  you can access API using http://localhost:8080/api
```

--------------------------------

### initialize()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/tools/computeruse/BaseComputer.html

Initializes the BaseComputer instance and prepares the underlying environment. Must be invoked before issuing environment commands.

```APIDOC
### Method
`initialize()`

### Package
`com.google.adk.tools.computeruse.BaseComputer`

### Description
Initializes the computer environment.
```

--------------------------------

### Clone the ADK repository and navigate to tutorial directory

Source: https://github.com/google/adk-docs/blob/main/examples/python/tutorial/agent_team/adk_tutorial/README.md

Clones the `adk-docs` repository from GitHub and changes into the tutorial's project folder.

```bash
git clone https://github.com/google/adk-docs.git
cd adk-docs/examples/python/tutorial/agent_team/adk_tutorial/ # Navigate into the cloned directory
```

--------------------------------

### Install Temporal Python SDK with google-adk extra

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/temporal.md

Installs the Temporal Python SDK along with dependencies required for Google ADK integration.

```bash
pip install "temporalio[google-adk]"
```

--------------------------------

### public void execute()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/maven/WebMojo.html

Executes the Mojo to start the Google ADK Web Server with user-provided agents. The server dynamically loads specified agents and exposes them through the ADK Web UI.

```APIDOC
## public void execute()

### Description
Starts the Google ADK Web Server with user-provided agents for testing and interaction via the ADK Web UI.

### Configuration Parameters
- **agents** (String) - Required - Full class path to AgentLoader implementation (e.g., static field `com.example.MyProvider.INSTANCE` or class with default constructor `com.example.MyProvider`).
- **port** (int) - Optional (default: 8000) - Server port.
- **host** (String) - Optional (default: localhost) - Server host address.
- **hotReloading** (boolean) - Optional (default: true) - Enable hot reloading for config-based agents.
- **registry** (String) - Optional - Full class path to custom ComponentRegistry subclass for injecting customized tools and agents.

### Throws
- **org.apache.maven.plugin.MojoExecutionException** - If an error occurs during execution.
- **org.apache.maven.plugin.MojoFailureException** - If Mojo execution fails.
```

--------------------------------

### get userId(): string

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/typescript/classes/Context.html

Gets the user ID associated with the current session. Inherited from ReadonlyContext.

```APIDOC
## get userId(): string

### Description
The user ID of the current session.

### Type
Getter (Accessor)

### Returns
- **string** - The current session's user ID.
```

--------------------------------

### Create CLI entry point with ReplRunner in Main.kt

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/kotlin.md

Configures an interactive command-line REPL entry point for HelloTimeAgent using ReplRunner to manage input, responses, and tool confirmations.

```kotlin
package com.example.agent

import com.google.adk.kt.runners.ReplRunner

fun main() {
    ReplRunner(HelloTimeAgent.rootAgent).start()
}
```

--------------------------------

### Install google-adk with A2A dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/a2a/quickstart-exposing.md

Installs the google-adk package including the optional a2a extra dependencies.

```bash
pip install google-adk[a2a]
```

--------------------------------

### Embed launcher and start Go API server

Source: https://github.com/google/adk-docs/blob/main/docs/runtime/api-server.md

Embeds full.NewLauncher in main.go to bundle the REST API and Web UI, then launches the server with the web and api subcommands. Routes are registered under the /api prefix by default.

```go
import (
    "google.golang.org/adk/v2/cmd/launcher"
    "google.golang.org/adk/v2/cmd/launcher/full"
)

func main() {
    // ... build your agent and config ...
    l := full.NewLauncher()
    if err := l.Execute(ctx, config, os.Args[1:]); err != nil {
        log.Fatalf("Run failed: %v\n\n%s", err, l.CommandLineSyntax())
    }
}
```

```shell
go run agent.go web api
```

--------------------------------

### Install google-adk agent-identity extra package

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/agent-identity.md

Install the agent-identity extra package group to download the required client libraries.

```bash
pip install "google-adk[agent-identity]"
```

--------------------------------

### get sessionId(): string

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/typescript/classes/Context.html

Gets the ID of the current session in which the agent is running. Inherited from ReadonlyContext.

```APIDOC
## get sessionId(): string

### Description
The ID of the current session.

### Type
Getter (Accessor)

### Returns
- **string** - The session ID.
```

--------------------------------

### Start ADK Web Server with google-adk:web

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/maven/WebMojo.html

Executes the ADK web server Maven goal with a specified AgentLoader implementation. Once started, the web UI is accessible at http://host:port.

```bash
mvn google-adk:web -Dagents=com.example.MyAgentLoader
```

--------------------------------

### get invocationId(): string

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/typescript/classes/Context.html

Gets the unique identifier for the current agent invocation. Inherited from ReadonlyContext.

```APIDOC
## get invocationId(): string

### Description
The current invocation id.

### Type
Getter (Accessor)

### Returns
- **string** - The ID of the current invocation.
```

--------------------------------

### Install Anthropic Vertex Client Library

Source: https://github.com/google/adk-docs/blob/main/docs/agents/models/agent-platform.md

Install the required Anthropic client library configured for Agent Platform in your Python environment.

```shell
pip install "anthropic[vertex]"
```

--------------------------------

### Start FastAPI agent server with adk api_server

Source: https://github.com/google/adk-docs/blob/main/examples/python/tutorial/agent_team/adk_tutorial/README.md

Start a FastAPI server exposing the agent via an API endpoint.

```bash
# Make sure you are in the main 'adk_tutorial' folder
adk api_server
```

--------------------------------

### Install ADK and Aerospike integration packages

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/aerospike.md

Installs the ADK for Python and the Aerospike integration provider via pip.

```bash
pip install google-adk adk-aerospike
```

--------------------------------

### Install ADK with MCP extra

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/unstructured.md

Install google-adk with MCP support enabled. The extra is required to import ADK's MCP classes.

```bash
pip install "google-adk[mcp]"
```

--------------------------------

### Configure MCP Toolset and compose Agent in Go

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/agent-registry.md

Demonstrates connecting to an MCP server resource, creating a Gemini model, and executing a root agent with sub-agents and toolsets using the launcher.

```go
    	// 4. Using an MCP Toolset
    	// Replace with the full resource name of your registered MCP server
    	mcpServerName := fmt.Sprintf("projects/%s/locations/%s/mcpServers/YOUR_MCP_SERVER_ID", projectID, location)
    	myMCPToolset, err := registry.MCPToolset(ctx, mcpServerName)
    	if err != nil {
    		log.Fatalf("Failed to connect to the MCP server: %v", err)
    	}

    	// 5. Example Agent Composition
    	model, err := gemini.NewModel(ctx, "gemini-flash-latest", &genai.ClientConfig{})
    	if err != nil {
    		log.Fatalf("Failed to create the model: %v", err)
    	}

    	rootAgent, err := llmagent.New(llmagent.Config{
    		Name:        "demo_agent",
    		Model:       model,
    		Instruction: "You can leverage registered tools and sub-agents.",
    		Toolsets:    []tool.Toolset{myMCPToolset},
    		SubAgents:   []agent.Agent{myRemoteAgent},
    	})
    	if err != nil {
    		log.Fatalf("Failed to create the agent: %v", err)
    	}

    	config := &launcher.Config{AgentLoader: agent.NewSingleLoader(rootAgent)}
    	l := full.NewLauncher()
    	if err := l.Execute(ctx, config, os.Args[1:]); err != nil {
    		log.Fatalf("Run failed: %v\n\n%s", err, l.CommandLineSyntax())
    	}
    }
```

--------------------------------

### Install Phoenix and Google ADK Instrumentation Packages

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/phoenix.md

Install the required Python packages for Google ADK and Arize Phoenix OpenTelemetry instrumentation.

```bash
pip install openinference-instrumentation-google-adk google-adk arize-phoenix-otel
```

--------------------------------

### FastAPI entry point using get_fast_api_app (main.py)

Source: https://github.com/google/adk-docs/blob/main/docs/deploy/cloud-run.md

Creates a FastAPI instance configured with the agent directory, SQLite async session store, and Cloud Run port handling.

```python
import os

import uvicorn
from fastapi import FastAPI
from google.adk.cli.fast_api import get_fast_api_app

# Get the directory where main.py is located
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
# Example session service URI, for example, SQLite
# Note: Use 'sqlite+aiosqlite' instead of 'sqlite' because DatabaseSessionService requires an async driver
SESSION_SERVICE_URI = "sqlite+aiosqlite:///./sessions.db"
# Example allowed origins for CORS
ALLOWED_ORIGINS = ["http://localhost", "http://localhost:8080", "*"]
# Set web=True if you intend to serve a web interface, False otherwise
SERVE_WEB_INTERFACE = True

# Call the function to get the FastAPI app instance
# Ensure the agent directory name ('capital_agent') matches your agent folder
app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    session_service_uri=SESSION_SERVICE_URI,
    allow_origins=ALLOWED_ORIGINS,
    web=SERVE_WEB_INTERFACE,
)

# You can add more FastAPI routes or configurations below if needed
# Example:
# @app.get("/hello")
# async def read_root():
#     return {"Hello": "World"}

if __name__ == "__main__":
    # Use the PORT environment variable provided by Cloud Run, defaulting to 8080
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
```

--------------------------------

### Deploy agent to Cloud Run with ADK CLI flags

Source: https://github.com/google/adk-docs/blob/main/docs/deploy/cloud-run.md

Example command demonstrating deployment to a specific project and region with authentication and instance scaling flags.

```bash
adk deploy cloud_run --project=[PROJECT_ID] --region=[REGION] path/to/my_agent    -- --no-allow-unauthenticated --min-instances=2
```

--------------------------------

### Verify project setup with mvn compile

Source: https://github.com/google/adk-docs/blob/main/docs/live/get-started/streaming-java.md

Run the compilation command to verify that Maven dependencies and project configurations are properly set up.

```shell
$ mvn compile
[INFO] Scanning for projects...
[INFO]
[INFO] --------------------< adk-agents:adk-agents >--------------------
[INFO] Building adk-agents 1.0-SNAPSHOT
[INFO]   from pom.xml
[INFO] --------------------------------[ jar ]---------------------------------
[INFO]
[INFO] --- resources:3.3.1:resources (default-resources) @ adk-demo ---
[INFO] skip non existing resourceDirectory /home/user/adk-demo/src/main/resources
[INFO]
[INFO] --- compiler:3.13.0:compile (default-compile) @ adk-demo ---
[INFO] Nothing to compile - all classes are up to date.
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  1.347 s
[INFO] Finished at: 2025-05-06T15:38:08Z
[INFO] ------------------------------------------------------------------------
```

--------------------------------

### Cloud Run service URL format example

Source: https://github.com/google/adk-docs/blob/main/docs/deploy/cloud-run.md

Example URL structure for accessing the deployed Cloud Run service web interface.

```bash
# Example URL format
# https://your-service-name-abc123xyz.a.run.app
```

--------------------------------

### Get session details via GET

Source: https://github.com/google/adk-docs/blob/main/docs/runtime/api-server.md

Retrieve current state and recorded events for a given session path.

```shell
curl -X GET http://localhost:8000/apps/my_sample_agent/users/u_123/sessions/s_abc
```

```json
{"id":"s_abc","appName":"my_sample_agent","userId":"u_123","state":{"visit_count":5},"events":[...],"lastUpdateTime":1743711430.022186}
```

--------------------------------

### Run Live Audio Run tool with Maven

Source: https://github.com/google/adk-docs/blob/main/docs/live/get-started/streaming-java.md

Execute this command in the adk-agents directory to start the tool. Once initialized, speak directly into the microphone; wear earphones if audio feedback causes the agent to loop.

```shell
mvn compile exec:java
```

```text
$ mvn compile exec:java
...
Initializing microphone input and speaker output...
Conversation started. Press Enter to stop...
Speaker initialized.
Microphone initialized. Start speaking...
```

--------------------------------

### Install adk-database-memory with database drivers

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/database-memory.md

Install the package along with the appropriate database driver extra. Choose the extra corresponding to your backend (SQLite via aiosqlite, PostgreSQL via asyncpg, or MySQL/MariaDB via aiomysql).

```bash
pip install "adk-database-memory[sqlite]"    # SQLite (via aiosqlite)
pip install "adk-database-memory[postgres]"  # PostgreSQL (via asyncpg)
pip install "adk-database-memory[mysql]"     # MySQL / MariaDB (via aiomysql)
```

--------------------------------

### Install adk-redis components and dependencies

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/redis.md

Install specific extras for session memory, search tools, SQL querying, LangCache semantic caching, or the RedisVL MCP server.

```bash
pip install 'adk-redis[memory]'      # session + long-term memory services
pip install 'adk-redis[search]'      # RedisVL-backed search tools
pip install 'adk-redis[sql]'         # RedisSQLSearchTool (sql-redis)
pip install 'adk-redis[langcache]'   # managed semantic cache provider
pip install 'adk-redis[all]'         # everything above

# For the RedisVL MCP server (used with ADK's native McpToolset):
pip install 'redisvl[mcp]>=0.18.2'
```

--------------------------------

### Test queries and launch playground with agents-cli

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/migrate.md

Runs a single prompt directly against the agent or starts the interactive web UI playground.

```bash
# Test a single prompt
agents-cli run "Look up customer cust_101 and apply a 10% discount on $100."

# Start the interactive web UI
agents-cli playground
```

--------------------------------

### static void main(String[] args)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/web/AdkWebServer.html

Serves as the main entry point for the Spring Boot application.

```APIDOC
## static void main(String[] args)

### Description
Main entry point for the Spring Boot application.

### Signature
`public static void main(String[] args)`

### Parameters
- **args** (`String[]`) - Command-line arguments passed to the application.
```

--------------------------------

### Install ADK connector package via pip

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/adk-connector.md

Installs the Python connector package for ADK projects.

```bash
pip install adk-connector
```

--------------------------------

### init(PlanningContext)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/planner/LoopPlanner.html

Initializes the LoopPlanner with the provided planning context. Prepares the planner state before action execution.

```APIDOC
### Method

```java
init(com.google.adk.agents.PlanningContext context)
```

#### Parameters
- `context` (`com.google.adk.agents.PlanningContext`) - The planning context for the agent.
```

--------------------------------

### Install google-adk using pip

Source: https://github.com/google/adk-docs/blob/main/docs/_includes/homepage/_hero.md

Install the Google ADK Python package using the pip package manager.

```shell
pip install google-adk
```

--------------------------------

### Verify Agents CLI installation with agents-cli info

Source: https://github.com/google/adk-docs/blob/main/docs/get-started/migrate.md

Checks and confirms the installation of Agents CLI and its configured skills.

```bash
agents-cli info
```

--------------------------------

### Example.Builder input(Content input)

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/examples/Example.Builder.html

Sets the input Content for the Example instance being constructed. Returns the builder instance for method chaining.

```APIDOC
## Example.Builder input(Content input)

### Description
Sets the input content for the `Example` instance.

### Method Signature
`public abstract Example.Builder input(com.google.genai.types.Content input)`

### Parameters
- **input** (`com.google.genai.types.Content`) - The input content for the example.

### Returns
- `Example.Builder` - This builder instance.
```

--------------------------------

### Start Python server with Pub/Sub trigger locally

Source: https://github.com/google/adk-docs/blob/main/docs/runtime/ambient-agents.md

Starts the local ADK API server with the Pub/Sub trigger enabled for the `event_processing_agent` app.

```bash
adk api_server --trigger_sources "pubsub" event_processing_agent
```

--------------------------------

### Install the MCP library using pip

Source: https://github.com/google/adk-docs/blob/main/docs/tools-custom/mcp-tools/agent-as-server.md

Installs the MCP Server library prerequisite in the ADK environment before building a custom MCP server for individual tools.

```bash
pip install mcp
```

--------------------------------

### Install adk-perseus-context

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/perseus.md

Install the Perseus context integration package using pip. Automatically includes the required perseus-ctx dependency.

```bash
pip install adk-perseus-context
```

--------------------------------

### build()

Source: https://github.com/google/adk-docs/blob/main/docs/api-reference/java/com/google/adk/models/ApigeeLlm.Builder.html

Constructs and returns the configured ApigeeLlm instance.

```APIDOC
### Method Signature
`public ApigeeLlm build()`

### Returns
- `ApigeeLlm` - The initialized ApigeeLlm instance.
```

--------------------------------

### Install Channels SDK packages for Slack

Source: https://github.com/google/adk-docs/blob/main/docs/integrations/copilotkit.md

Install the required CopilotKit bot packages to connect a Slack workspace directly to an ag-ui-adk endpoint without requiring the CopilotKit Runtime route.

```bash
npm install @copilotkit/bot @copilotkit/bot-slack @copilotkit/bot-ui
```