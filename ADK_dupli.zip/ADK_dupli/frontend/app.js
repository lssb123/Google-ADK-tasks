// ---------------------------------------------------------------------------
// ADK Multi-Agent Chatbot POC — frontend logic
// Streams Server-Sent Events from the FastAPI backend and renders the
// orchestrator's routing, each active agent, tool calls and the final answer.
// ---------------------------------------------------------------------------

// When served by FastAPI (StaticFiles) same-origin works. If you open the HTML
// directly, point this at your backend, e.g. "http://localhost:8000".
const API_BASE = "";

const form = document.getElementById("chat-form");
const input = document.getElementById("input");
const sendBtn = document.getElementById("send");
const messages = document.getElementById("messages");
const traceLog = document.getElementById("trace-log");

let sessionId = null;

// ---- Helpers --------------------------------------------------------------
function addMessage(text, who) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${who}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrap.appendChild(bubble);
  messages.appendChild(wrap);
  messages.scrollTop = messages.scrollHeight;
  return bubble;
}

function addRouteChip(label) {
  const chip = document.createElement("div");
  chip.className = "route-chip";
  chip.textContent = `Routed to ${label}`;
  messages.appendChild(chip);
  messages.scrollTop = messages.scrollHeight;
}

function clearTrace() {
  traceLog.innerHTML = "";
}

function addTrace(kind, head, body) {
  const item = document.createElement("div");
  item.className = `trace-item ${kind}`;
  const h = document.createElement("div");
  h.className = "ti-head";
  h.textContent = head;
  item.appendChild(h);
  if (body) {
    const b = document.createElement("div");
    b.className = "ti-body";
    b.textContent = body;
    item.appendChild(b);
  }
  traceLog.appendChild(item);
  traceLog.scrollTop = traceLog.scrollHeight;
}

function highlightNode(agentName) {
  document
    .querySelectorAll(".node")
    .forEach((n) => {
      if (n.dataset.agent === agentName) n.classList.add("active");
    });
}

function resetNodes() {
  document.querySelectorAll(".node").forEach((n) => n.classList.remove("active"));
}

// ---- SSE streaming --------------------------------------------------------
async function send(message) {
  addMessage(message, "user");
  clearTrace();
  resetNodes();
  sendBtn.disabled = true;
  input.value = "";

  // placeholder bot bubble with typing indicator
  const botBubble = addMessage("", "bot");
  botBubble.innerHTML =
    '<span class="typing"><span></span><span></span><span></span></span>';

  try {
    const res = await fetch(`${API_BASE}/api/chat/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: sessionId }),
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let finalized = false;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const parts = buffer.split("\n\n");
      buffer = parts.pop(); // keep incomplete chunk

      for (const part of parts) {
        const line = part.trim();
        if (!line.startsWith("data:")) continue;
        const json = line.slice(5).trim();
        if (!json) continue;
        const evt = JSON.parse(json);
        handleEvent(evt, botBubble);
        if (evt.type === "final") finalized = true;
      }
    }
    if (!finalized) botBubble.textContent = "(stream ended)";
  } catch (err) {
    botBubble.textContent = "⚠️ Error: " + err.message;
    addTrace("error", "Connection error", err.message);
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

function handleEvent(evt, botBubble) {
  switch (evt.type) {
    case "session":
      sessionId = evt.session_id;
      break;
    case "status":
      addTrace("status", "Status", evt.message);
      break;
    case "agent_selected":
      addTrace("agent", `Agent active: ${evt.label}`);
      highlightNode(evt.agent);
      addRouteChip(evt.label);
      break;
    case "tool_call":
      addTrace(
        "tool",
        `${evt.label} → 🛠 ${evt.tool}`,
        Object.keys(evt.args || {}).length
          ? JSON.stringify(evt.args)
          : ""
      );
      break;
    case "tool_result":
      addTrace("result", `${evt.label} ← ✅ ${evt.tool} returned`);
      break;
    case "thinking":
      addTrace("think", `${evt.label} thinking`, evt.text);
      break;
    case "final":
      botBubble.textContent = evt.text;
      messages.scrollTop = messages.scrollHeight;
      break;
    case "error":
      botBubble.textContent = "⚠️ " + evt.message;
      addTrace("error", "Error", evt.message);
      break;
    case "done":
      break;
  }
}

// ---- Events ---------------------------------------------------------------
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const msg = input.value.trim();
  if (msg) send(msg);
});

document.querySelectorAll(".hint").forEach((btn) => {
  btn.addEventListener("click", () => send(btn.textContent.trim()));
});
