"""Central configuration for the ADK POC backend."""
import os
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables from .env (if present)
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

# ---------------------------------------------------------------------------
# Model configuration
# ---------------------------------------------------------------------------
# Set MODEL_PROVIDER=litellm in .env to route every agent through a LiteLLM
# endpoint (any OpenAI-compatible provider: OpenAI, Azure, Ollama, vLLM,
# Together, Groq, a self-hosted LiteLLM proxy, etc.). Otherwise agents use
# Google Gemini directly.
MODEL_PROVIDER = os.getenv("MODEL_PROVIDER", "gemini").strip().lower()

# The model name/identifier.
#   - Gemini:   e.g. "gemini-3.8-flash"
#   - LiteLLM:  e.g. "openai/gpt-4o-mini", "ollama/llama3", or the model your
#               LiteLLM proxy exposes. Prefix with the provider LiteLLM expects.
ADK_MODEL = os.getenv("ADK_MODEL", "gemini-3.8-flash")

# LiteLLM connection details (only used when MODEL_PROVIDER=litellm).
LITELLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "").strip()
LITELLM_API_KEY = os.getenv("LITELLM_API_KEY", "").strip()


def _build_model():
    """Return the model object/string every agent should use."""
    if MODEL_PROVIDER == "litellm":
        # Imported lazily so the app still runs without litellm installed
        # when using Gemini.
        from google.adk.models.lite_llm import LiteLlm

        return LiteLlm(
            model=ADK_MODEL,
            api_base=LITELLM_BASE_URL or None,
            api_key=LITELLM_API_KEY or None,
        )
    # Default: plain Gemini model string handled natively by ADK.
    return ADK_MODEL


# All agents import this. It is either a model-name string (Gemini) or a
# LiteLlm instance (LiteLLM provider).
MODEL = _build_model()

# Convenience flag other modules can check.
USING_LITELLM = MODEL_PROVIDER == "litellm"

# Application / session identifiers used by the ADK Runner.
APP_NAME = "adk_poc_chatbot"

# Location of the mock SQLite database.
DB_PATH = BASE_DIR / "database" / "mock.db"
