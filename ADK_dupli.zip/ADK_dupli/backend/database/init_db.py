"""Creates and seeds a mock SQLite database used by the SQL agent.

Run directly:  python -m database.init_db
It is also invoked automatically on backend startup if the DB is missing.
"""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "mock.db"


SCHEMA = """
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    city        TEXT NOT NULL,
    signup_date TEXT NOT NULL,
    tier        TEXT NOT NULL          -- bronze | silver | gold
);

CREATE TABLE products (
    id       INTEGER PRIMARY KEY,
    name     TEXT NOT NULL,
    category TEXT NOT NULL,
    price    REAL NOT NULL,
    stock    INTEGER NOT NULL
);

CREATE TABLE orders (
    id          INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    order_date  TEXT NOT NULL,
    status      TEXT NOT NULL,         -- pending | shipped | delivered | cancelled
    total       REAL NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE order_items (
    id         INTEGER PRIMARY KEY,
    order_id   INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity   INTEGER NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
"""

CUSTOMERS = [
    (1, "Alice Johnson", "New York", "2023-01-15", "gold"),
    (2, "Bob Smith", "Chicago", "2023-03-22", "silver"),
    (3, "Carla Gomez", "Austin", "2023-05-10", "bronze"),
    (4, "David Lee", "Seattle", "2024-02-01", "gold"),
    (5, "Emma Brown", "Boston", "2024-06-18", "silver"),
]

PRODUCTS = [
    (1, "Wireless Mouse", "Electronics", 25.99, 120),
    (2, "Mechanical Keyboard", "Electronics", 89.50, 60),
    (3, "USB-C Hub", "Accessories", 39.00, 200),
    (4, "Noise Cancelling Headphones", "Electronics", 199.99, 35),
    (5, "Laptop Stand", "Accessories", 45.00, 80),
    (6, "4K Monitor", "Electronics", 329.00, 25),
]

ORDERS = [
    (1, 1, "2024-07-01", "delivered", 115.49),
    (2, 2, "2024-07-03", "shipped", 89.50),
    (3, 1, "2024-08-12", "delivered", 199.99),
    (4, 3, "2024-08-20", "pending", 45.00),
    (5, 4, "2024-09-05", "delivered", 329.00),
    (6, 5, "2024-09-10", "cancelled", 25.99),
    (7, 4, "2024-09-15", "shipped", 128.50),
]

ORDER_ITEMS = [
    (1, 1, 1, 1), (2, 1, 3, 1), (3, 1, 5, 1),
    (4, 2, 2, 1),
    (5, 3, 4, 1),
    (6, 4, 5, 1),
    (7, 5, 6, 1),
    (8, 6, 1, 1),
    (9, 7, 2, 1), (10, 7, 3, 1),
]


def init_db() -> None:
    """(Re)create the mock database with fresh seed data."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.executescript(SCHEMA)
        cur.executemany("INSERT INTO customers VALUES (?,?,?,?,?)", CUSTOMERS)
        cur.executemany("INSERT INTO products VALUES (?,?,?,?,?)", PRODUCTS)
        cur.executemany("INSERT INTO orders VALUES (?,?,?,?,?)", ORDERS)
        cur.executemany("INSERT INTO order_items VALUES (?,?,?,?)", ORDER_ITEMS)
        conn.commit()
    finally:
        conn.close()
    print(f"Mock database created at {DB_PATH}")


if __name__ == "__main__":
    init_db()
