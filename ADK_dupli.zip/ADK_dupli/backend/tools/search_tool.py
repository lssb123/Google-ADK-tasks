"""Provider-aware web-search tool.

The built-in ADK `google_search` tool ONLY works with Gemini models. When the
app is configured to use a LiteLLM provider, we fall back to a simple function
tool so the search agent keeps working (it just won't have live grounding
unless you wire in a real search API here).
"""
from config import USING_LITELLM


def web_search(query: str) -> dict:
    """Look up information on the web for the given query.

    NOTE: This is a placeholder used when running through LiteLLM (where the
    native google_search grounding is unavailable). Replace the body with a
    real search API call (SerpAPI, Tavily, Bing, Brave, etc.) for live results.

    Args:
        query: The search query.

    Returns:
        dict: status and a note/result for the query.
    """
    return {
        "status": "success",
        "query": query,
        "note": (
            "LiteLLM mode: live web grounding is not configured. Answer using "
            "your own knowledge and clearly state it may not be up to date. "
            "To enable real search, plug a search API into tools/search_tool.web_search."
        ),
    }


def get_search_tools() -> list:
    """Return the correct search tool(s) for the active model provider."""
    if USING_LITELLM:
        return [web_search]
    # Gemini path: use the native grounded search tool.
    from google.adk.tools import google_search

    return [google_search]
