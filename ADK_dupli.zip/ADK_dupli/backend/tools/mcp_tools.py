"""Mock MCP (Model Context Protocol) tools.

In a real deployment these functions would be provided by an external MCP
server (e.g. via `google.adk.tools.mcp_tool.MCPToolset` connecting over
stdio/SSE). To keep this POC self-contained and free of external
infrastructure, we simulate an MCP server that exposes weather and currency
"resources". Swap these out for a real MCPToolset when you have a server.
"""
from datetime import datetime, timezone

# Simulated "remote" data that an MCP server might expose.
_WEATHER = {
    "new york": {"temp_c": 22, "condition": "Partly cloudy", "humidity": 55},
    "chicago": {"temp_c": 18, "condition": "Windy", "humidity": 48},
    "seattle": {"temp_c": 15, "condition": "Rainy", "humidity": 80},
    "austin": {"temp_c": 31, "condition": "Sunny", "humidity": 35},
    "boston": {"temp_c": 20, "condition": "Clear", "humidity": 50},
}

_RATES_TO_USD = {
    "usd": 1.0,
    "eur": 1.08,
    "gbp": 1.27,
    "inr": 0.012,
    "jpy": 0.0067,
}


def mcp_get_weather(city: str) -> dict:
    """Fetch current weather for a city from the (mock) MCP weather resource.

    Args:
        city: Name of the city, e.g. "Seattle".

    Returns:
        dict: status and the weather details for the requested city.
    """
    data = _WEATHER.get(city.strip().lower())
    if not data:
        return {
            "status": "error",
            "error_message": f"No MCP weather resource for '{city}'. "
            f"Available: {', '.join(sorted(_WEATHER))}.",
        }
    return {
        "status": "success",
        "city": city,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
        **data,
    }


def mcp_convert_currency(amount: float, from_currency: str, to_currency: str) -> dict:
    """Convert an amount between currencies using the (mock) MCP FX resource.

    Args:
        amount: The numeric amount to convert.
        from_currency: Source currency code (e.g. "EUR").
        to_currency: Target currency code (e.g. "USD").

    Returns:
        dict: status and the converted amount.
    """
    src = from_currency.strip().lower()
    dst = to_currency.strip().lower()
    if src not in _RATES_TO_USD or dst not in _RATES_TO_USD:
        return {
            "status": "error",
            "error_message": f"Unsupported currency. Supported: "
            f"{', '.join(c.upper() for c in _RATES_TO_USD)}.",
        }
    usd = amount * _RATES_TO_USD[src]
    converted = usd / _RATES_TO_USD[dst]
    return {
        "status": "success",
        "amount": amount,
        "from": from_currency.upper(),
        "to": to_currency.upper(),
        "converted_amount": round(converted, 2),
    }
