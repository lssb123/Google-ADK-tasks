"""Function tools that let the SQL agent inspect and query the mock database.

These are plain Python functions. ADK automatically converts the function
signature + docstring into a tool schema for the LLM.
"""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "database" / "mock.db"


def get_database_schema() -> dict:
    """Return the schema (tables and columns) of the mock database.

    Use this first to understand what tables and columns are available
    before writing a SQL query.

    Returns:
        dict: A mapping of table name -> list of "column (type)" strings.
    """
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cur.fetchall()]
        schema = {}
        for table in tables:
            cur.execute(f"PRAGMA table_info({table})")
            schema[table] = [f"{col[1]} ({col[2]})" for col in cur.fetchall()]
        return {"status": "success", "schema": schema}
    finally:
        conn.close()


def run_sql_query(query: str) -> dict:
    """Execute a read-only SQL SELECT query against the mock database.

    Only SELECT statements are allowed. Any attempt to modify data
    (INSERT/UPDATE/DELETE/DROP/ALTER) is rejected.

    Args:
        query: A valid SQLite SELECT statement.

    Returns:
        dict: status, the columns, and the rows returned by the query.
    """
    normalized = query.strip().lower()
    forbidden = ("insert", "update", "delete", "drop", "alter", "create", "replace")
    if not normalized.startswith("select") or any(k in normalized for k in forbidden):
        return {
            "status": "error",
            "error_message": "Only read-only SELECT queries are allowed.",
        }

    conn = sqlite3.connect(DB_PATH)
    try:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(query)
        rows = cur.fetchall()
        columns = [d[0] for d in cur.description] if cur.description else []
        data = [dict(row) for row in rows]
        return {
            "status": "success",
            "columns": columns,
            "row_count": len(data),
            "rows": data,
        }
    except sqlite3.Error as exc:
        return {"status": "error", "error_message": str(exc)}
    finally:
        conn.close()
