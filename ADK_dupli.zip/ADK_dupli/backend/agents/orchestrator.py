"""Root orchestrator agent.

This is the "main" agent the user talks to. It inspects each incoming
question and delegates (routes) to the most appropriate specialist agent
using ADK's built-in LLM-driven delegation (transfer_to_agent):

    orchestrator_agent
      ├── search_agent    -> general knowledge / current events (Google Search)
      ├── sql_agent       -> internal business data (mock SQL database)
      ├── mcp_agent       -> external MCP tools (weather, currency)
      └── research_agent  -> broad questions needing web + data (Parallel+Sequential)
"""
from google.adk.agents import LlmAgent

from config import MODEL
from agents.mcp_agent import mcp_agent
from agents.research_agent import research_agent
from agents.search_agent import search_agent
from agents.sql_agent import sql_agent

orchestrator_agent = LlmAgent(
    name="orchestrator_agent",
    model=MODEL,
    description="Main router that decides which specialist agent should answer.",
    instruction=(
        "You are the ORCHESTRATOR of a multi-agent chatbot. Your job is to "
        "read the user's question and route it to the correct specialist "
        "agent. Do NOT answer specialised questions yourself — delegate.\n\n"
        "Routing rules:\n"
        "- General knowledge, news, current events, 'who/what/when' about the "
        "outside world  ->  transfer to `search_agent`.\n"
        "- Company/business data: customers, products, orders, revenue, sales, "
        "inventory, stock  ->  transfer to `sql_agent`.\n"
        "- Weather for a city OR currency conversion / exchange rates  ->  "
        "transfer to `mcp_agent`.\n"
        "- Broad questions that clearly need BOTH outside/market info AND "
        "internal company data together  ->  transfer to `research_agent`.\n\n"
        "If the user just greets you or asks what you can do, answer briefly "
        "yourself and explain the four capabilities. For everything else, "
        "delegate to exactly one specialist agent."
    ),
    sub_agents=[search_agent, sql_agent, mcp_agent, research_agent],
)

# Friendly labels shown in the frontend for each internal agent name.
AGENT_LABELS = {
    "orchestrator_agent": "🧭 Orchestrator",
    "search_agent": "🔎 Google Search Agent",
    "sql_agent": "🗄️ SQL Database Agent",
    "mcp_agent": "🔌 MCP External Agent",
    "research_agent": "🧪 Research Pipeline (Parallel + Sequential)",
    "parallel_research_gather": "⚡ Parallel Gather",
    "web_researcher": "🌐 Web Researcher",
    "data_researcher": "📊 Data Researcher",
    "research_synthesizer": "🧩 Synthesizer",
}
