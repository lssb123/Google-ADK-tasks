"""Research pipeline demonstrating ADK workflow agents.

Structure:
    research_agent (SequentialAgent)
      1. gather (ParallelAgent)  -> runs two researchers concurrently
           - web_researcher  (Google Search)  -> state['web_findings']
           - data_researcher (SQL database)    -> state['db_findings']
      2. synthesizer (LlmAgent) -> merges both findings into one answer

Use this for broad questions that benefit from BOTH external web knowledge
and internal company data at the same time.
"""
from google.adk.agents import LlmAgent, ParallelAgent, SequentialAgent

from config import MODEL
from tools.search_tool import get_search_tools
from tools.sql_tools import get_database_schema, run_sql_query

# --- Parallel branch 1: external web research -----------------------------
web_researcher = LlmAgent(
    name="web_researcher",
    model=MODEL,
    description="Gathers external web context using web search.",
    instruction=(
        "Use the search tool to gather relevant external/market context for "
        "the user's request. Return a short bullet summary of what you found."
    ),
    tools=get_search_tools(),
    output_key="web_findings",
)

# --- Parallel branch 2: internal data research ----------------------------
data_researcher = LlmAgent(
    name="data_researcher",
    model=MODEL,
    description="Gathers internal company data from the SQL database.",
    instruction=(
        "Inspect the schema with get_database_schema, then run a SELECT query "
        "with run_sql_query to gather any relevant internal figures "
        "(customers, orders, revenue, stock). Return a short bullet summary."
    ),
    tools=[get_database_schema, run_sql_query],
    output_key="db_findings",
)

gather = ParallelAgent(
    name="parallel_research_gather",
    description="Runs web and data research concurrently.",
    sub_agents=[web_researcher, data_researcher],
)

# --- Sequential step 2: synthesize both sources ---------------------------
synthesizer = LlmAgent(
    name="research_synthesizer",
    model=MODEL,
    description="Combines web and data findings into a single answer.",
    instruction=(
        "Combine the two research results below into one clear, well-structured "
        "answer for the user.\n\n"
        "External web findings:\n{web_findings}\n\n"
        "Internal data findings:\n{db_findings}\n\n"
        "Produce a concise synthesis that references both where relevant."
    ),
)

research_agent = SequentialAgent(
    name="research_agent",
    description=(
        "Handles broad questions that need BOTH external web knowledge AND "
        "internal company data, gathering them in parallel and then "
        "synthesizing a combined answer."
    ),
    sub_agents=[gather, synthesizer],
)
