"""Search agent: answers general-knowledge / current-events questions using
web search (native Google Search grounding on Gemini, or a fallback tool on
LiteLLM providers)."""
from google.adk.agents import LlmAgent

from config import MODEL
from tools.search_tool import get_search_tools

search_agent = LlmAgent(
    name="search_agent",
    model=MODEL,
    description=(
        "Answers general knowledge, current events, and open-web questions "
        "by grounding responses in web search results."
    ),
    instruction=(
        "You are a research specialist. Use the available search tool to find "
        "accurate, up-to-date information for the user's question. "
        "Summarize the findings clearly and cite what you found. "
        "Always base your answer on the search results when available."
    ),
    tools=get_search_tools(),
)
