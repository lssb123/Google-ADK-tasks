"""MCP agent: fetches data from an external (mock) MCP server exposing weather
and currency-exchange resources."""
from google.adk.agents import LlmAgent

from config import MODEL
from tools.mcp_tools import mcp_convert_currency, mcp_get_weather

mcp_agent = LlmAgent(
    name="mcp_agent",
    model=MODEL,
    description=(
        "Fetches live data from external MCP tools: current weather for a city "
        "and currency exchange / conversion."
    ),
    instruction=(
        "You connect to external MCP tools. Use mcp_get_weather for weather "
        "questions and mcp_convert_currency for currency conversion questions. "
        "Call the correct tool, then present the result to the user in a clear, "
        "natural sentence."
    ),
    tools=[mcp_get_weather, mcp_convert_currency],
)
