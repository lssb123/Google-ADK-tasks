"""SQL agent: answers questions about internal business data stored in the
mock SQLite database (customers, products, orders)."""
from google.adk.agents import LlmAgent

from config import MODEL
from tools.sql_tools import get_database_schema, run_sql_query

sql_agent = LlmAgent(
    name="sql_agent",
    model=MODEL,
    description=(
        "Answers questions about internal business data: customers, products, "
        "orders, revenue, inventory and stock levels stored in the company "
        "SQL database."
    ),
    instruction=(
        "You are a data analyst working with a SQLite database.\n"
        "Workflow you MUST follow:\n"
        "1. Call get_database_schema to learn the available tables/columns.\n"
        "2. Write a single valid SQLite SELECT query to answer the question.\n"
        "3. Call run_sql_query with that query.\n"
        "4. Interpret the returned rows and give the user a concise, friendly "
        "answer in natural language (not raw JSON).\n"
        "Only use read-only SELECT queries. If the data cannot answer the "
        "question, say so clearly."
    ),
    tools=[get_database_schema, run_sql_query],
)
