"""FastAPI backend for the ADK multi-agent chatbot POC.

Exposes a Server-Sent Events (SSE) endpoint that streams the orchestrator's
routing decisions, each agent that becomes active, tool calls, intermediate
"thinking", and the final answer to the frontend in real time.
"""
import json
import uuid

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from pydantic import BaseModel

from config import APP_NAME, DB_PATH
from agents.orchestrator import AGENT_LABELS, orchestrator_agent
from database.init_db import init_db

# --- Ensure the mock database exists --------------------------------------
if not DB_PATH.exists():
    init_db()

# --- ADK runner + session service -----------------------------------------
session_service = InMemorySessionService()
runner = Runner(
    agent=orchestrator_agent,
    app_name=APP_NAME,
    session_service=session_service,
)

# --- FastAPI app -----------------------------------------------------------
app = FastAPI(title="ADK Multi-Agent Chatbot POC")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str
    user_id: str = "web_user"
    session_id: str | None = None


def _sse(event_type: str, **data) -> str:
    """Format a dict as a Server-Sent Event line."""
    payload = {"type": event_type, **data}
    return f"data: {json.dumps(payload)}\n\n"


def _label(agent_name: str) -> str:
    return AGENT_LABELS.get(agent_name, agent_name)


async def _ensure_session(user_id: str, session_id: str) -> None:
    """Create the session if it does not already exist."""
    existing = await session_service.get_session(
        app_name=APP_NAME, user_id=user_id, session_id=session_id
    )
    if existing is None:
        await session_service.create_session(
            app_name=APP_NAME, user_id=user_id, session_id=session_id
        )


def _events_from(event, seen_agents: set[str]) -> list[str]:
    """Translate a single ADK event into zero or more SSE lines."""
    author = event.author or "unknown"
    out: list[str] = []

    # New agent became active.
    if author not in seen_agents and author in AGENT_LABELS:
        seen_agents.add(author)
        out.append(_sse("agent_selected", agent=author, label=_label(author)))

    # Tool calls / results = visible "thinking / actions".
    for call in event.get_function_calls():
        out.append(_sse("tool_call", agent=author, label=_label(author),
                        tool=call.name, args=call.args or {}))
    for resp in event.get_function_responses():
        out.append(_sse("tool_result", agent=author, label=_label(author),
                        tool=resp.name))

    return out


async def event_stream(req: ChatRequest):
    """Run the orchestrator and stream every step as SSE events."""
    user_id = req.user_id
    session_id = req.session_id or f"s_{uuid.uuid4().hex[:12]}"
    await _ensure_session(user_id, session_id)

    yield _sse("session", session_id=session_id)
    yield _sse("status", message="Orchestrator is analyzing your question...")

    content = types.Content(role="user", parts=[types.Part(text=req.message)])
    seen_agents: set[str] = set()
    final_text = ""

    try:
        async for event in runner.run_async(
            user_id=user_id, session_id=session_id, new_message=content
        ):
            for line in _events_from(event, seen_agents):
                yield line

            text = "".join(
                p.text or "" for p in (event.content.parts if event.content else [])
            )
            if text.strip():
                if event.is_final_response():
                    final_text = text
                else:
                    yield _sse("thinking", agent=event.author,
                               label=_label(event.author or ""), text=text)

        yield _sse("final", text=final_text or "(no response produced)")
    except Exception as exc:  # surface errors to the UI instead of hanging
        msg = str(exc)
        if "RESOURCE_EXHAUSTED" in msg or "429" in msg:
            msg = (
                "Gemini API quota/rate limit reached (429). Wait a minute and "
                "retry, switch ADK_MODEL in .env (e.g. gemini-2.0-flash), or "
                "enable billing for higher limits."
            )
        yield _sse("error", message=msg)
    finally:
        yield _sse("done")


@app.post("/api/chat/stream")
async def chat_stream(req: ChatRequest):
    return StreamingResponse(
        event_stream(req),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/health")
async def health():
    return {"status": "ok", "app": APP_NAME}


# Serve the frontend (mounted last so /api routes take precedence).
app.mount(
    "/",
    StaticFiles(directory="../frontend", html=True),
    name="frontend",
)
