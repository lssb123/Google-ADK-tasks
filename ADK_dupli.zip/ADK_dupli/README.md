# 🤖 ADK Multi-Agent Chatbot POC

A complete end-to-end proof-of-concept built with **Google's Agent Development
Kit (ADK)**. A **main orchestrator agent** reads each question and routes it to
the right specialist agent. The frontend shows the **live thinking** and
**which agent was selected** in real time.

---

## 🧩 Architecture

```
                    ┌─────────────────────────┐
   User ───────────▶│   🧭 Orchestrator Agent  │  (LLM-driven routing)
                    └────────────┬────────────┘
          ┌──────────────┬───────┼───────────────┬──────────────────┐
          ▼              ▼       ▼               ▼                  
  🔎 search_agent   🗄️ sql_agent  🔌 mcp_agent   🧪 research_agent
  (Google Search)  (mock SQLite) (mock MCP:      (SequentialAgent)
                                  weather / FX)     │
                                                    ▼
                                       ⚡ ParallelAgent
                                       ├── 🌐 web_researcher (Search)
                                       └── 📊 data_researcher (SQL)
                                                    │
                                                    ▼
                                       🧩 research_synthesizer
```

| Agent | Type | When it's used |
|-------|------|----------------|
| `orchestrator_agent` | `LlmAgent` (root) | Routes every question |
| `search_agent` | `LlmAgent` + `google_search` | General knowledge / current events |
| `sql_agent` | `LlmAgent` + SQL tools | Internal business data (customers, orders…) |
| `mcp_agent` | `LlmAgent` + MCP tools | Weather / currency (external MCP) |
| `research_agent` | `SequentialAgent` → `ParallelAgent` → synthesizer | Broad questions needing web **and** data |

> **Routing** uses ADK's built-in LLM-driven delegation (`transfer_to_agent`)
> via the orchestrator's `sub_agents`.

---

## 📂 Project structure

```
ADK/
├── backend/
│   ├── agents/
│   │   ├── orchestrator.py      # root router + agent labels
│   │   ├── search_agent.py      # Google Search agent
│   │   ├── sql_agent.py         # SQL database agent
│   │   ├── mcp_agent.py         # external MCP agent (mock)
│   │   └── research_agent.py    # Parallel + Sequential pipeline
│   ├── tools/
│   │   ├── sql_tools.py         # schema + read-only SQL query tools
│   │   └── mcp_tools.py         # mock MCP weather / currency tools
│   ├── database/
│   │   ├── init_db.py           # creates + seeds mock.db
│   │   └── mock.db              # (auto-generated)
│   ├── config.py
│   ├── main.py                  # FastAPI + SSE streaming
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── index.html
    ├── styles.css
    └── app.js
```

---

## 🚀 Setup & run

### 1. Prerequisites
- Python **3.10+**
- A **Google AI Studio API key**: https://aistudio.google.com/app/apikey

### 2. Install
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1        # Windows PowerShell
pip install -r requirements.txt
```

### 3. Configure your API key
```powershell
copy .env.example .env
# then edit .env and set GOOGLE_API_KEY=...
```

### 4. (Optional) build the mock DB manually
```powershell
python -m database.init_db
```
> It is also created automatically on first startup.

### 5. Run the server
```powershell
uvicorn main:app --reload --port 8000
```

### 6. Open the app
Navigate to **http://localhost:8000** — the FastAPI server also serves the
frontend. Start chatting!

---

## 💬 Example questions (and where they route)

| Question | Routes to |
|----------|-----------|
| "Who won the last FIFA World Cup?" | 🔎 search_agent |
| "Which customer placed the most orders?" | 🗄️ sql_agent |
| "What products are low on stock?" | 🗄️ sql_agent |
| "What's the weather in Seattle?" | 🔌 mcp_agent |
| "Convert 100 EUR to USD" | 🔌 mcp_agent |
| "Compare our monitor prices with market trends" | 🧪 research_agent |

---

## 🔌 Using a **real** MCP server

The MCP tools in `tools/mcp_tools.py` are mocked so the POC runs with zero
external infrastructure. To connect a real MCP server, replace `mcp_agent`'s
tools with an `MCPToolset`:

```python
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters

mcp_agent = LlmAgent(
    name="mcp_agent",
    model=MODEL,
    instruction="...",
    tools=[MCPToolset(connection_params=StdioServerParameters(
        command="npx", args=["-y", "@modelcontextprotocol/server-weather"],
    ))],
)
```

---

## 🧠 How the "thinking" is streamed

`main.py` iterates over `runner.run_async(...)` events and emits SSE messages:

- `agent_selected` → a new agent became active (highlights the node)
- `tool_call` / `tool_result` → a tool was invoked / returned
- `thinking` → intermediate model text
- `final` → the final answer

The frontend (`app.js`) parses these and renders the live trace on the right.

---

## ⚙️ Notes on ADK 2.0

ADK 2.0 introduces a graph-based workflow runtime but remains **backward
compatible** with the `LlmAgent` / `SequentialAgent` / `ParallelAgent` APIs used
here, so this POC runs on both ADK 1.x and 2.0. To adopt native 2.0 graph
workflows later, see https://adk.dev/graphs/.
